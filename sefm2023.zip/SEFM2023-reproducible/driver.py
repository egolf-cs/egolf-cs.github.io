from pprint import pprint
from pathlib import Path

import matplotlib.pyplot as plt

from data import mk_data, plot_lim_approx_multi

import _2pc_automata, toy_automata, abp_automata
from toy_automata import mk_S_good, mk_S_bad
from _2pc_automata import mk_S_H, mk_S_A1, mk_S_A2
from abp_automata import mk_S_HH, mk_S_HA, mk_S_AH, mk_S_AA

MODES = ("Toy_Comm", "2PC", "ABP")
print("0 for toy communication protocol")
print("1 for 2PC")
print("2 for ABP")
MODE = int(input("Mode: "))

fig = plt.figure(figsize=(12,6))
ax = plt.axes()
axins_struct = None
colors = None
alpha = None
loc = None

if MODE == 0:
    print("Reproducing toy communication protocol case study...")
    title = ("Performance of Simple Communication protocols with"
             " different receivers")
    ylabel = "Average rate of\ns-a sequences"
    instances = [mk_S_good, mk_S_bad]
    mk_f = toy_automata.mk_fitness_fn
elif MODE == 1:
    print("Reproducing 2PC case study...")
    title = "Performance of 2PC protocols with different transaction managers"
    ylabel = "Average rate of\ncompleted transactions"
    instances = [mk_S_H, mk_S_A1, mk_S_A2]
    mk_f = _2pc_automata.mk_fitness_fn
    colors = ["r", "g", "b"]
    alpha = 0.5
else:
    print("Reproducing ABP case study (allow 10-60 seconds)...")
    title = "Performance of ABP protocols with different senders/receivers"
    ylabel = "Average rate of\nsend-done sequences"
    instances = [mk_S_HH, mk_S_HA, mk_S_AH, mk_S_AA]
    mk_f = abp_automata.mk_fitness_fn
    axins = ax.inset_axes([0.2, 0.6, 0.37, 0.37])
    corners = (8500, 9000, 0.013, 0.018)
    axins_struct = (axins, corners)
    loc = "upper right"


# representation of aggregate average rate as a scalar arithmetic function
def h(y1, y2):
    if y2 == 0:
        return None
    return y1/y2


data_list = [mk_data(9000, instance, mk_f, h) for instance in instances]
data_for_plot, data_for_table = zip(*data_list)
plot_lim_approx_multi(data_for_plot, ax, axins_struct, title, ylabel, 
    loc=loc, colors=colors, alpha=alpha)
pprint(data_for_table)
Path("img").mkdir(parents=True, exist_ok=True)
plt.savefig(f"img/{MODES[MODE]}.png")

print("Finished! Compare the data above with Table 1 of the paper.")
print("Plots of intermediate K-approximations can be found in the"
      " img directory.")