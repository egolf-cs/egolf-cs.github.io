import time
import matplotlib.pyplot as plt
from tool.interface import k_approx

def mk_data(k, mk_S, mk_f, h):

    start = time.time()
    S = mk_S()
    f = mk_f()
    mid = time.time()
    ks, aggs = k_approx(k, S, f, h)
    end = time.time()

    table_data = {
        "1. M" : S.name,
        "2. |M|" : len(S.Q),
        "3. total time" : end-start,
        f"4. @f(M{ks[-2]})" : aggs[-2],
        f"5. @f(M{ks[-1]})" : aggs[-1],
    }

    return (ks, aggs, S.name), table_data

def plot_lim_approx(xs, ys, label, ax = None, axins = None, c=None, alpha=None):
    if ax is None:
        plt.plot(xs,ys,label=label,c=c,alpha=alpha)
    else:
        ax.plot(xs,ys,label=label,c=c,alpha=alpha)
        ax.scatter(xs,ys,label="_",s=10,c=c,alpha=alpha)
        if axins is not None:
            axins.plot(xs,ys,label=label,c=c,alpha=alpha)

def plot_lim_approx_multi(
        data_list, ax, axins_struct, title, ylabel, 
        loc=None, colors=None, alpha=None):
    
    if colors is None:
        colors = [None for _ in data_list]
    if loc is None:
        loc = "lower right"
    FS = 14
    
    data_list = zip(data_list, colors)
    if axins_struct is None:
        for (xs, ys, label), color in data_list:
            plot_lim_approx(
                xs, ys, f"$@_f({label}_k)$", 
                ax=ax, c=color, alpha=alpha)
        axins = None
    else:
        axins, corners = axins_struct
        for (xs, ys, label), color in data_list:
            plot_lim_approx(
                xs, ys, f"$@_f({label}_k)$", 
                ax=ax, axins=axins, c=color, alpha=alpha)
        x1, x2, y1, y2 = corners
        axins.set_xlim(x1, x2)
        axins.set_ylim(y1, y2)
        axins.set_xticklabels([])
        axins.set_yticklabels([])
        ax.indicate_inset_zoom(axins, edgecolor="black")
    


    ax.set_title(title, fontdict = {'fontsize' : FS})
    ax.set_xlabel("k",fontsize=FS)
    ax.set_ylabel(ylabel,fontsize=FS)
    ax.tick_params(axis='both', which='major', labelsize=FS)
    ax.legend(loc=loc)
