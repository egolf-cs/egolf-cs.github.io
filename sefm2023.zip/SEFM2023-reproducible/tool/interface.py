import numpy as np
from tool.LTS import mk_prod_cl

def compile_rec_rel(P, dtype):
    '''This function computes the recurrence relation corresponding to system P.
    The kth term of this recurrence relation is equal to the total number of 
    accepting states visited along all paths through P of length k.
    '''
    ordering = [str(x) for x in P.Q]
    ordering_st = [x for x in P.Q]
    inits = list(filter(lambda x: x in ordering, [str(x) for x in P.Q_0]))
    accs = list(filter(lambda x: x in ordering, [str(x) for x in P.F]))
    N = len(ordering)

    btot = 1
    qs = [[0 for i in range(2*N+btot)] for i in range(N)]
    Rs = [[0 for i in range(2*N+btot)] for i in range(N)]
    tot = [0 for i in range(N)] + [1 for i in range(N)] + [0]

    q0s = [0 for i in range(N)]
    R0s = [0 for i in range(N)]

    for s in ordering:
        s_i = ordering.index(s)
        re_s = ordering_st[s_i]
        preds = P.preds(re_s)
        preds = [str(x) for x in preds if str(x) in ordering]
        indices = [ordering.index(p) for p in preds]
        for i in indices:
            re_p = ordering_st[i]
            q_wts = [t.wt for t in P.delta[re_p][re_s]]
            qs[s_i][i] = sum(q_wts)
            Rs_wts = [t.wt for t in P.delta[re_p][re_s]]
            Rs[s_i][i+N] = sum(Rs_wts)
            if s in accs:
                Rs[s_i][i] = sum(Rs_wts)
        if s in inits:
            q0s[s_i] = 1
            if s in accs:
                R0s[s_i] = 1

    m = np.array(qs + Rs + [tot], dtype=dtype)
    v = np.array(q0s + R0s + [0])

    return m, v

def _approx_xhat_cumul_fast_aux(k,m):
    '''This function raises m to power k using exponentiation by squaring.
    It returns all intermediate powers.
    '''
    bits = bin(k)[:1:-1]
    intermediate_powers = [(int(1),m)]
    res = np.identity(len(m), dtype=np.float128)
    for idx, bit in enumerate(bits):
        expt, curr = intermediate_powers[-1]
        if int(bit) == 1:
            res = np.matmul(res,curr)
        if idx < len(bits) - 1:
            # We don't need to do this for the last bit
            intermediate_powers.append((2*expt, np.matmul(curr,curr)))
    intermediate_powers.append((k,res))
    return intermediate_powers


def approx_xhat_cumul_fast(k,m,v):
    '''Each element of cumul (the return value) is a list of tuples of natural 
    numbers. Each tuple (k', z) is such that z is the k'th term of the rec rel
    represented by recurrence matrix m, initial condition vector v.
    '''
    intermediate_powers = _approx_xhat_cumul_fast_aux(k,m)
    cumul = []
    for i, power in intermediate_powers:
        tmp = (np.matmul(power, v))[-1]
        cumul.append((i, tmp))
    return cumul

def k_approx_powers(k, h, *rrs):
    ''' Inputs:
    k : int := the depth to approximate the limit
    h : int^d -> int := the arithmetic function representing the 
        aggregate function 
    rrs : list (matrix * vector) := a list of recurrence relations
        represented by matrix-vector pairs (xi and v in paper)

    Outputs:
    ks : list int := the intermediate values of k for which the 
        k-approximation was computed
    aggs :list int := the intermediate k-approximations
    '''

    pts = [approx_xhat_cumul_fast(k,*rr_i) for rr_i in rrs]

    ks, aggs = [], []
    for tups in zip(*pts):
        ground_ks, ys = zip(*tups)
        k = ground_ks[0]
        assert(all(k == l for l in ground_ks))
        agg = h(*ys)
        if agg is not None:
            ks.append(k)
            aggs.append(agg)

    return ks, aggs

def k_approx(k, S, f, h, dtype=np.float128):
    ''' Inputs:
    k : int := the depth to approximate the limit
    S : System :=  the system to be evaluated
    f : list System := the list of LTS representing the fitness function
    h : int^d -> int := the arithmetic function representing the 
        aggregate function, where d is the length of f

    Outputs:
    ks : list int := the intermediate values of k for which the 
        k-approximation was computed
    aggs : list int := the intermediate k-approximations
    '''

    Ps = [mk_prod_cl(S, f_i) for f_i in f]
    rrs = [compile_rec_rel(P_i, dtype=dtype) for P_i in Ps]

    ks, aggs = k_approx_powers(k, h, *rrs)

    return ks, aggs
