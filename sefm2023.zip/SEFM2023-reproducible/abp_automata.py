from tool.LTS import StateLabel, TransitionLabel, System, mk_multi_prod_ren

# https://users.ics.aalto.fi/stavros/papers/sigact2017.pdf

# # Environment Processes # #

# Unreliable forward channel from Fig of sigact2017
def mk_fchan_u():
    Q = [StateLabel("f0", init=True),
         StateLabel("f1"),
         StateLabel("f2")]
    delta = {Q[0] : {Q[0] : [TransitionLabel("p0","?"),
                             TransitionLabel("p1","?")],
                     Q[1] : [TransitionLabel("p0","?")],
                     Q[2] : [TransitionLabel("p1","?")]},
             Q[1] : {Q[0] : [TransitionLabel("p0'","!")],
                     Q[1] : [TransitionLabel("p0'","!"),
                             TransitionLabel("p1","?"),
                             TransitionLabel("p0","?")]},
             Q[2] : {Q[0] : [TransitionLabel("p1'","!")],
                     Q[2] : [TransitionLabel("p1'","!"),
                             TransitionLabel("p1","?"),
                             TransitionLabel("p0","?")]}}
    S = System("f_chan_u", Q, delta)
    return S

# Unreliable back channel from Fig of sigact2017
def mk_bchan_u():
    Q = [StateLabel("b0", init=True),
         StateLabel("b1"),
         StateLabel("b2")]
    delta = {Q[0] : {Q[0] : [TransitionLabel("a0","?"),
                             TransitionLabel("a1","?")],
                     Q[1] : [TransitionLabel("a0","?")],
                     Q[2] : [TransitionLabel("a1","?")]},
             Q[1] : {Q[0] : [TransitionLabel("a0'","!")],
                     Q[1] : [TransitionLabel("a0'","!"),
                             TransitionLabel("a1","?"),
                             TransitionLabel("a0","?")]},
             Q[2] : {Q[0] : [TransitionLabel("a1'","!")],
                     Q[2] : [TransitionLabel("a1'","!"),
                             TransitionLabel("a1","?"),
                             TransitionLabel("a0","?")]}}
    S = System("b_chan_u", Q, delta)
    return S

# from Fig 3 of sigact2017
def mk_sending_client3():
    Q = [StateLabel("sc0",init=True),
         StateLabel("sc1")]
    delta = {Q[0] : {Q[0] : [TransitionLabel("done","?")],
                     Q[1] : [TransitionLabel("send","!")]},
             Q[1] : {Q[0] : [TransitionLabel("done","?")]}}
    S = System("sending_client3", Q, delta)
    return S

# from Fig 3 of sigact2017
def mk_receiving_client3():
    Q = [StateLabel("rc0",init=True)]
    delta = {Q[0] : {Q[0] : [TransitionLabel("deliver","?")]}}
    S = System("receiving_client3", Q, delta)
    return S

# from Fig 3 of sigact2017
def mk_timer3():
    Q = [StateLabel("t0",init=True)]
    delta = {Q[0] : {Q[0] : [TransitionLabel("timeout","!")]}}
    S = System("timer3", Q, delta)
    return S



# # The Sender/Receiver Processes (varies per case study) # #

# from Fig 10 of sigact2017
def mk_rec10():
    Q = [StateLabel("r0", init=True),
    StateLabel("r1"),
    StateLabel("r2"),
    StateLabel("r3"),
    StateLabel("r4"),
    StateLabel("r5")]
    delta = {Q[0] : {Q[1] : [TransitionLabel("p0'","?")],
                     Q[5] : [TransitionLabel("p1'","?")]},
             Q[1] : {Q[2] : [TransitionLabel("deliver","!")]},
             Q[2] : {Q[3] : [TransitionLabel("a0","!")]},
             Q[3] : {Q[2] : [TransitionLabel("p0'","?")],
                     Q[4] : [TransitionLabel("p1'","?")]},
             Q[4] : {Q[5] : [TransitionLabel("deliver","!")]},
             Q[5] : {Q[0] : [TransitionLabel("a1","!")]}}
    S = System("rec10", Q, delta)
    return S

# from Fig 18 of sigact2017
def mk_rec18():
    Q = [StateLabel("r0", init=True),
    StateLabel("r1"),
    StateLabel("r2"),
    StateLabel("r3"),
    StateLabel("r4"),
    StateLabel("r5")]
    delta = {Q[0] : {Q[1] : [TransitionLabel("p0'","?")],
                     Q[5] : [TransitionLabel("p1'","?")]},
             Q[1] : {Q[2] : [TransitionLabel("deliver","!")]},
             Q[2] : {Q[3] : [TransitionLabel("a0","!")]},
             Q[3] : {Q[2] : [TransitionLabel("p0'","?")],
                     Q[4] : [TransitionLabel("p1'","?")]},
             Q[4] : {Q[0] : [TransitionLabel("deliver","!")]},
             Q[5] : {Q[0] : [TransitionLabel("a1","!")]}}
    S = System("rec18", Q, delta)
    return S

# from Fig 9 of sigact2017
def mk_sender9():
    Q = [StateLabel("s0",init=True),
        StateLabel("s1"),
        StateLabel("s2"),
        StateLabel("s3"),
        StateLabel("s4"),
        StateLabel("s5"),
        StateLabel("s6"),
        StateLabel("s7"),]
    delta = {Q[0] : {Q[0] : [TransitionLabel("a0'","?"),
                             TransitionLabel("a1'","?"),
                             TransitionLabel("timeout","?")],
                     Q[1] : [TransitionLabel("send","?")]},
             Q[1] : {Q[2] : [TransitionLabel("p0","!")]},
             Q[2] : {Q[2] : [TransitionLabel("send","?"),
                             TransitionLabel("a1'","?")],
                     Q[1] : [TransitionLabel("timeout","?")],
                     Q[3] : [TransitionLabel("a0'","?")]},
             Q[3] : {Q[4] : [TransitionLabel("done","!")]},
             Q[4] : {Q[4] : [TransitionLabel("a0'","?"),
                             TransitionLabel("a1'","?"),
                             TransitionLabel("timeout","?")],
                     Q[5] : [TransitionLabel("send","?")]},
             Q[5] : {Q[6] : [TransitionLabel("p1","!")]},
             Q[6] : {Q[6] : [TransitionLabel("a0'","?"),
                             TransitionLabel("send","?")],
                     Q[5] : [TransitionLabel("timeout","?")],
                     Q[7] : [TransitionLabel("a1'","?")]},
             Q[7] : {Q[0] : [TransitionLabel("done","!")]}}
    S = System("sender9", Q, delta)
    return S

# from Fig 19 of sigact2017
def mk_sender19():
    Q = [StateLabel("s0",init=True),
        StateLabel("s1"),
        StateLabel("s2"),
        StateLabel("s3"),
        StateLabel("s4"),
        StateLabel("s5"),
        StateLabel("s6"),
        StateLabel("s7"),]
    delta = {Q[0] : {Q[0] : [TransitionLabel("a0'","?"),
                             TransitionLabel("a1'","?"),
                             TransitionLabel("timeout","?")],
                     Q[4] : [TransitionLabel("send","?")]},
             Q[4] : {Q[4] : [TransitionLabel("a1'","?"),
                             TransitionLabel("send","?")],
                     Q[3] : [TransitionLabel("timeout","?")],
                     Q[1] : [TransitionLabel("a0'","?")]},
             Q[3] : {Q[4] : [TransitionLabel("p0","!")]},
             Q[1] : {Q[2] : [TransitionLabel("done","!")]},
             Q[2] : {Q[2] : [TransitionLabel("a0'","?"),
                             TransitionLabel("timeout","?")],
                     Q[5] : [TransitionLabel("send","?"),
                             TransitionLabel("a1'","?")]},
             Q[5] : {Q[6] : [TransitionLabel("p1","!")]},

             Q[6] : {Q[5] : [TransitionLabel("timeout","?"),
                             TransitionLabel("a0'","?")],
                     Q[7] : [TransitionLabel("a1'","?")],
                     Q[1] : [TransitionLabel("send","?")]},
             Q[7] : {Q[0] : [TransitionLabel("done","!")]}}
    S = System("sender19", Q, delta)
    return S



# # The systems to be evaluated, parameterized by the Sender/Receiver # #

def mk_S(sender, receiver, name):
    Ss = [
        mk_fchan_u(),
        mk_bchan_u(),
        mk_timer3(),
        mk_receiving_client3(),
        mk_sending_client3(),
        receiver,
        sender,
    ]
    S = mk_multi_prod_ren(Ss)
    S.name = name
    return S

def mk_S_HH():
    return mk_S(mk_sender9(), mk_rec10(), "HH")
def mk_S_HA():
    return mk_S(mk_sender9(), mk_rec18(), "HA")
def mk_S_AH():
    return mk_S(mk_sender19(), mk_rec10(), "AH")
def mk_S_AA():
    return mk_S(mk_sender19(), mk_rec18(), "AA")



# # The Fitness Function # #

def mk_req_resp_fn():
    Q = [StateLabel("rr0", init=True),
         StateLabel("rr1"),
         StateLabel("rr2", acc=True)]
    delta = {Q[0] : {Q[0] : [TransitionLabel("a0"),
                             TransitionLabel("a1"),
                             TransitionLabel("a0'"),
                             TransitionLabel("a1'"),
                             TransitionLabel("p0'"),
                             TransitionLabel("p1'"),
                             TransitionLabel("done"),
                             TransitionLabel("deliver"),
                             TransitionLabel("timeout"),
                             TransitionLabel("p0"),
                             TransitionLabel("p1")],
                     Q[1] : [TransitionLabel("send")]},
             Q[1] : {Q[1] : [TransitionLabel("p0"),
                             TransitionLabel("p1"),
                             TransitionLabel("a0'"),
                             TransitionLabel("a1'"),
                             TransitionLabel("p0'"),
                             TransitionLabel("p1'"),
                             TransitionLabel("send"),
                             TransitionLabel("deliver"),
                             TransitionLabel("timeout"),
                             TransitionLabel("a0"),
                             TransitionLabel("a1")],
                     Q[2] : [TransitionLabel("done")]},
             Q[2] : {Q[0] : [TransitionLabel("a0"),
                             TransitionLabel("a1"),
                             TransitionLabel("a0'"),
                             TransitionLabel("a1'"),
                             TransitionLabel("p0'"),
                             TransitionLabel("p1'"),
                             TransitionLabel("p0"),
                             TransitionLabel("p1"),
                             TransitionLabel("done"),
                             TransitionLabel("deliver"),
                             TransitionLabel("timeout")],
                     Q[1] : [TransitionLabel("send")]},}
    S = System("req_resp", Q, delta)
    return S

def mk_len_fn():
    Q = [StateLabel("len0", init=True),
         StateLabel("len1",acc=True)]
    delta = {Q[0] : {Q[1] : [TransitionLabel("p0"),
                            TransitionLabel("p1"),
                            TransitionLabel("a0'"),
                            TransitionLabel("a1'"),
                            TransitionLabel("p0'"),
                            TransitionLabel("p1'"),
                            TransitionLabel("done"),
                            TransitionLabel("send"),
                            TransitionLabel("deliver"),
                            TransitionLabel("timeout"),
                            TransitionLabel("a0"),
                            TransitionLabel("a1")]},
             Q[1] : {Q[1] : [TransitionLabel("p0"),
                             TransitionLabel("p1"),
                             TransitionLabel("a0'"),
                             TransitionLabel("a1'"),
                             TransitionLabel("p0'"),
                             TransitionLabel("p1'"),
                             TransitionLabel("done"),
                             TransitionLabel("send"),
                             TransitionLabel("deliver"),
                             TransitionLabel("timeout"),
                             TransitionLabel("a0"),
                             TransitionLabel("a1")]}}
    S = System("len",Q,delta)
    return S

def mk_fitness_fn():
    return mk_req_resp_fn(), mk_len_fn()