from tool.LTS import StateLabel, TransitionLabel, System, mk_multi_prod_ren

# # Environment Processes # #

def mk_database(i):
    Q = [
        StateLabel(f"db{i}0", init=True),
        StateLabel(f"db{i}1"),
        StateLabel(f"db{i}2"),
    ]
    delta = {
        Q[0] : {
          Q[1] : [
              TransitionLabel(f"qry{i}","?"),
            ],
          Q[2] : [
              TransitionLabel(f"qry{i}","?"),
            ],  
        },
        Q[1] : {
            Q[0] : [
                TransitionLabel(f"bd{i}", "!")
            ],
        },
        Q[2] : {
            Q[0] : [
                TransitionLabel(f"gd{i}", "!")
            ],
        },
    }
    S = System(f"db{i}", Q, delta)
    return S

def mk_db_man(i):
    Q0 = [StateLabel(f"dbm{i}0", init=True)]
    Qrest = [StateLabel(f"dbm{i}{n}") for n in range(1,6)]
    Q = Q0 + Qrest
    # print(Q)

    delta = dict()
    inlabels = [
        f"x{i}",
        f"gd{i}",
        f"bd{i}",
        f"ab{i}",
        f"cm{i}",
    ]
    inlabels = [TransitionLabel(x,"?") for x in inlabels]
    for j in [0,2,5]:
        delta[Q[j]] = {}
        delta[Q[j]][Q[j]] = list(inlabels)

    # Q0
    delta[Q[0]][Q[0]].remove(inlabels[0])
    delta[Q[0]][Q[1]] = [inlabels[0]]
    # Q2
    delta[Q[2]][Q[2]].remove(inlabels[1])
    delta[Q[2]][Q[2]].remove(inlabels[2])
    # print(inlabels)
    delta[Q[2]][Q[4]] = [inlabels[1]]
    delta[Q[2]][Q[3]] = [inlabels[2]]
    # Q5
    delta[Q[5]][Q[5]].remove(inlabels[3])
    delta[Q[5]][Q[5]].remove(inlabels[4])
    delta[Q[5]][Q[0]] = [inlabels[3], inlabels[4]]

    # Q1
    delta[Q[1]] = dict()
    delta[Q[1]][Q[2]] = [TransitionLabel(f"qry{i}","!")]
    # Q3
    delta[Q[3]] = dict()
    delta[Q[3]][Q[5]] = [TransitionLabel(f"no{i}","!")]
    # Q4
    delta[Q[4]] = dict()
    delta[Q[4]][Q[5]] = [TransitionLabel(f"yes{i}","!")]

    S = System(f"dbman{i}", Q, delta)
    return S

def mk_user():
    Q = [StateLabel("u0", init=True), StateLabel("u1")]
    delta = {
        Q[0] : {
            Q[1] : [TransitionLabel("x","!")]
        },
        Q[1] : {
            Q[0] : [
                TransitionLabel("succ","?"), 
                TransitionLabel("fail","?")
            ]
        },
    }
    S = System("user", Q, delta)
    return S



# # The Transaction Manager Processes (varies per instance of case study) # #

def mk_txman_H():
    Q0 = [StateLabel(f"m0", init=True)]
    Qrest = [StateLabel(f"m{n}") for n in range(1,12)]
    Q = Q0 + Qrest
    delta = {
        Q[0] : {
            Q[1] : [
                TransitionLabel("x","?")
            ],
            Q[0] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?"),
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?")
            ],
        },
        Q[1] : {
            Q[2] : [
                TransitionLabel("x1","!")
            ],
        },
        Q[2] : {
            Q[3] : [
                TransitionLabel("x2","!")
            ],
        },
        Q[3] : {
            Q[3] : [
                TransitionLabel("x","?")
            ],
            Q[4] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?")
            ],
            Q[8] : [
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?")
            ],
        },
        Q[4] : {
            Q[4] : [
                TransitionLabel("x","?")
            ],
            Q[5] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?")
            ],
            Q[9] : [
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?")
            ],
        },
        Q[5] : {
            Q[6] : [
                TransitionLabel("cm1","!")
            ],
        },
        Q[6] : {
            Q[7] : [
                TransitionLabel("cm2","!")
            ],
        },
        Q[7] : {
            Q[0] : [
                TransitionLabel("succ","!")
            ],
        },
        Q[8] : {
            Q[8] : [
                TransitionLabel("x","?")
            ],
            Q[9] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?"),
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?"),
            ],
        },
        Q[9] : {
            Q[10] : [
                TransitionLabel("ab1","!")
            ],
        },
        Q[10] : {
            Q[11] : [
                TransitionLabel("ab2","!")
            ],
        },
        Q[11] : {
            Q[0] : [
                TransitionLabel("fail","!")
            ],
        },
    }

    S = System("txman_H", Q, delta)
    return S

def mk_txman_A1():
    Q0 = [StateLabel(f"m0", init=True)]
    Qrest = [StateLabel(f"m{n}") for n in range(1,12)]
    Q = Q0 + Qrest
    delta = {
        Q[0] : {
            Q[1] : [
                TransitionLabel("x","?")
            ],
            Q[0] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?"),
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?")
            ],
        },
        Q[1] : {
            Q[2] : [
                TransitionLabel("x1","!")
            ],
        },
        Q[2] : {
            Q[2] : [
               TransitionLabel("x","?") 
            ],
            Q[3] : [
               TransitionLabel("no1","?") 
            ],
            Q[4] : [
               TransitionLabel("yes1","?") 
            ],
            Q[5] : [
               TransitionLabel("yes2","?") 
            ],
            Q[9] : [
               TransitionLabel("no2","?") 
            ],
        },
        Q[3] : {
            Q[8] : [
                TransitionLabel("x2","!"),
            ],
        },
        Q[4] : {
            Q[1] : [
                TransitionLabel("x2","!")
            ],
        },
        Q[5] : {
            Q[6] : [
                TransitionLabel("cm1","!")
            ],
        },
        Q[6] : {
            Q[7] : [
                TransitionLabel("cm2","!")
            ],
        },
        Q[7] : {
            Q[0] : [
                TransitionLabel("succ","!")
            ],
        },
        Q[8] : {
            Q[8] : [
                TransitionLabel("x","?")
            ],
            Q[9] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?"),
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?"),
            ],
        },
        Q[9] : {
            Q[10] : [
                TransitionLabel("ab1","!")
            ],
        },
        Q[10] : {
            Q[11] : [
                TransitionLabel("ab2","!")
            ],
        },
        Q[11] : {
            Q[0] : [
                TransitionLabel("fail","!")
            ],
        },
    }

    S = System("txman_A1", Q, delta)
    return S

def mk_txman_A2():
    Q0 = [StateLabel(f"m0", init=True)]
    Qrest = [StateLabel(f"m{n}") for n in range(1,12)]
    Q = Q0 + Qrest
    delta = {
        Q[0] : {
            Q[1] : [
                TransitionLabel("x","?")
            ],
            Q[0] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?"),
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?")
            ],
        },
        Q[1] : {
            Q[2] : [
                TransitionLabel("x1","!")
            ],
        },
        Q[2] : {
            Q[2] : [
               TransitionLabel("x","?") 
            ],
            Q[3] : [
               TransitionLabel("no1","?") 
            ],
            Q[4] : [
               TransitionLabel("yes1","?") 
            ],
            Q[5] : [
               TransitionLabel("yes2","?") 
            ],
            Q[9] : [
               TransitionLabel("no2","?") 
            ],
        },
        Q[3] : {
            Q[8] : [
                TransitionLabel("x2","!"),
            ],
        },
        Q[4] : {
            Q[2] : [
                TransitionLabel("x2","!")
            ],
        },
        Q[5] : {
            Q[6] : [
                TransitionLabel("cm1","!")
            ],
        },
        Q[6] : {
            Q[7] : [
                TransitionLabel("cm2","!")
            ],
        },
        Q[7] : {
            Q[0] : [
                TransitionLabel("succ","!")
            ],
        },
        Q[8] : {
            Q[8] : [
                TransitionLabel("x","?")
            ],
            Q[9] : [
                TransitionLabel("yes1","?"),
                TransitionLabel("yes2","?"),
                TransitionLabel("no1","?"),
                TransitionLabel("no2","?"),
            ],
        },
        Q[9] : {
            Q[10] : [
                TransitionLabel("ab1","!")
            ],
        },
        Q[10] : {
            Q[11] : [
                TransitionLabel("ab2","!")
            ],
        },
        Q[11] : {
            Q[0] : [
                TransitionLabel("fail","!")
            ],
        },
    }

    S = System("txman3", Q, delta)
    return S



# # The systems to be evaluated, parameterized by the Transaction Manager # #

def mk_S(txman, name):
    user = mk_user()
    Ss = [
        mk_database(1),
        mk_database(2),
        mk_db_man(1),
        mk_db_man(2),
        txman,
        user,
    ]
    S = mk_multi_prod_ren(Ss)
    S.name = name
    return S

def mk_S_H():
    return mk_S(mk_txman_H(), "H")
def mk_S_A1():
    return mk_S(mk_txman_A1(), "A1")
def mk_S_A2():
    return mk_S(mk_txman_A2(), "A2")



# # The Fitness Function # #

def mk_len_fn():
    Q = [
        StateLabel("len0", init=True),
        StateLabel("len1",acc=True)
    ]
    delta = {
        Q[0] : {
            Q[1] : [
                TransitionLabel("ab1"),
                TransitionLabel("ab2"),
                TransitionLabel("bd1"),
                TransitionLabel("bd2"),
                TransitionLabel("cm1"),
                TransitionLabel("cm2"),
                TransitionLabel("fail"),
                TransitionLabel("gd1"),
                TransitionLabel("gd2"),
                TransitionLabel("no1"),
                TransitionLabel("no2"),
                TransitionLabel("qry1"),
                TransitionLabel("qry2"),
                TransitionLabel("succ"),
                TransitionLabel("x1"),
                TransitionLabel("x2"),
                TransitionLabel("x"),
                TransitionLabel("yes1"),
                TransitionLabel("yes2"),
            ],
        },
        Q[1] : {
            Q[1] : [
                TransitionLabel("ab1"),
                TransitionLabel("ab2"),
                TransitionLabel("bd1"),
                TransitionLabel("bd2"),
                TransitionLabel("cm1"),
                TransitionLabel("cm2"),
                TransitionLabel("fail"),
                TransitionLabel("gd1"),
                TransitionLabel("gd2"),
                TransitionLabel("no1"),
                TransitionLabel("no2"),
                TransitionLabel("qry1"),
                TransitionLabel("qry2"),
                TransitionLabel("succ"),
                TransitionLabel("x1"),
                TransitionLabel("x2"),
                TransitionLabel("x"),
                TransitionLabel("yes1"),
                TransitionLabel("yes2"),
            ],
        },
    }
    S = System("2pc_len",Q,delta)
    return S

def mk_req_resp_fn():
    Q = [
        StateLabel("rr0", init=True),
        StateLabel("rr1"),
        StateLabel("rr2",acc=True),
    ]
    delta = {
        Q[0] : {
            Q[0] : [
                TransitionLabel("ab1"),
                TransitionLabel("ab2"),
                TransitionLabel("bd1"),
                TransitionLabel("bd2"),
                TransitionLabel("cm1"),
                TransitionLabel("cm2"),
                TransitionLabel("fail"),
                TransitionLabel("gd1"),
                TransitionLabel("gd2"),
                TransitionLabel("no1"),
                TransitionLabel("no2"),
                TransitionLabel("qry1"),
                TransitionLabel("qry2"),
                TransitionLabel("succ"),
                TransitionLabel("x1"),
                TransitionLabel("x2"),
                TransitionLabel("yes1"),
                TransitionLabel("yes2"),
            ],
            Q[1] : [ 
                TransitionLabel("x"),
            ]
        },
        Q[1] : {
            Q[1] : [
                TransitionLabel("ab1"),
                TransitionLabel("ab2"),
                TransitionLabel("bd1"),
                TransitionLabel("bd2"),
                TransitionLabel("cm1"),
                TransitionLabel("cm2"),
                TransitionLabel("gd1"),
                TransitionLabel("gd2"),
                TransitionLabel("no1"),
                TransitionLabel("no2"),
                TransitionLabel("qry1"),
                TransitionLabel("qry2"),
                TransitionLabel("x1"),
                TransitionLabel("x2"),
                TransitionLabel("x"),
                TransitionLabel("yes1"),
                TransitionLabel("yes2"),
            ],
            Q[2] : [
                TransitionLabel("succ"),
                TransitionLabel("fail"),
            ]
        },
        Q[2] : {
            Q[0] : [
                TransitionLabel("ab1"),
                TransitionLabel("ab2"),
                TransitionLabel("bd1"),
                TransitionLabel("bd2"),
                TransitionLabel("cm1"),
                TransitionLabel("cm2"),
                TransitionLabel("fail"),
                TransitionLabel("gd1"),
                TransitionLabel("gd2"),
                TransitionLabel("no1"),
                TransitionLabel("no2"),
                TransitionLabel("qry1"),
                TransitionLabel("qry2"),
                TransitionLabel("succ"),
                TransitionLabel("x1"),
                TransitionLabel("x2"),
                TransitionLabel("yes1"),
                TransitionLabel("yes2"),
            ],
            Q[1] : [ 
                TransitionLabel("x"),
            ]
        },
    }
    S = System("2pc_req_resp",Q,delta)
    return S

def mk_fitness_fn():
    return mk_req_resp_fn(), mk_len_fn()

