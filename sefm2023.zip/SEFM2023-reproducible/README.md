# SEFM2023 Artifact

This zip file contains the artifact for paper "Decoupled Fitness Criteria for Reactive Systems" by Derek Egolf and Stavros Tripakis, submitted to SEFM 2023. 
The paper is included in the zip file as SEFM2023_paper_53.pdf.

## Running the Artifact
The results in Table 1 of the paper can be reproduced by running the docker commands below and following the prompts.
Each of the three case studies should be run separately, per the prompts. 

`docker build -t sefm2023 .`

Please note the `.` in the command. The user should see the usual docker output, terminating in "Successfully..."

`docker run -it   -v $(pwd)/img:/img   sefm2023`

The user should see a prompt to enter an integer and an explanation for each possible choice.
The data from the table will be printed to the terminal. 
Image files are written to the img directory, which the docker command should automatically mount.

**A common error message** is "Got permission denied while trying to connect to the Docker daemon socket at unix..."
In this case, the user should add sudo to the beginning of the command (or elevate priviledges otherwise).

**We do not include** code to reproduce the results for the symbolic method mentioned in Section 5.1 of the paper, as those results depend on Mathematica, which requires a subscription to use.

## Project Structure

- *_automata.py : these files contain the automata for each case study
- data.py : this file allows to produce data for a case study and to plot that data
- driver.py : this files prompts the user for which case study they would like to reproduce
- tool/LTS.py : this file contains the data structures representing LTSs and auxiliary functions on these data structures (e.g. products)
- tool/interface.py : this file allows to construct the recurrence matrix/initial condition vector and to compute K-approximations
