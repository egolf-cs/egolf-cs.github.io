"""CLI driver for running Cataclyst synthesis benchmarks.

Provides a command-line interface for running individual or
batched benchmarks with different solver variants (proph, retro,
no-gen).

Collects benchmark filenames from the given input path (a single
.lisp file or a directory of them), applies optional
unreal-prefix filtering, then delegates each (benchmark, variant)
pair to run.run().

Usage examples:

    python driver.py inputs/foo.lisp --proph
    python driver.py inputs/ --all --exclude-unreal
"""

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

CATACLYST_DIR = Path(__file__).resolve().parent
IMPLEMENTATION_DIR = CATACLYST_DIR / "implementation"

UNREAL_PREFIX = "unreal-"

VARIANT_TO_TOOL_ID = {
    "proph" : "proph",
    "retro" : "retro",
    "no_gen" : "brute",
}

ALL_TOOL_IDS = list(VARIANT_TO_TOOL_ID.values())


def collect_benchmarks(input_path_str: str) -> list[str]:
    """Collect benchmark filenames from a file or directory.

    If input_path_str points to a .lisp file, returns a
    one-element list containing its filename.  If it points to a
    directory, returns a sorted list of every .lisp filename in
    that directory.

    Returns bare filenames (no directory prefix), e.g.
    "contata-list-insertion.lisp".

    Assumes input_path_str is a valid path to an existing file or
    directory; exits with an error message otherwise.
    """
    path = Path(input_path_str).resolve()
    if path.is_file():
        if path.suffix != ".lisp":
            print(
                f"Error: expected a .lisp file, got {path}",
                flush=True,
            )
            sys.exit(1)
        return [path.name]
    if path.is_dir():
        fnames = sorted(p.name for p in path.glob("*.lisp"))
        if len(fnames) == 0:
            print(
                f"Error: no .lisp files found in {path}",
                flush=True,
            )
            sys.exit(1)
        return fnames
    print(
        f"Error: {input_path_str} is not a file or"
        f" directory",
        flush=True,
    )
    sys.exit(1)


def filter_benchmarks(
    fnames: list[str],
    exclude_unreal: bool,
    only_unreal: bool,
) -> list[str]:
    """Filter benchmark filenames by unreal-prefix policy.

    Returns fnames unchanged when both flags are False.  When
    exclude_unreal is True, drops names starting with "unreal-".
    When only_unreal is True, keeps only those names.

    Assumes exclude_unreal and only_unreal are not both True
    (enforced by the argument parser).
    """
    if exclude_unreal:
        return [
            f for f in fnames
            if not f.startswith(UNREAL_PREFIX)
        ]
    if only_unreal:
        return [
            f for f in fnames
            if f.startswith(UNREAL_PREFIX)
        ]
    return fnames


def resolve_tool_ids(args: argparse.Namespace) -> list[str]:
    """Map the parsed variant flag to a list of tool ID strings.

    Returns e.g. ["proph"] for --proph, or all three tool IDs for
    --all.

    Assumes exactly one of --proph, --retro, --no-gen, --all was
    provided (enforced by the argument parser's mutually exclusive
    group).
    """
    if args.all:
        return list(ALL_TOOL_IDS)
    for variant, tool_id in VARIANT_TO_TOOL_ID.items():
        if getattr(args, variant):
            return [tool_id]
    print("Error: no variant specified.", flush=True)
    sys.exit(1)


def build_arg_parser() -> argparse.ArgumentParser:
    """Build the argparse parser for the driver CLI.

    Returns an ArgumentParser with a positional input path, a
    required mutually exclusive variant group (--proph, --retro,
    --no-gen, --all), and an optional mutually exclusive unreal
    filter group (--exclude-unreal, --only-unreal).
    """
    parser = argparse.ArgumentParser(
        description=(
            "Run Cataclyst synthesis benchmarks."
        ),
    )
    parser.add_argument(
        "input",
        help=(
            "Path to a .lisp benchmark file or a"
            " directory of .lisp benchmarks."
        ),
    )

    variant = parser.add_mutually_exclusive_group(
        required=True,
    )
    variant.add_argument(
        "--proph",
        action="store_true",
        help="Prophetic generalization variant.",
    )
    variant.add_argument(
        "--retro",
        action="store_true",
        help="Retroactive generalization variant.",
    )
    variant.add_argument(
        "--no-gen",
        dest="no_gen",
        action="store_true",
        help="No-generalization (brute) variant.",
    )
    variant.add_argument(
        "--all",
        action="store_true",
        help="Run all three variants.",
    )

    unreal = parser.add_mutually_exclusive_group()
    unreal.add_argument(
        "--exclude-unreal",
        action="store_true",
        help="Exclude benchmarks prefixed with 'unreal-'.",
    )
    unreal.add_argument(
        "--only-unreal",
        action="store_true",
        help="Run only benchmarks prefixed with 'unreal-'.",
    )

    return parser


def run_benchmarks(
    fnames: list[str],
    tool_ids: list[str],
) -> None:
    """Run each (benchmark, variant) pair via run.run().

    For each tool_id and fname, calls run.run(fname, tool_id,
    outname, batchtime).  outname is derived from run.OUTPUT_DIR
    as OUTPUT_DIR / "output-{tool_id}" / fname.  batchtime is a
    shared timestamp string for the entire batch.

    Assumes implementation/ is on sys.path so that run and its
    transitive dependencies are importable.
    """
    sys.path.insert(0, str(IMPLEMENTATION_DIR))
    from run import run as run_single
    from run import OUTPUT_DIR

    batchtime = datetime.now().strftime("%Y-%m-%d_%H:%M:%S")
    total = len(fnames) * len(tool_ids)
    completed = 0

    for tool_id in tool_ids:
        for fname in fnames:
            completed += 1
            print(
                f"\n{'=' * 60}\n"
                f"[{completed}/{total}] {fname}"
                f"  (variant: {tool_id})\n"
                f"{'=' * 60}",
                flush=True,
            )
            outname = str(
                OUTPUT_DIR
                / f"output-{tool_id}"
                / fname
            )
            run_single(fname, tool_id, outname, batchtime)


def main() -> None:
    """Entry point: parse args, collect benchmarks, run them.

    Parses CLI arguments, resolves the benchmark list and variant
    list, applies unreal filtering, and delegates to
    run_benchmarks.  Prints the process ID at startup so the user
    can kill the process if it hangs.
    """
    print(f"!kill -9 {os.getpid()}", flush=True)

    parser = build_arg_parser()
    args = parser.parse_args()

    fnames = collect_benchmarks(args.input)
    fnames = filter_benchmarks(
        fnames, args.exclude_unreal, args.only_unreal,
    )
    if len(fnames) == 0:
        print(
            "No benchmarks matched the given filters.",
            flush=True,
        )
        sys.exit(0)

    tool_ids = resolve_tool_ids(args)

    print(
        f"Running {len(fnames)} benchmark(s) with"
        f" {len(tool_ids)} variant(s).",
        flush=True,
    )
    run_benchmarks(fnames, tool_ids)


if __name__ == "__main__":
    main()
