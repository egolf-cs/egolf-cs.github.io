(declare-primitives head <= cons list tail endp)

(set-contata-bench list_sort.mls)

(ld lib/int-list-native.lisp)

(defsig contata-insert-sort (x :int xs :int-list) :int-list)

(fn-property contata-insert-sort
    (x :int xs :int-list)
    _fn
    (=> (sortedp xs) (sortedp _fn)))

(io contata-insert-sort
    (2 nil)
    (list 2))

(io contata-insert-sort
    (0 (list 1))
    (cons 0 (list 1)))

(io contata-insert-sort
    (2 (cons 0 (list 1)))
    (cons 0 (cons 1 (list 2))))
(ld lib/sortedp.lisp)

(ld sketches/contata-list-sort-sk.lisp)
