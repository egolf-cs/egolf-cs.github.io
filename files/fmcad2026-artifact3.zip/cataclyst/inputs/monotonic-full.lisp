(declare-primitives endp head tail szerop 1+)

(ld lib/bit.lisp)
(ld lib/bit-list.lisp)

(definec szerop (b :sbit) :bool
    (equal b 'zero))

(defsig ones (xs :bit-list) :bool)
(defsig monotonic (xs :bit-list) :bool)

(property (
    xs :bit-list)
    (=> (member 'zero xs)
        (not (ones xs))))

(property (
    xs :bit-list)
    (=> (not (member 'zero xs))
        (ones xs)))

(io monotonic (nil) t)
(io monotonic ((cons 'zero nil)) t)
(io monotonic ((cons 'one nil)) t)
(io monotonic ((cons 'zero (cons 'one nil))) t)
(io monotonic ((cons 'zero (cons 'zero nil))) t)
(io monotonic ((cons 'zero (cons 'zero (cons 'one nil)))) t)
(io monotonic ((cons 'zero (cons 'one (cons 'one nil)))) t)
(io monotonic ((cons 'one (cons 'zero nil))) nil)

(prenex (
    (A xs :bit-list)
    (E pre-n (xs :bit-list) :nat)
    (E suf-n (xs :bit-list pre-n :nat) :nat))
    (=> (monotonic xs)
        (equal (append (repeat pre-n 'zero)
                       (repeat suf-n 'one))
               xs)))


(defdata small-nat (range integer (0 <= _ < 20)))

(property (
    n :small-nat
    k :small-nat)
    (monotonic (append (repeat n 'zero)
                       (repeat k 'one))))

(ld sketches/monotonic-sk.lisp)
