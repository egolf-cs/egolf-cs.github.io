(set-contata-bench list_insertion2.mls)

; NOTE: preamble has some auxiliary definitions/specifications common to
; all contata-list-insertion* benchmarks
(ld preambles/contata-list-insertion-pre.lisp)

(property (
    xs :int-list
    x :int
    y :int)
    (=> (member y xs)
        (member y (contata-list-insertion x xs))))

(ld sketches/contata-list-insertion-sk.lisp)
