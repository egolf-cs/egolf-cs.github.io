(set-contata-bench ext-mirror-ternary_test.mls)

(ld contata-mirror-ternary-test.lisp)
(ld preambles/contata-ext-mirror-ternary-test-pre.lisp)

