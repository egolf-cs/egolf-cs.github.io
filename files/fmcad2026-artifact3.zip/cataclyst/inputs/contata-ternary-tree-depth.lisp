(declare-primitives int-cmp max3 1+ tt-left tt-middle tt-right atom)

(set-contata-bench ternary_tree_depth.mls)
(ld lib/compare.lisp)
(ld lib/int-cmp.lisp)
(ld lib/ternary-tree.lisp)
(ld lib/max3.lisp)

(defsig tt-depth (x :ttree) :int)

(defsig tt-cmp (x :ttree x1 :ttree) :compare)

(io tt-depth
    ('leaf)
    0)

(property (
    tr :ttree)
    (equal (tt-depth (list tr 0 'leaf 'leaf))
           (1+ (tt-depth tr))))

(property (
    tr :ttree)
    (equal (tt-depth (list 'leaf 0 tr 'leaf))
           (1+ (tt-depth tr))))

(property (
    tr :ttree)
    (equal (tt-depth (list 'leaf 0 'leaf tr))
           (1+ (tt-depth tr))))

(fn-property tt-cmp
    (x :ttree x1 :ttree)
    _fn
    (=> (equal x x1)
        (equal 'cmp-eq _fn)))

(io tt-cmp
    ('leaf (list 'leaf 0 'leaf 'leaf))
    'cmp-lt)

(io tt-cmp
    ((list 'leaf 0 (list 'leaf 0 'leaf 'leaf) 'leaf) (list 'leaf 0 'leaf 'leaf))
    'cmp-gt)

(io tt-cmp
    ((list (list 'leaf 0 'leaf 'leaf) 0 'leaf 'leaf) (list 'leaf 0 'leaf 'leaf))
    'cmp-gt)

(ld sketches/contata-ternary-tree-depth-sk.lisp)
