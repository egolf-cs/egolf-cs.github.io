(declare-primitives endp equal head tail cons 1+)

(ld lib/int-list-native.lisp)
(ld lib/int-option-native.lisp)
(ld lib/int-list-nth-native.lisp)

(defsig contains (x :int xs :int-list) :bool)

(property (
    x :int)
    (not (contains x nil)))

(property (
    x :int)
    (contains x (cons x nil)))

(property (
    x :int
    y :int
    xs :int-list)
    (=> (contains x xs)
        (contains x (cons y xs))))

(property (
    x :int
    y :int
    xs :int-list)
    (=> (contains x (cons y xs))
        (or (equal x y)
            (contains x xs))))

(prenex (
    (A x :int)
    (A xs :int-list)
    (E index-of (x :int xs :int-list) :nat))
    (=> (contains x xs)
        (equal x (nth index-of xs))))

(property (
    x :int
    xs :int-list
    j :nat)
    (=> (equal x (nth j xs))
        (contains x xs)))


(ld sketches/index-of-contains-sk.lisp)
