(declare-primitives endp head tail equal < 1+)

(ld lib/int-list-native.lisp)
(ld lib/int-option-native.lisp)
(ld lib/int-list-nth-native.lisp)
(ld lib/nat-option-native.lisp)

(defsig prefix-min (x :int xs :int-list) :bool)

(property (x :int)
    (not (prefix-min x nil)))

(property (x :int xs :int-list)
    (prefix-min x (cons x xs)))

(property (x :int y :int xs :int-list)
    (=> (prefix-min x (cons y xs))
             (<= x y)))

(property (x :int y :int xs :int-list)
    (=> 
      (and (prefix-min x (cons y xs))
           (< x y))
      (prefix-min x xs)))

(property (x :int y :int xs :int-list)
    (=>
      (and (prefix-min x xs)
           (< x y))
      (prefix-min x (cons y xs))))

(prenex (
    (A x :int)
    (A xs :int-list)
    (E index-of (x :int xs :int-list) :nat)
    (A j :nat))
    (=> (prefix-min x xs)
        (and (equal x (nth index-of xs))
             (=> (< j index-of)
                 (< x (nth j xs))))))

(prenex (
    (A x :int)
    (A xs :int-list)
    (A i :nat)
    (E anti-index (x :int xs :int-list) :nat))
    (=> (not (prefix-min x xs))
        (or (not (equal x (nth i xs)))
            (and (< anti-index i)
                 (>= x (nth anti-index xs))))))

(ld sketches/prefixmin-sk.lisp)
