(set-contata-bench list_insertion3.mls)

; NOTE: preamble has some auxiliary definitions/specifications common to
; all contata-list-insertion* benchmarks
(ld preambles/contata-list-insertion-pre.lisp)


(property (
    xs :int-list
    x :int
    y :int)
    (=> (and (not (equal x y)) (not (member x xs)))
        (not (member x (contata-list-insertion y xs)))))

(ld sketches/contata-list-insertion-sk.lisp)
