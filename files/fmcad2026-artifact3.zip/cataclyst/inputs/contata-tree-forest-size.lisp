(declare-primitives 1+ + ifnilp itemptyp iftail ifhead itchildren)

(set-contata-bench tree_forest_size.mls)

(ld lib/tree-forest.lisp)

(defsigs (
    (tree-size (x :itree) :nat)
    (forest-size (x1 :iforest) :nat)))

(property (
    f :iforest)
    (< (forest-size f) (tree-size (itnode 0 f))))


(property (
    f :iforest)
    (>= (forest-size (ifcons 'itempty f))
        (forest-size f)))

(io tree-size
    ('itempty)
    0)

(io forest-size
    ('ifnil)
    0)

(io tree-size
    ((itnode 0 'ifnil))
    1)

(io forest-size
    ((ifcons 'itempty 'ifnil))
    0)

(io forest-size
    ((ifcons (itnode 0 'ifnil) 'ifnil))
    1)

(io forest-size
    ((ifcons 'itempty (ifcons 'itempty 'ifnil)))
    0)

(io forest-size
    ((ifcons (itnode 0 'ifnil) (ifcons (itnode 1 'ifnil) 'ifnil)))
    2)

(io forest-size
    ((ifcons 'itempty (ifcons (itnode 1 'ifnil) 'ifnil)))
    1)

(ld sketches/contata-tree-forest-size-sk.lisp)
