; Backup: contata-ext-mirror-ternary-test-pre_20251022_181058.lisp | Transformations: node->list
(ld lib/is-subtree.lisp)

;test forall (x : tree) . forall (y : tree) .
;  implies (
;    is_subtree (x, y),
;    is_subtree (mirror x, mirror y))
;;;
;(test? (=>
;    (and (ttreep x)
;         (ttreep y)
;         (is-subtree x y))
;    (is-subtree (mirror x) (mirror y))))
(property (
    x :ttree
    y :ttree)
    (=> (is-subtree x y)
        (is-subtree (mirror x) (mirror y))))

;
;io mirror (
; Node (
;   Node (Leaf, True, Leaf, Node (Leaf, False, Leaf, Leaf)),
;   False, Leaf, Leaf))
;  -> Node (
;        Leaf, False, Leaf,
;        Node (Node (Leaf, False, Leaf, Leaf), True, Leaf, Leaf)) ;;
;(test? (equal
;    (mirror (node
;        (node 'leaf 1 'leaf (node 'leaf 0 'leaf 'leaf)) 0 'leaf 'leaf))
;    (node
;        'leaf 0 'leaf
;        (node (node 'leaf 0 'leaf 'leaf) 1 'leaf 'leaf))))
(io mirror
    ((list (list 'leaf 1 'leaf (list 'leaf 0 'leaf 'leaf)) 0 'leaf 'leaf))
    (list 'leaf 0 'leaf (list (list 'leaf 0 'leaf 'leaf) 1 'leaf 'leaf)))

;io mirror (
;  Node (Leaf, True,
;    Node (Leaf, True, Leaf, Node (Leaf, True, Leaf, Leaf)),
;    Leaf)) -> Node (Leaf, True,
;      Node (Node (Leaf, True, Leaf, Leaf), True, Leaf, Leaf),
;      Leaf) ;;
;(test? (equal
;    (mirror (node 'leaf 1 (node 'leaf 1 'leaf (node 'leaf 1 'leaf 'leaf)) 'leaf))
;    (node 'leaf 1
;          (node (node 'leaf 1 'leaf 'leaf) 1 'leaf 'leaf)
;          'leaf)))
(io mirror
    ((list 'leaf 1 (list 'leaf 1 'leaf (list 'leaf 1 'leaf 'leaf)) 'leaf))
    (list 'leaf 1 (list (list 'leaf 1 'leaf 'leaf) 1 'leaf 'leaf) 'leaf))