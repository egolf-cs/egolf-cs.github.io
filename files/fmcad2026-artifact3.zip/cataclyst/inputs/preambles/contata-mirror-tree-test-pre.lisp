; Backup: contata-mirror-tree-test-pre_20251022_151521.lisp | Transformations: node->list
(defsig mirror (x :bintree) :bintree)

;io mirror Leaf -> Leaf ;;
;(test? (equal (mirror 'leaf) 'leaf))
(io mirror
    ('leaf)
    'leaf)

;io mirror (Node (Leaf, True, Leaf)) -> Node (Leaf, True, Leaf) ;;
;(test? (equal (mirror (node 'leaf 1 'leaf)) (node 'leaf 1 'leaf)))
(io mirror
    ((list 'leaf 1 'leaf))
    (list 'leaf 1 'leaf))

;io mirror (Node (Node (Leaf, True, Leaf), True, Leaf)) -> Node (Leaf, True, Node (Leaf, True, Leaf)) ;;
;(test? (equal (mirror (node (node 'leaf 1 'leaf) 1 'leaf))
;              (node 'leaf 1 (node 'leaf 1 'leaf))))
(io mirror
    ((list (list 'leaf 1 'leaf) 1 'leaf))
    (list 'leaf 1 (list 'leaf 1 'leaf)))