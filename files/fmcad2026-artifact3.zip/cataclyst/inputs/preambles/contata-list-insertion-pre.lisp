; Backup: contata-list-insertion-pre_20251022_101426.lisp | Transformations: inilp->endp, ihead->head, itail->tail, icons->cons, imember->member, ione->list, inil->nil
(declare-primitives head cons tail endp)

(ld lib/int-list-native.lisp)

(defsig contata-list-insertion (x :int xs :int-list) :int-list)

; Adapted from
; io insert ((| A 0), Cons ((| A 0), Cons ((| A 1), Nil)))
; -> Cons ((| A 0), Cons ((| A 1), Cons ((| A 0), Nil))) ;;
(io contata-list-insertion
    (0 (cons 0 (list 1)))
    (cons 0 (cons 1 (list 0))))
