; Backup: contata-mirror-ternary-test-pre_20251022_153157.lisp | Transformations: node->list
(defsig mirror (tr :ttree) :ttree)

;io mirror Leaf -> Leaf ;;
;(test? (equal 'leaf (mirror 'leaf)))
(io mirror
    ('leaf)
    'leaf)

;io mirror
;    Node(
;         Node(Leaf, False, Leaf, Leaf),
;         True, Leaf, Leaf)
;    -> Node(
;         Leaf, True, Leaf,
;         Node(Leaf, False, Leaf, Leaf)) ;;
;(test? (equal
;    (node (node 'leaf 0 'leaf 'leaf) 1 'leaf 'leaf)
;    (mirror (node 'leaf 1 'leaf (node 'leaf 0 'leaf 'leaf)))))
(io mirror
    ((list 'leaf 1 'leaf (list 'leaf 0 'leaf 'leaf)))
    (list (list 'leaf 0 'leaf 'leaf) 1 'leaf 'leaf))

;io mirror
;    Node(
;        Node(Leaf, True, Leaf, Leaf),
;        False, Leaf, Leaf)
;    -> Node(
;        Leaf, False, Leaf,
;        Node(Leaf, True, Leaf, Leaf)) ;;
;(test? (equal
;    (node (node 'leaf 1 'leaf 'leaf) 0 'leaf 'leaf)
;    (mirror (node 'leaf 0 'leaf (node 'leaf 1 'leaf 'leaf)))))
(io mirror
    ((list 'leaf 0 'leaf (list 'leaf 1 'leaf 'leaf)))
    (list (list 'leaf 1 'leaf 'leaf) 0 'leaf 'leaf))