; Backup: contata-list-removal-pre_20251022_102510.lisp | Transformations: inilp->endp, ihead->head, itail->tail, icons->cons, imember->member, ione->list, inil->nil
(declare-primitives equal head cons tail endp)

(ld lib/int-list-native.lisp)

(defsig contata-remove (x :int xs :int-list) :int-list)

;(test? (equal (contata-remove 0 (icons 1 (ione 0))) (ione 1)))
(io contata-remove
    (0 (cons 1 (list 0)))
    (list 1))

;(test? (equal (contata-remove 0 (icons 0 (ione 1))) (ione 1)))
(io contata-remove
    (0 (cons 0 (list 1)))
    (list 1))
