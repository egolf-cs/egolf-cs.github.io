
(defdata bit-list (listof sbit))

(deflocal bit-listp (x :all) :bool
    (or (endp x)
        (and (consp x)
             (sbitp (head x))
             (bit-listp (tail x)))))

(deflocal repeat (n :nat m :sbit) :bit-list
    (if (zp n)
        '()
        (cons m (repeat (1- n) m))))

(deflocal append (xs :bit-list ys :bit-list) :bit-list
    (if (endp xs)
        ys
        (cons (head xs) (append (tail xs) ys))))



