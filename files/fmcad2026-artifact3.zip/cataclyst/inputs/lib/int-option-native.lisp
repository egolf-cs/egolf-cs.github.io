(defdata int-option (oneof 'none int))
(deflocal int-optionp (x :all) :bool
    (or (equal x 'none)
        (intp x)))


