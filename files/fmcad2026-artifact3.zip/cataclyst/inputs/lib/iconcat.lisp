; Backup: iconcat_20251022_103753.lisp | Transformations: iappend->append, inil->nil, ilnil->nil, ilhead->head, iltail->tail, ilnilp->endp
(definec iconcat (xss :int-list-list) :int-list
    (if (endp xss)
        nil
        (append (head xss) (iconcat (tail xss)))))
