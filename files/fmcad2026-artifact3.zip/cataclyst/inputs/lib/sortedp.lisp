; Backup: sortedp_20251022_102911.lisp | Transformations: inilp->endp, ihead->head, itail->tail, inil->nil
(definec sortedp (xs :int-list) :boolean
    (if (endp xs)
        t
        (if (endp (tail xs))
            t
            (if (<= (head xs) (head (tail xs)))
                (sortedp (tail xs))
                nil))))
