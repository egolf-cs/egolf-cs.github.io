
(defdata int-pair (list int int))

(deflocal int-pairp (x :all) :bool
    (and (consp x)
         (equal (length x) 2)
         (intp (head x))
         (intp (head (tail x)))))


