; Backup: splines_20251022_122815.lisp | Transformations: icons->cons, inil->nil
(definec left-spline (x :bintree) :int-list
    (if (atom x)
        nil
        (cons (bt-value x) (left-spline (bt-left x)))))

(definec right-spline (x :bintree) :int-list
    (if (atom x)
        nil
        (cons (bt-value x) (right-spline (bt-right x)))))
