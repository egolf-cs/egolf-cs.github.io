(definec int-cmp (x :int y :int) :compare
    (if (equal x y)
        'cmp-eq 
        (if (< x y)
            'cmp-lt
            'cmp-gt)))

;(definec int-cmp (x :int y :int) :int
;    (if (equal x y)
;        0
;        (if (< x y)
;            -1
;            1)))

