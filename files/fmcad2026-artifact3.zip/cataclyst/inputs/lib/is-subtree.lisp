; Backup: is-subtree_20251022_181153.lisp | Transformations: leafp->atom
(definec is-subtree (x :ttree y :ttree) :bool
    (if (atom x)
        (atom y)
        (if (atom y)
            nil
            (or (equal x y)
                (is-subtree (tt-left x) y)
                (is-subtree (tt-middle x) y)
                (is-subtree (tt-right x) y)))))
