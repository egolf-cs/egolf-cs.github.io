(definec max3 (x :int y :int z :int) :int
    (max x (max y z)))


