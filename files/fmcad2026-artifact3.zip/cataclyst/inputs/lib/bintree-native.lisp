(defdata bintree (or 'leaf (list bintree int bintree)))

(deflocal bintreep (x :all) :bool
    (or (equal x 'leaf)
        (and (consp x)
             (bintreep (first x))
             (intp (second x))
             (bintreep (third x)))))

(definec bt-left (t1 :bintree) :bintree 
    :ic (consp t1) 
    (first t1))

(definec bt-right (t1 :bintree) :bintree 
    :ic (consp t1)
    (third t1))

(definec bt-value (t1 :bintree) :int
    :ic (consp t1)
    (second t1))
