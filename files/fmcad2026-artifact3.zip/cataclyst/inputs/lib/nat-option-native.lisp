
(defdata nat-option (oneof 'none nat))
(deflocal nat-optionp (x :all) :bool
    (or (equal x 'none)
        (natp x)))


