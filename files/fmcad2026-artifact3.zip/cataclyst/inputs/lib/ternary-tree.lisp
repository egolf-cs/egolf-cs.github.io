(defdata ttree (or 'leaf (list ttree int ttree ttree)))

(deflocal ttreep (x :all) :bool
    (or (equal x 'leaf)
        (and (consp x)
             (ttreep (first x))
             (intp (second x))
             (ttreep (third x))
             (ttreep (fourth x)))))

(definec tt-left (t1 :ttree) :ttree 
    :ic (consp t1) 
    (first t1))
(definec tt-middle (t1 :ttree) :ttree
    :ic (consp t1)
    (third t1))
(definec tt-right (t1 :ttree) :ttree
    :ic (consp t1) 
    (fourth t1))
(definec tt-value (t1 :ttree) :int
    :ic (consp t1)
    (second t1))

