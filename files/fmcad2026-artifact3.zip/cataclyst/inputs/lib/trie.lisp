(defdata trie (or 'leaf (list trie int trie)))

(deflocal triep (x :all) :bool
    (or (equal x 'leaf)
        (and (consp x)
             (triep (first x))
             (intp (second x))
             (triep (third x)))))

(definec trie-left (t1 :trie) :trie 
    :ic (consp t1) 
    (first t1))

(definec trie-right (t1 :trie) :trie 
    :ic (consp t1)
    (third t1))

(definec trie-value (t1 :trie) :int
    :ic (consp t1)
    (second t1))


