(defdata int-list (listof int))

(deflocal int-listp (x :all) :bool
    (or (endp x)
        (and (consp x)
             (intp (head x))
             (int-listp (tail x)))))


