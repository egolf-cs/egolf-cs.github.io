(defdata unary (listof 1))

(deflocal unaryp (x :all) :bool
    (or (endp x)
        (and (consp x)
             (equal (head x) 1)
             (unaryp (tail x)))))

(definec usucc (x :unary) :unary
    (cons 1 x))
