(defdata int-pair-list (listof int-pair))
(deflocal int-pair-listp (x :all) :bool
    (or (endp x)
        (and (consp x)
             (int-pairp (head x))
             (int-pair-listp (tail x)))))


