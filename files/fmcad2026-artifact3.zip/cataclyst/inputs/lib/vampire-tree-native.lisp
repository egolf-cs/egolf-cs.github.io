; IJCAR tree datatype from tree-max.smt2: leaf(leaf0 nat) | node(lc,val,rc).
; Encoding: leaf(k) -> k (int); node(l,k,r) -> (list l k r).
; Mirrors lib/bintree-native.lisp style (defdata, deflocal, definec accessors).
(defdata vtree (or int (list vtree int vtree)))

(deflocal vtreep (x :all) :bool
    (or (intp x)
        (and (consp x)
             (consp (cdr x))
             (consp (cdr (cdr x)))
             (endp (cdr (cdr (cdr x))))
             (vtreep (first x))
             (intp (second x))
             (vtreep (third x)))))

(definec vt-left (tr :vtree) :vtree
    :ic (and (vtreep tr) (consp tr))
    (first tr))

(definec vt-node-val (tr :vtree) :int
    :ic (and (vtreep tr) (consp tr))
    (second tr))

(definec vt-right (tr :vtree) :vtree
    :ic (and (vtreep tr) (consp tr))
    (third tr))

; Leaf trees are encoded as int; this is the identity on that case.
(definec vt-leaf-val (tr :vtree) :int
    :ic (and (vtreep tr) (intp tr))
    tr)
