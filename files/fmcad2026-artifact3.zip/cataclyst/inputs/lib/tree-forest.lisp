(declare-datatypes (
    (itree 0)
    (iforest 0)) (

    (
        (itempty)
        (itnode (itval int) (itchildren iforest)))

    (
        (ifnil)
        (ifcons (ifhead itree) (iftail iforest)))))
