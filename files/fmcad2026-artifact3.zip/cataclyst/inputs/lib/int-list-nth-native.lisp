(deflocal nth (n :nat xs :int-list) :int-option
    (if (endp xs)
        'none
        (if (equal n 0)
            (head xs)
            (nth (1- n) (tail xs)))))


