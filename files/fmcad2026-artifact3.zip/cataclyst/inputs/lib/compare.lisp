;(declare-datatype compare (
;    (cmp-lt)
;    (cmp-eq)
;    (cmp-gt)))

(defdata compare (enum '(cmp-lt cmp-eq cmp-gt)))
