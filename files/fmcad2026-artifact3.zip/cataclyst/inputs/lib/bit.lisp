
(defdata sbit (oneof 'zero 'one))
(deflocal sbitp (x :all) :bool
    (or (equal x 'zero)
        (equal x 'one)))


