(defdata int-list-list (listof int-list))

(deflocal int-list-listp (x :all) :bool
    (or (endp x)
        (and (consp x)
             (int-listp (head x))
             (int-list-listp (tail x)))))
