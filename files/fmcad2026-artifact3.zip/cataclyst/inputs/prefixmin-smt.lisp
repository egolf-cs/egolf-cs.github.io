(declare-primitives endp head tail equal < 1+)

(ld lib/int-list-native.lisp)
(ld lib/int-list-nth-native.lisp)

(defsig prefix-min (x :int xs :int-list) :bool)

(smt smt/prefixmin-p1.lisp)
(smt smt/prefixmin-p2.lisp)

(ld sketches/prefixmin-sk-smt.lisp)
