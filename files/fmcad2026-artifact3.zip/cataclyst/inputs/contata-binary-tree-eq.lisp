(declare-primitives equal and bt-value atom bt-left bt-right)

(set-contata-bench binary_tree_eq.mls)
(ld lib/bintree-native.lisp)

(defsig binary-tree-eq (t1 :bintree t2 :bintree) :bool)

(property (
    t1 :bintree)
    (binary-tree-eq t1 t1))

(property (
    t1 :bintree
    t2 :bintree)
    (=> (binary-tree-eq t1 t2)
        (binary-tree-eq t2 t1)))

(property (
    t1 :bintree
    t2 :bintree
    x :int)
    (not (binary-tree-eq t1 (list t1 x t2))))

(io binary-tree-eq
    ((list 'leaf 0 (list 'leaf 3 'leaf)) (list 'leaf 0 (list 'leaf 3 'leaf)))
    t)

(io binary-tree-eq
    ((list 'leaf 0 (list 'leaf 1 'leaf)) (list 'leaf 0 (list 'leaf 3 'leaf)))
    nil)

(io binary-tree-eq
    ((list 'leaf 0 (list 'leaf 1 'leaf)) (list 'leaf 0 (list 'leaf 1 'leaf)))
    t)

(ld sketches/contata-binary-tree-eq-sk.lisp)
