(declare-primitives endp tail)

(set-contata-bench even_odd.mls)

(ld lib/unary.lisp)

(defsigs (
    (is-even (x :unary) :bool)
    (is-odd (x :unary) :bool)))

(property
    (x :unary)
    (equal (is-odd (usucc x))
           (is-even x)))

(property
    (x :unary)
    (equal (is-odd x)
           (not (is-odd (usucc x)))))

(io is-even
    (nil)
    t)

(ld sketches/contata-even-odd-sk.lisp)
