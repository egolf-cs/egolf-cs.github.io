(declare-primitives endp head tail equal)

(ld lib/int-list-native.lisp)

(defsig prefixb (xs :int-list ys :int-list) :bool)

; completeness
(property (
    xs :int-list
    ys :int-list
    zs :int-list)
    (=> (equal ys (append xs zs))
        (prefixb xs ys)))

; soundness
(smt smt/prefixb.lisp)

(ld sketches/prefixb-sk-smt.lisp)
