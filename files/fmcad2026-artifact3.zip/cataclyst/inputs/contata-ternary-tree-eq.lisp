(declare-primitives equal tt-right tt-value and atom tt-left tt-middle)

(set-contata-bench ternary_tree_eq.mls)
(defsig ttree-eq (t1 :ttree t2 :ttree) :bool)

(ld lib/ternary-tree.lisp)

(property (
    t1 :ttree)
    (ttree-eq t1 t1))

(property (
    t1 :ttree
    t2 :ttree)
    (=> (ttree-eq t1 t2)
        (ttree-eq t2 t1)))

(io ttree-eq
    ((list 'leaf 0 'leaf 'leaf) (list 'leaf 0 'leaf (list 'leaf 1 'leaf 'leaf)))
    nil)

(ld sketches/contata-ternary-tree-eq-sk.lisp)
