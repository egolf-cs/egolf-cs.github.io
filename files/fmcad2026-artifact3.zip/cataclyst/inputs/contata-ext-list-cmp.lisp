(set-contata-bench ext-list_cmp.mls)
(ld contata-list-cmp.lisp)

(property (
    x :int
    y :int
    z :int)
    (=> (equal 'cmp-eq (list-cmp (cons x (list y)) (cons x (list z))))
        (equal y z)))
