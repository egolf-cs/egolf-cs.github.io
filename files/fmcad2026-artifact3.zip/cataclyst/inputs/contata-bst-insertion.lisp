(declare-primitives equal list bt-value atom bt-left bt-right <)

(set-contata-bench bst_insertion.mls)
(defsig contata-insert (x :int tr :bintree) :bintree)

(ld lib/bintree-native.lisp)

(definec bst-lookup (x :int tr :bintree) :boolean
    (if (atom tr)
        nil
        (if (equal x (bt-value tr))
            t
            (if (< x (bt-value tr))
                (bst-lookup x (bt-left tr))
                (bst-lookup x (bt-right tr))))))

(fn-property contata-insert
    (x :int tr :bintree)
    _fn
(bst-lookup x _fn))

(property (
    tr :bintree
    x :int
    y :int)
    (=> (bst-lookup x tr)
        (bst-lookup x (contata-insert y tr))))

(io contata-insert
    (0 (list 'leaf 1 'leaf))
    (list (list 'leaf 0 'leaf) 1 'leaf))

(io contata-insert
    (1 (list 'leaf 0 'leaf))
    (list 'leaf 0 (list 'leaf 1 'leaf)))

(ld sketches/contata-bst-insertion-sk.lisp)
