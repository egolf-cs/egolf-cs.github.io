(declare-primitives tail endp)

(set-contata-bench parenthesis_match.mls)

(defdata paren (enum '(left right)))
(deflocal parenp (x :all) :bool
    (or (equal x 'left)
        (equal x 'right)))
(defdata parenthesis-list (listof paren))
(deflocal parenthesis-listp (x :all) :bool
    (or (endp x)
        (and (consp x)
             (parenp (head x))
             (parenthesis-listp (tail x)))))

(defsigs (
    (is-open (x :parenthesis-list) :bool)
    (is-close (x :parenthesis-list) :bool)))

; Note: the contata benchmark does not actually have anything
; to do with the traditional notion of open/closed parentheses,
; we have faithfully translated their spec below.


(property
    (x :parenthesis-list)
    (equal (is-open x)
           (not (is-close x))))

(io is-open
    (nil)
    t)

(io is-close
    (nil)
    nil)

(io is-close
    ((list 'right))
    t)

(io is-open
    ((list 'left))
    nil)

(io is-open
    ((cons 'left (list 'right)))
    t)

(io is-close
    ((cons 'left (list 'right)))
    nil)

(io is-open
    ((cons 'left (cons 'right (list 'right))))
    nil)

(ld sketches/contata-parenthesis-sk.lisp)
