(set-contata-bench ext-list_eq.mls)
(ld contata-list-eq.lisp)

(property (
    x :int
    y :int
    z :int)
    (=> (list-eq (cons x (list y)) (cons x (list z)))
        (equal y z)))
