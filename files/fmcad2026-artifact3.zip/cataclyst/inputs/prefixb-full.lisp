(declare-primitives endp head tail equal)

(ld lib/int-list-native.lisp)

(defsig prefixb (xs :int-list ys :int-list) :bool)

(property (
    xs :int-list)
    (prefixb xs xs))

(property (
    xs :int-list)
    (prefixb nil xs))

(property (
    x :int
    xs :int-list)
    (not (prefixb (cons x xs) nil)))

(property (
    x :int
    y :int
    xs :int-list
    ys :int-list)
    (=> (not (equal x y))
        (not (prefixb (cons x xs) (cons y ys)))))

;completeness
(property (
    xs :int-list
    ys :int-list
    zs :int-list)
    (=> (equal ys (append xs zs))
        (prefixb xs ys)))

;soundness
(prenex (
    (A xs :int-list)
    (A ys :int-list)
    (E suffix (xs :int-list ys :int-list) :int-list))
    (=> (prefixb xs ys)
        (equal ys (append xs suffix))))

(ld sketches/prefixb-sk.lisp)
