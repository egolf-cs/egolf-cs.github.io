(declare-primitives cons list head tail endp)

(set-contata-bench zip_same_len.mls)

(ld lib/int-list-native.lisp)
(ld lib/int-pair-native.lisp)
(ld lib/int-pair-list-native.lisp)

(defsig my-zip (xs :int-list ys :int-list) :int-pair-list)


(io my-zip
    ((cons 1 nil) (cons 2 nil))
    (cons (list 1 2) nil))


(fn-property my-zip
    (xs :int-list ys :int-list)
    _fn
    (equal (length _fn) (min (length xs) (length ys))))

(ld sketches/contata-zip-same-len-sk.lisp)
