(declare-primitives itemptyp ifnilp itchildren ifhead iftail +)

(ld lib/tree-forest.lisp)

(set-contata-bench tree_forest_leaves.mls)
; Note: naming convention slightly different between us and contata
; contata.Empty is equivalent to our 'itempty (an empty tree)
; contata.Leaf is equivalent to our 'ifnil (an empty list of trees)
; Their benchmark counts the number of empty sub-forests, rather
; than the number of empty trees and we do the same. 

(defsigs (
    (count-leaves-tree (tr :itree) :nat)
    (count-leaves-forest (fr :iforest) :nat)))

(property (
    f :iforest)
    (equal (count-leaves-forest f)
           (count-leaves-tree (itnode 0 f))))

(property (
    f :iforest)
    (equal (count-leaves-forest f)
           (count-leaves-forest (ifcons 'itempty f))))

(io count-leaves-tree
    ('itempty)
    0)

(io count-leaves-forest
    ('ifnil)
    1)

(io count-leaves-tree
    ((itnode 0 'ifnil))
    1)

(io count-leaves-forest
    ((ifcons 'itempty 'ifnil))
    1)

(io count-leaves-forest
    ((ifcons (itnode 0 'ifnil) 'ifnil))
    2)

(io count-leaves-forest
    ((ifcons 'itempty (ifcons 'itempty 'ifnil)))
    1)

(io count-leaves-forest
    ((ifcons (itnode 0 'ifnil) (ifcons (itnode 1 'ifnil) 'ifnil)))
    3)

(io count-leaves-forest
    ((ifcons 'itempty (ifcons (itnode 1 'ifnil) 'ifnil)))
    2)


(ld sketches/contata-tree-forest-leaves-sk.lisp)
