(set-contata-bench list_insertion.mls)

; NOTE: preamble has some auxiliary definitions/specifications common to
; all contata-list-insertion* benchmarks
(ld preambles/contata-list-insertion-pre.lisp)

(fn-property contata-list-insertion
    (x :int xs :int-list)
    _fn
    (member x _fn))

(ld sketches/contata-list-insertion-sk.lisp)
