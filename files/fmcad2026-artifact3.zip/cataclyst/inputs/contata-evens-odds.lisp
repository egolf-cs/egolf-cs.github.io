(declare-primitives head cons tail endp)

(set-contata-bench evens_odds.mls)
(ld lib/int-list-native.lisp)

(defsigs (
    (ilevens (x :int-list) :int-list)
    (ilodds (x :int-list) :int-list)
))

(property (
    x :int
    xs :int-list)
    (equal (ilodds (cons x xs)) (ilevens xs)))

(io ilevens
    (nil)
    nil)

(io ilodds
    (nil)
    nil)

(io ilevens
    ((list 0))
    (list 0))

(io ilodds
    ((list 0))
    nil)

(io ilevens
    ((cons 0 (list 1)))
    (list 0))

(io ilodds
    ((cons 0 (list 1)))
    (list 1))

(io ilevens
    ((cons 0 (cons 1 (list 2))))
    (cons 0 (list 2)))

(ld sketches/contata-evens-odds-sk.lisp)
