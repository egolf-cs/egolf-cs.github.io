(set-contata-bench list_removal2.mls)

; NOTE: preamble has some auxiliary definitions/specifications common to
; all contata-list-removal* benchmarks
(ld preambles/contata-list-removal-pre.lisp)

(property (
    xs :int-list
    x :int
    y :int)
    (=> (and (not (equal x y)) (member y xs))
        (member y (contata-remove x xs))))

(ld sketches/contata-list-removal-sk.lisp)
