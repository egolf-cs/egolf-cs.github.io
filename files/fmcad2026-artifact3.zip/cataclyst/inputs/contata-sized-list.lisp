(declare-primitives list 1+ get-size)
(set-contata-bench sized_list.mls)

;type list = mu list .
;  | Nil of nat
;  | Cons of (A * nat * list)
;type t = list
(defdata sized-list (oneof nat (list nat int sized-list)))
(deflocal sized-listp (x :all) :bool
    (or (natp x)
        (and (consp x)
             (natp (first x))
             (intp (second x))
             (sized-listp (third x)))))

(defsig insert (xs :sized-list x :int) :sized-list)

(definec get-size (ys :sized-list) :nat
    (if (natp ys)
        ys
        (first ys)))

(definec invariant (ys :sized-list) :bool
    :skip-admissibilityp t
    (if (natp ys)
        t
        (let ((xs (third ys)))
            (if (invariant xs)
                (< (get-size xs) (get-size ys))
                nil))))

(fn-property insert ; function name
    (xs :sized-list x :int) ; function args
    _fn ; function placeholder
    (=> (invariant xs)
        (invariant _fn))) ; predicate over args and placeholder
     

(io insert
    (0 0)
    (list 1 0 0))

(io insert
    ((list 1 0 0) 1)
    (list 2 1 (list 1 0 0)))

(ld sketches/contata-sized-list-sk.lisp)
