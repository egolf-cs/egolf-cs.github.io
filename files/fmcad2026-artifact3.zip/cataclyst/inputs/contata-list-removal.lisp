(set-contata-bench list_removal.mls)

; NOTE: preamble has some auxiliary definitions/specifications common to
; all contata-list-removal* benchmarks
(ld preambles/contata-list-removal-pre.lisp)

(fn-property contata-remove
    (x :int xs :int-list)
    _fn
    (not (member x _fn)))

(ld sketches/contata-list-removal-sk.lisp)
