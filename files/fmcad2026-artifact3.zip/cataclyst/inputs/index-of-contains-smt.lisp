(declare-primitives endp equal head tail cons 1+)

(ld lib/int-list-native.lisp)
(ld lib/int-option-native.lisp)
(ld lib/int-list-nth-native.lisp)

(defsig contains (x :int xs :int-list) :bool)

; completeness
(property (
    x :int
    xs :int-list
    j :nat)
    (=> (equal x (nth j xs))
        (contains x xs)))

; soundness
(smt smt/index-of-contains.lisp)


(ld sketches/index-of-contains-sk-smt.lisp)
