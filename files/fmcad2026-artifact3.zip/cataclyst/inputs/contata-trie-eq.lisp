(declare-primitives equal trie-value and trie-right atom trie-left)

(set-contata-bench trie_eq.mls)

; Based on ContataArtifactEvaluation/reccomp/trie-eq.lisp Note: we are aware
; that these tries are isomorphic to those in binary_tree_eq, but we are using
; the same structure as Contata.
(ld lib/trie.lisp)

(defsig trie-eq (t1 :trie t2 :trie) :bool)

(property (
    t1 :trie)
    (trie-eq t1 t1))

(property (
    t1 :trie)
    (not (trie-eq (list t1 0 t1) (list t1 1 t1))))

(property (
    t1 :trie)
    (not (trie-eq t1 (list t1 0 t1))))

(fn-property trie-eq
    (t1 :trie t2 :trie)
    _fn
    (=> (and (atom t1) (consp t2))
        (not _fn)))

(ld sketches/contata-trie-eq-sk.lisp)
