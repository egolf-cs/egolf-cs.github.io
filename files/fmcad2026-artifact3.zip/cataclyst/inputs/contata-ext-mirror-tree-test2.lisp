(set-contata-bench ext-mirror_tree_test2.mls)

(ld contata-mirror-tree-test2.lisp)
(ld lib/int-list-native.lisp)
(ld lib/splines.lisp)

(fn-property mirror ; function name
    (x :bintree) ; function args
    _fn ; function placeholder
    (equal (left-spline x)
           (right-spline (mirror x)))) ; predicate over args and placeholder

(fn-property mirror ; function name
    (x :bintree) ; function args
    _fn ; function placeholder
    (equal (right-spline x)
           (left-spline (mirror x)))) ; predicate over args and placeholder
