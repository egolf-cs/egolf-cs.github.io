(declare-primitives endp tail)

(set-contata-bench even_odd2.mls)

(ld lib/unary.lisp)

(defsigs (
    (is-even (x :unary) :bool)
    (is-odd (x :unary) :bool)))

(property
    (x :unary)
    (equal (is-odd (usucc (usucc x)))
           (is-even (usucc x))))

(property
    (x :unary)
    (equal (is-even x)
           (not (is-even (usucc x)))))

(io is-odd
    (nil)
    nil)

(ld sketches/contata-even-odd-sk.lisp)
