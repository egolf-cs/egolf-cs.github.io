(declare-primitives head list-eq tail endp)

(set-contata-bench nested_list_eq.mls)
(ld lib/int-list-native.lisp)
(ld lib/int-list-list-native.lisp)

;Note: Contata also uses list-eq as a primitive, they call it list-cmp
(definec list-eq (xs :int-list ys :int-list) :bool
    (equal xs ys))

(defsig nested-list-eq (xss :int-list-list yss :int-list-list) :bool)

(property (
    xss :int-list-list)
    (nested-list-eq xss xss))

(fn-property nested-list-eq
    (xss :int-list-list yss :int-list-list)
    _fn
    (=> (and (consp xss) (consp yss) (endp (tail xss)) (endp (tail yss)) (not (list-eq (head xss) (head yss))))
        (not _fn)))

(fn-property nested-list-eq
    (xss :int-list-list yss :int-list-list)
    _fn
    (=> (and (consp xss) (endp (tail xss)) (endp yss))
        (not _fn)))

(ld sketches/contata-nested-list-eq-sk.lisp)
