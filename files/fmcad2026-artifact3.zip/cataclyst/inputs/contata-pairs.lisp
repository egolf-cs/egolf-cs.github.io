(declare-primitives head tail cons list endp)
(set-contata-bench pairs.mls)

(ld lib/int-list-native.lisp)
(ld lib/int-pair-native.lisp)
(ld lib/int-pair-list-native.lisp)

(definec pairs-inv (xys :int-pair-list) :int-list
    (if (endp xys)
        nil
        (cons (first (head xys))
              (cons (second (head xys))
                    (pairs-inv (tail xys))))))

(definec is-even (n :nat) :bool
    (if (zp n)
        t
        (if (zp (1- n))
            nil
            (is-even (1- (1- n))))))

(defsig pairs (xs :int-list) :int-pair-list)

(fn-property pairs ; function name
    (xs :int-list) ; function args
    _fn ; function placeholder
    (=> (is-even (length xs))
        (equal (pairs-inv _fn) xs))) ; predicate over args and placeholder

(ld sketches/contata-pairs-sk.lisp)
