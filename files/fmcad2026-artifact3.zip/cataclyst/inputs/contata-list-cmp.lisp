(declare-primitives head <= tail endp)

(set-contata-bench list_cmp.mls)
(ld lib/int-list-native.lisp)
(ld lib/compare.lisp)

(defsig list-cmp (xs :int-list ys :int-list) :compare)

(fn-property list-cmp
    (xs :int-list ys :int-list)
    _fn
    (=> (equal xs ys)
        (equal 'cmp-eq _fn)))

(fn-property list-cmp
    (xs :int-list ys :int-list)
    _fn
    (=> (and (consp xs) (endp (tail xs)) (endp ys))
        (equal 'cmp-gt _fn)))

(fn-property list-cmp
    (xs :int-list ys :int-list)
    _fn
    (=> (and (consp ys) (endp (tail ys)) (endp xs))
        (equal 'cmp-lt _fn)))

(io list-cmp
    ((list 0) (list 1))
    'cmp-lt)

(io list-cmp
    ((list 1) (list 0))
    'cmp-gt)

(ld sketches/contata-list-cmp-sk.lisp)
