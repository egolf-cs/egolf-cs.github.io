(declare-primitives tt-right tt-value list atom tt-left tt-middle)
(set-contata-bench mirror_ternary_test2.mls)

(ld lib/ternary-tree.lisp)
(ld preambles/contata-mirror-ternary-test-pre.lisp)

(property 
    (x :ttree)
    (equal x (mirror (mirror (mirror (mirror x))))))


(property 
    (x :ttree)
    (equal (mirror x) (mirror (mirror (mirror x)))))

(ld sketches/contata-mirror-ternary-test-sk.lisp)
