(declare-primitives equal head tail endp)

(set-contata-bench list_eq.mls)
(ld lib/int-list-native.lisp)

(defsig list-eq (xs :int-list ys :int-list) :bool)

(property (
    xs :int-list)
    (list-eq xs xs))

(fn-property list-eq
    (xs :int-list ys :int-list)
    _fn
    (=> (and (consp xs) 
             (consp ys) 
             (endp (tail xs)) 
             (endp (tail ys)) 
             (not (equal (head xs) (head ys))))
        (not _fn)))

(fn-property list-eq
    (xs :int-list ys :int-list)
    _fn
    (=> (and (consp xs) (endp (tail xs)) (endp ys))
        (not _fn)))

(ld sketches/contata-list-eq-sk.lisp)
