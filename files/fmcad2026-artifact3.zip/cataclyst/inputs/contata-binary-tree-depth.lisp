(declare-primitives int-cmp max 1+ bt-left bt-right atom)

(set-contata-bench binary_tree_depth.mls)
(ld lib/compare.lisp)
(ld lib/int-cmp.lisp)
(ld lib/bintree-native.lisp)

(defsig bt-depth (x :bintree) :int)

(defsig bt-cmp (x :bintree x1 :bintree) :compare)

(io bt-depth
    ('leaf)
    0)

(property (
    tr :bintree)
    (equal (bt-depth (list tr 0 'leaf)) (1+ (bt-depth tr))))

(property (
    tr :bintree)
    (equal (bt-depth (list 'leaf 0 tr)) (1+ (bt-depth tr))))

(fn-property bt-cmp
    (x :bintree x1 :bintree)
    _fn
    (=> (equal x x1)
        (equal 'cmp-eq _fn)))

(fn-property bt-cmp
    (x :bintree x1 :bintree)
    _fn
    (equal _fn (int-cmp (bt-depth x) (bt-depth x1))))

(ld sketches/contata-binary-tree-depth-sk.lisp)
