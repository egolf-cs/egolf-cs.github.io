(declare-primitives tt-right tt-value list atom tt-left tt-middle)

(set-contata-bench mirror_ternary_test.mls)
(ld lib/ternary-tree.lisp)
(ld preambles/contata-mirror-ternary-test-pre.lisp)

(property (
    x :ttree)
    (equal x (mirror (mirror x))))

(ld sketches/contata-mirror-ternary-test-sk.lisp)
