(set-contata-bench ext-nested_list_eq.mls)
(ld contata-nested-list-eq.lisp)

(fn-property nested-list-eq
    (xss :int-list-list yss :int-list-list)
    _fn
    (=> (and (endp xss) (consp yss) (endp (tail yss)))
        (not _fn)))

(property (
    xs :int-list
    ys :int-list
    zs :int-list)
    (=> (nested-list-eq (cons xs (list ys)) (cons xs (list zs)))
        (list-eq ys zs)))
