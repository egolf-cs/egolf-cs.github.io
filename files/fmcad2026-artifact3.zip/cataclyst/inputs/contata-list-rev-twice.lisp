(declare-primitives head append tail endp cons)

(set-contata-bench list_rev_twice.mls)
(ld lib/int-list-native.lisp)

(defsig my-rev (xs :int-list) :int-list)

(io my-rev
    (nil)
    nil)

(io my-rev
    ((list 0))
    (list 0))

(io my-rev
    ((cons 1 (list 0)))
    (cons 0 (list 1)))

(io my-rev
    ((cons 2 (cons 1 (list 0))))
    (cons 0 (cons 1 (list 2))))

(property (
    xs :int-list)
    (equal (my-rev (my-rev xs)) xs))

(ld sketches/contata-list-rev-twice-sk.lisp)
