(declare-primitives endp head tail szerop 1+)

(ld lib/bit.lisp)
(ld lib/bit-list.lisp)

(definec szerop (b :sbit) :bool
    (equal b 'zero))

(defsig ones (xs :bit-list) :bool)
(defsig monotonic (xs :bit-list) :bool)

(property (
    xs :bit-list)
    (=> (member 'zero xs)
        (not (ones xs))))

(property (
    xs :bit-list)
    (=> (not (member 'zero xs))
        (ones xs)))

; using small-nats for cex generation
(defdata small-nat (range integer (0 <= _ < 20)))
(deflocal small-natp (x :all) :bool
    (natp x))
(property (
    n :small-nat
    k :small-nat)
    (monotonic (append (repeat n 'zero)
                       (repeat k 'one))))

(smt smt/monotonic.lisp)


(ld sketches/monotonic-sk-smt.lisp)
