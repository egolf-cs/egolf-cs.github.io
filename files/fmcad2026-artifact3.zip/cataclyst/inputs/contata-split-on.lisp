(declare-primitives equal head carcons cons list tail endp)

(set-contata-bench split_on.mls)
(ld lib/int-list-native.lisp)
(ld lib/int-list-list-native.lisp)
(ld lib/iconcat.lisp)

(defsig split-on-zero (xs :int-list) :int-list-list)

(fn-property split-on-zero
    (xs :int-list)
    _fn
    (equal xs (iconcat _fn)))

(io split-on-zero
    ((cons 1 (cons 0 (list 2))))
    (cons (list 1) (cons (list 0) (list (list 2)))))

(io split-on-zero
    ((cons 1 (cons 2 (list 3))))
    (list (cons 1 (cons 2 (list 3)))))

(ld sketches/contata-split-on-sk.lisp)
