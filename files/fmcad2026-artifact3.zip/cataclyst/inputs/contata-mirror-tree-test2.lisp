(declare-primitives list bt-right atom bt-value bt-left)
(set-contata-bench mirror_tree_test2.mls)

(ld lib/bintree-native.lisp)
(ld preambles/contata-mirror-tree-test-pre.lisp)

(property 
    (x :bintree)
    (equal (mirror (mirror (mirror (mirror x)))) x))

(property 
    (x :bintree)
    (equal (mirror (mirror (mirror x))) (mirror x)))

(ld sketches/contata-mirror-tree-test-sk.lisp)
