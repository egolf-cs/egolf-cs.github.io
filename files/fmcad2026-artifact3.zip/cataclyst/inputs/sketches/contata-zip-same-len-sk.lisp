(set-subexpr-bound 5)

(deftgt my-zip (xs :int-list ys :int-list) :int-pair-list
    (if (endp xs)
        nil
        (if (endp ys)
            nil
            (cons (list (head xs) (head ys))
                  (my-zip (tail xs) (tail ys))))))

(defmeasure m (xs :int-list ys :int-list) :nat
    (acl2s-size xs))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (cons ???5 (my-zip ???6 ???7)))))

(defhole ???1 :bool (B))
(defhole ???2 :int-pair-list (PLIST))
(defhole ???3 :bool (B))
(defhole ???4 :int-pair-list (PLIST))
(defhole ???5 :int-pair (PAIR))
(defhole ???6 :int-list (LIST))
(defhole ???7 :int-list (LIST))
(defnt B (
    (endp LIST)))
(defnt INT (
    (head LIST)))
(defnt PAIR (
    (list INT INT)))
(defnt LIST (
    nil
    xs
    ys
    (cons INT LIST)
    (tail LIST)))
(defnt PLIST (
    nil
    (cons PAIR PLIST)
    (tail PLIST)))
