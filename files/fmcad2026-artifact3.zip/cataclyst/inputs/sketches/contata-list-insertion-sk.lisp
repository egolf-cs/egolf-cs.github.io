(deftgt contata-list-insertion (x :int xs :int-list) :int-list
    (if (endp xs)
        (cons x nil)
        (cons (head xs) (contata-list-insertion x (tail xs)))))

(defmeasure m (x :int xs :int-list) :nat
    (acl2s-size xs))

(defsketch ???2)
(defsketch (if ???1 ???2 (contata-list-insertion ???4 ???5)))
(defsketch-tgt
    (if ???1
        ???2
        (cons ???3 (contata-list-insertion ???4 ???5))))

(defhole ???1 :bool (B))
(defhole ???2 :int-list (INT-LIST))
(defhole ???3 :int (INT))
(defhole ???4 :int (INT))
(defhole ???5 :int-list (INT-LIST))

(defnt B (
    (endp INT-LIST)))
(defnt INT-LIST (
    nil
    xs
    (tail INT-LIST)
    (cons INT INT-LIST)))
(defnt INT (
    0
    x
    (head INT-LIST)))
