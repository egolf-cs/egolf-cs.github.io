(set-subexpr-bound 5)
(deftgt list-eq (xs :int-list ys :int-list) :bool
    (if (endp xs)
        (endp ys)
        (if (endp ys)
            nil
            (if (equal (head xs) (head ys))
                (list-eq (tail xs) (tail ys))
                nil))))

(defmeasure m (xs :int-list ys :int-list) :nat
    (acl2s-size xs))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (if ???5
                (list-eq ???6 ???7)
                ???8))))

(defhole ???1 :bool (B))
(defhole ???2 :bool (FALSE B))
(defhole ???3 :bool (B))
(defhole ???4 :bool (FALSE B))
(defhole ???5 :bool (B))
(defhole ???6 :int-list (LIST))
(defhole ???7 :int-list (LIST))
(defhole ???8 :bool (FALSE B))
(defnt FALSE (
    nil))
(defnt B (
    (endp LIST)
    (equal INT INT :distinct)))
(defnt INT (
    (head LIST)))
(defnt LIST (
    xs
    ys
    (tail LIST)))
