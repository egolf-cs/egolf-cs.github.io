
(deftgt tree-size (x :itree) :nat
    (if (itemptyp x)
        0
        (1+ (forest-size (itchildren x)))))
(deftgt forest-size (x1 :iforest) :nat
    (if (ifnilp x1)
        0
        (+ (tree-size (ifhead x1)) (forest-size (iftail x1)))))


(defmeasure m (x :all) :nat
    (acl2s-size x))

(defsketch
    (if ???1
        ???2
        (tree-size ???3a))
    tree-size)
(defsketch
    (if ???1
        ???2
        (1+ (tree-size ???3a)))
    tree-size)
 (defsketch
    (if ???1
        ???2
        (1+ (forest-size ???3)))
    tree-size)
(defsketch
    (if ???1
        ???2
        (+ (forest-size ???3) (tree-size ???3a)))
    tree-size)
(defsketch-tgt
    (if ???1
        ???2
        (1+ (forest-size ???3)))
    tree-size)

(defsketch
    (if ???4
        ???5
        (forest-size ???7))
    forest-size)
(defsketch
    (if ???4
        ???5
        (1+ (forest-size ???7)))
    forest-size)
(defsketch
    (if ???4
        ???5
        (1+ (tree-size ???6)))
    forest-size)
(defsketch
    (if ???4
        ???5
        (forest-size ???7))
    forest-size)
(defsketch-tgt
    (if ???4
        ???5
        (+ (tree-size ???6) (forest-size ???7)))
    forest-size)

(defhole ???1 :bool (B) tree-size)
(defhole ???2 :nat (N) tree-size)
(defhole ???3 :iforest (FOREST) tree-size)
(defhole ???3a :itree (TREE) tree-size)

(defhole ???4 :bool (B1) forest-size)
(defhole ???5 :nat (N) forest-size)
(defhole ???6 :itree (TREE1) forest-size)
(defhole ???7 :iforest (FOREST1) forest-size)

(defnt N (
    0 1))

(defnt B (
    (itemptyp TREE)
    (ifnilp FOREST)))
(defnt TREE (
    'itempty
    x
    (ifhead FOREST)))
(defnt FOREST (
    'ifnil
    (iftail FOREST)
    (itchildren TREE)))

(defnt B1 (
    (itemptyp TREE1)
    (ifnilp FOREST1)))
(defnt TREE1 (
    'itempty
    (ifhead FOREST1)))
(defnt FOREST1 (
    'ifnil
    x1
    (iftail FOREST1)
    (itchildren TREE1)))


