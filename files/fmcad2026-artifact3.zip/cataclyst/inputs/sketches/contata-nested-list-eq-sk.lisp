(set-subexpr-bound 5)

(deftgt nested-list-eq (xss :int-list-list yss :int-list-list) :bool
    (if (endp xss)
        (endp yss)
        (if (endp yss)
            nil
            (if (list-eq (head xss) (head yss))
                (nested-list-eq (tail xss) (tail yss))
                nil))))

(defmeasure m (xss :int-list-list yss :int-list-list) :nat
    (acl2s-size xss))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (if ???5
                (nested-list-eq ???6 ???7)
                ???8))))

(defhole ???1 :bool (B))
(defhole ???2 :bool (NIL B))
(defhole ???3 :bool (B))
(defhole ???4 :bool (NIL B))
(defhole ???5 :bool (B))
(defhole ???6 :int-list-list (LIST-LIST))
(defhole ???7 :int-list-list (LIST-LIST))
(defhole ???8 :bool (NIL B))
(defnt B (
    (endp LIST-LIST)
    (list-eq LIST LIST :distinct)))
(defnt NIL (
    nil))
(defnt LIST (
    (head LIST-LIST)))
(defnt LIST-LIST (
    xss
    yss
    (tail LIST-LIST)))
