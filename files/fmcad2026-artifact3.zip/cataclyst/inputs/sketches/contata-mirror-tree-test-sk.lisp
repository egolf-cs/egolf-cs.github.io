(deftgt mirror (x :bintree) :bintree
    (if (atom x)
        x
        (list (mirror (bt-right x))
              (bt-value x)
              (mirror (bt-left x)))))

(defmeasure m (x :bintree) :nat
    (acl2s-size x))

(defsketch
    (if ???1
        ???2
        (mirror ???3)))

(defsketch
    (if ???1
        ???2
        (list ???3 ???4 (mirror ???5))))

(defsketch
    (if ???1
        ???2
        (list (mirror ???3) ???4 ???5)))

(defsketch-tgt
    (if ???1
        ???2
        (list (mirror ???3) ???4 (mirror ???5))))

(defhole ???1 :bool (BOOL))
(defhole ???2 :bintree (BINTREE))
(defhole ???3 :bintree (BINTREE))
(defhole ???4 :int (INT))
(defhole ???5 :bintree (BINTREE))
(defnt BOOL (
    (atom BINTREE)))
(defnt INT (
    0
    (bt-value BINTREE)))
(defnt BINTREE (
    'leaf
    x
    (list BINTREE INT BINTREE)
    (bt-left BINTREE)
    (bt-right BINTREE)))
