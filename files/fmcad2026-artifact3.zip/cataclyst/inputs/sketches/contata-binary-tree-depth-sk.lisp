(deftgt bt-depth (x :bintree) :int
    (if (atom x)
        0
        (1+ (max (bt-depth (bt-left x)) (bt-depth (bt-right x))))))

(deftgt bt-cmp (x :bintree x1 :bintree) :compare
    (int-cmp (bt-depth x) (bt-depth x1)))

(defmeasure m (x :all) :nat
    (if (consp x)
        (+ 1 (m (car x)) (m (cdr x)))
        1))

(defsketch
    (if ???1
        ???2
        (bt-depth ???3))
    bt-depth)

(defsketch
    (if ???1
        ???2
        (max (bt-depth ???3) (bt-depth ???4)))
    bt-depth)

(defsketch-tgt
    (if ???1
        ???2
        (1+ (max (bt-depth ???3) (bt-depth ???4))))
    bt-depth)

(defsketch-tgt
    (int-cmp (bt-depth ???5) (bt-depth ???6))
    bt-cmp)

(defhole ???1 :bool (B) bt-depth)
(defhole ???2 :nat (N) bt-depth)
(defhole ???3 :bintree (BT) bt-depth)
(defhole ???4 :bintree (BT) bt-depth)
(defhole ???5 :bintree (BT1) bt-cmp)
(defhole ???6 :bintree (BT1) bt-cmp)
(defnt N (
    0
    (1+ N)))
(defnt B (
    (atom BT)))
(defnt BT (
    'leaf
    x
    (bt-left BT)
    (bt-right BT)))
(defnt BT1 (
    'leaf
    x
    x1
    (bt-left BT1)
    (bt-right BT1)))
