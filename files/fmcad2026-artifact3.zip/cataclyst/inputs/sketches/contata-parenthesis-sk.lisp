(deftgt is-open (x :parenthesis-list) :bool
    (if (endp x)
        t
        (is-close (tail x))))
(deftgt is-close (x :parenthesis-list) :bool
    (if (endp x)
        nil
        (is-open (tail x))))

(defmeasure m (x :all) :nat
    (acl2s-size x))

(defsketch-tgt
    (if ???1
        ???2
        (is-close ???3))
    is-open)
(defsketch-tgt
    (if ???4
        ???5
        (is-open ???6))
    is-close)

(defhole ???1 :bool (B) is-open)
(defhole ???2 :bool (BC B) is-open)
(defhole ???3 :parenthesis-list (P) is-open)

(defhole ???4 :bool (B) is-close)
(defhole ???5 :bool (BC B) is-close)
(defhole ???6 :parenthesis-list (P) is-close)

(defnt P (
    x
    nil
    (tail P)))
(defnt B (
    (equal E E :distinct)
    (endp P)))
(defnt BC (
    t nil))
(defnt E (
    'left
    'right
    (head P)))

