(deftgt my-rev (xs :int-list) :int-list
    (if (endp xs)
        xs
        (append (my-rev (tail xs)) (cons (head xs) nil))))

(defmeasure m (xs :int-list) :nat
    (acl2s-size xs))

(defsketch
    (if ???1
        ???2
        (append ???4 (my-rev ???3))))

(defsketch
    (if ???1
        ???2
        (my-rev ???3)))

(defsketch
    (if ???1
        ???2
        (cons ???5 (my-rev ???3))))

(defsketch-tgt
    (if ???1
        ???2
        (append (my-rev ???3) ???4)))

(defhole ???1 :bool (B))
(defhole ???2 :int-list (LIST))
(defhole ???3 :int-list (LIST))
(defhole ???4 :int-list (LIST))
(defhole ???5 :int (INT))
(defnt B (
    (endp LIST)))
(defnt INT (
    (head LIST)))
(defnt LIST (
    nil
    xs
    (cons INT LIST)
    (tail LIST)))
(defnt INT (
    0
    (head LIST)))
