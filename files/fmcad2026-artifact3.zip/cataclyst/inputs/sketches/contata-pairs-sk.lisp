(set-subexpr-bound 6)

(deftgt pairs (xs :int-list) :int-pair-list
    (if (endp xs)
        nil
        (if (endp (tail xs))
            nil
            (cons (list (head xs) (head (tail xs)))
                  (pairs (tail (tail xs)))))))

(defmeasure m (xs :int-list) :nat
    (acl2s-size xs))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (cons ???5 (pairs ???6)))))

(defhole ???1 :bool (B))
(defhole ???2 :int-pair-list (NIL PLIST))
(defhole ???3 :bool (B))
(defhole ???4 :int-pair-list (NIL PLIST))
(defhole ???5 :int-pair (PAIR))
(defhole ???6 :int-list (LIST))

(defnt B (
    (endp LIST)))
(defnt INT (
    0
    (head LIST)))
(defnt PAIR (
    (list INT INT)))
(defnt PLIST (
    (cons PAIR NIL)
    (cons PAIR PLIST)))
(defnt NIL (
    nil))
(defnt LIST (
    nil
    xs
    (tail LIST)))
