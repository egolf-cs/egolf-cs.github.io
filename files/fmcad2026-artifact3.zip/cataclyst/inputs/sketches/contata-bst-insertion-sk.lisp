(deftgt contata-insert (x :int tr :bintree) :bintree
    (if (atom tr)
        (list 'leaf x 'leaf)
        (if (equal x (bt-value tr))
            tr
            (if (< x (bt-value tr))
                (list (contata-insert x (bt-left tr))
                      (bt-value tr)
                      (bt-right tr))
                (list (bt-left tr)
                      (bt-value tr)
                      (contata-insert x (bt-right tr)))))))

(defmeasure m (x :int tr :bintree) :nat
    (acl2s-size tr))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (if ???5
                (list (contata-insert ???6 ???7) ???8 ???9)
                (list ???10
                      ???11
                      (contata-insert ???12 ???13))))))

(defsketch
    (if ???1
        ???2
        (if ???3
            ???4
            (list (contata-insert ???6 ???7) ???8 ???9))))

(defsketch
    (if ???1
        ???2
        (if ???3
            ???4
            (list ???10
                  ???11
                  (contata-insert ???12 ???13)))))

(defsketch
    (if ???1
        ???2
        (if ???5
            (list (contata-insert ???6 ???7) ???8 ???9)
            (list ???10
                  ???11
                  (contata-insert ???12 ???13)))))

(defsketch
    (if ???1
        ???2
        ???4))

(defsketch
    (if ???1
        ???2
        (list (contata-insert ???6 ???7) ???8 ???9)))

(defsketch
    (if ???1
        ???2
        (list ???10
              ???11
              (contata-insert ???12 ???13))))

(defhole ???1 :bool (B))
(defhole ???2 :bintree (SINGLE BASE TREE))
(defhole ???3 :bool (B))
(defhole ???4 :bintree (SINGLE BASE TREE))
(defhole ???5 :bool (B))
(defhole ???6 :int (INT))
(defhole ???7 :bintree (TREE))
(defhole ???8 :int (INT))
(defhole ???9 :bintree (TREE))
(defhole ???10 :bintree (TREE))
(defhole ???11 :int (INT))
(defhole ???12 :int (INT))
(defhole ???13 :bintree (TREE))
(defnt NIL (
    'leaf))
(defnt BASE (
    tr))
(defnt B (
    (atom BASE)
    (< INT INT :distinct)
    (equal INT INT :distinct)))
(defnt INT (
    x
    (bt-value BASE)
    (bt-value TREE)))
(defnt SINGLE (
    (list NIL INT NIL)))
(defnt TREE (
    (bt-left BASE)
    (bt-right BASE)
    (bt-left TREE)
    (bt-right TREE)))
