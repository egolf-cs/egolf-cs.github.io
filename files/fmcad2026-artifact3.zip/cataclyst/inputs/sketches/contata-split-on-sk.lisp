(definec carcons (x :int xss :int-list-list) :int-list-list
    (if (endp xss)
        (list (list x))
        (cons (cons x (head xss)) (tail xss))))

(deftgt split-on-zero (xs :int-list) :int-list-list
    (if (endp xs)
        nil
        (if (equal (head xs) 0)
            (cons nil (cons (list 0) (split-on-zero (tail xs))))
            (carcons (head xs) (split-on-zero (tail xs))))))

(defmeasure m (xs :int-list) :int
    (acl2s-size xs))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            (cons ???4 (cons ???5 (split-on-zero ???6)))
            (carcons ???7 (split-on-zero ???8)))))

(defhole ???1 :bool (B))
(defhole ???2 :int-list-list (ILNIL))
(defhole ???3 :bool (B))
(defhole ???4 :int-list (INIL SINGLE INT-LIST))
(defhole ???5 :int-list (INIL SINGLE INT-LIST))
(defhole ???6 :int-list (INIL SINGLE INT-LIST))
(defhole ???7 :int (INT))
(defhole ???8 :int-list (INIL SINGLE INT-LIST))
(defnt B (
    (equal INT INT :distinct)
    (endp INT-LIST)))
(defnt INIL (
    nil))
(defnt ILNIL (
    nil))
(defnt SINGLE (
    (list INT)))
(defnt INT-LIST (
    xs
    (tail INT-LIST)))
(defnt INT (
    0
    (head INT-LIST)))
