(deftgt contata-remove (x :int xs :int-list) :int-list
    (if (endp xs)
        nil
        (if (equal x (head xs))
            (contata-remove x (tail xs))
            (cons (head xs) (contata-remove x (tail xs))))))

(defmeasure m (x :int xs :int-list) :nat
    (acl2s-size xs))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            (contata-remove ???4 ???5)
            (cons ???6 (contata-remove ???7 ???8)))))

(defsketch (if ???1 ???2 (contata-remove ???4 ???5)))
(defsketch (if ???1 ???2 (cons ???6 (contata-remove ???7 ???8))))
(defhole ???1 :bool (B))
(defhole ???2 :int-list (NIL LIST))
(defhole ???3 :bool (B))
(defhole ???4 :int (INT))
(defhole ???5 :int-list (NIL LIST))
(defhole ???6 :int (INT))
(defhole ???7 :int (INT))
(defhole ???8 :int-list (NIL LIST))
(defnt NIL (
    nil))
(defnt B (
    (endp LIST)
    (equal INT INT :distinct)))
(defnt LIST (
    xs
    (tail LIST)))
(defnt INT (
    x
    (head LIST)))
