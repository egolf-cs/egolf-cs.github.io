(set-subexpr-bound 5)

(deftgt list-cmp (xs :int-list ys :int-list) :compare
    (if (endp xs)
        (if (endp ys)
            'cmp-eq
            'cmp-lt)
        (if (endp ys)
            'cmp-gt
            (if (<= (head xs) (head ys))
                (if (<= (head ys) (head xs))
                    (list-cmp (tail xs) (tail ys))
                    'cmp-lt)
                'cmp-gt))))

(defmeasure m (xs :int-list ys :int-list) :nat
    (acl2s-size xs))

(defsketch-tgt
    (if ???1
        (if ???2
            ???3
            ???4)
        (if ???5
            ???6
            (if ???7
                (if ???8
                    (list-cmp ???9 ???10)
                    ???11)
                ???12))))

(defhole ???1 :bool (B))
(defhole ???2 :bool (B))
(defhole ???3 :compare (C))
(defhole ???4 :compare (C))
(defhole ???5 :bool (B))
(defhole ???6 :compare (C))
(defhole ???7 :bool (B))
(defhole ???8 :bool (B))
(defhole ???9 :int-list (INT-LIST))
(defhole ???10 :int-list (INT-LIST))
(defhole ???11 :compare (C))
(defhole ???12 :compare (C))
(defnt B (
    (endp INT-LIST)
    (<= INT INT :distinct)))
(defnt C (
    'cmp-lt
    'cmp-eq
    'cmp-gt))
(defnt INT (
    (head INT-LIST)))
(defnt INT-LIST (
    xs
    ys
    (tail INT-LIST)))
