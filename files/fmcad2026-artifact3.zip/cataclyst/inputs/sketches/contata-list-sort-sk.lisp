(deftgt contata-insert-sort (x :int xs :int-list) :int-list
    (if (endp xs)
        (list x)
        (if (<= x (head xs))
            (cons x xs)
            (cons (head xs) (contata-insert-sort x (tail xs))))))

(defmeasure m (x :int xs :int-list) :nat
    (acl2s-size xs))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (cons ???5 (contata-insert-sort ???6 ???7)))))

(defsketch (if ???1 ???2 ???4))
(defsketch (if ???1 ???2 (cons ???5 (contata-insert-sort ???6 ???7))))
(defhole ???1 :bool (B))
(defhole ???2 :int-list (INT-LIST NIL))
(defhole ???3 :bool (B))
(defhole ???4 :int-list (INT-LIST NIL))
(defhole ???5 :int (INT))
(defhole ???6 :int (INT))
(defhole ???7 :int-list (INT-LIST NIL))
(defnt B (
    (endp INT-LIST)
    (<= INT INT :distinct)))
(defnt NIL (
    nil))
(defnt INT-LIST (
    xs
    (tail INT-LIST)
    (cons INT INT-LIST)
    (list INT)))
(defnt INT (
    x
    (head INT-LIST)))
