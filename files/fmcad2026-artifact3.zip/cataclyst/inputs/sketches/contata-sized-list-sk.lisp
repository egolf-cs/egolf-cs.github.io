(set-subexpr-bound 10)

(deftgt insert (xs :sized-list x :int) :sized-list
    (list (1+ (get-size xs)) x xs))

(defmeasure m (xs :sized-list x :int) :nat
    (if (natp xs)
        0
        (1+ (m (third xs) x))))

(defsketch-tgt ???1)

(defhole ???1 :sized-list (SIZED-LIST))

(defnt SIZED-LIST (
    xs
    (list NAT INT SIZED-LIST)))
(defnt INT (
    x))
(defnt NAT (
    (get-size SIZED-LIST)
    (1+ NAT)))
