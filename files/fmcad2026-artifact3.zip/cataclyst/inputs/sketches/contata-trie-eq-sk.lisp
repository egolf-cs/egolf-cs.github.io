consp contata-trie-eq-sk_20251022_161714.lisp | Transformations: leafp->atom
(set-subexpr-bound 5)
(deftgt trie-eq (t1 :trie t2 :trie) :bool
    (if (atom t1)
        (atom t2)
        (if (atom t2)
            nil
            (if (equal (trie-value t1) (trie-value t2))
                (and (trie-eq (trie-left t1) (trie-left t2))
                     (trie-eq (trie-right t1) (trie-right t2)))
                nil))))

(defmeasure m (t1 :trie t2 :trie) :nat
    (acl2s-size t1))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (if ???5
                (and (trie-eq ???6 ???7)
                     (trie-eq ???8 ???9))
                ???10))))

(defhole ???1 :bool (B))
(defhole ???2 :bool (NIL B))
(defhole ???3 :bool (B))
(defhole ???4 :bool (NIL B))
(defhole ???5 :bool (B))
(defhole ???6 :trie (BASE TREE))
(defhole ???7 :trie (BASE TREE))
(defhole ???8 :trie (BASE TREE))
(defhole ???9 :trie (BASE TREE))
(defhole ???10 :bool (NIL B))
(defnt NIL (
    nil))
(defnt BASE (
    t1
    t2))
(defnt B (
    (atom BASE)
    (equal INT INT :distinct)))
(defnt INT (
    (trie-value BASE)
    (trie-value TREE)))
(defnt TREE (
    (trie-left BASE)
    (trie-right BASE)
    (trie-left TREE)
    (trie-right TREE)))

(defsketch
    (if ???1
        ???2
        (if ???3
            ???4
            (and (trie-eq ???6 ???7)
                 (trie-eq ???8 ???9)))))

(defsketch
    (if ???1
        ???2
        (if ???3
            ???4
            ???10)))

(defsketch
    (if ???1
        ???2
        (if ???5
            (and (trie-eq ???6 ???7)
                 (trie-eq ???8 ???9))
            ???10)))

(defsketch
    (if ???1
        ???2
        ???4))

(defsketch
    (if ???1
        ???2
        (and (trie-eq ???6 ???7)
             (trie-eq ???8 ???9))))
