(deftgt is-even (x :unary) :bool
    (if (endp x)
        t
        (is-odd (tail x))))
(deftgt is-odd (x :unary) :bool
    (if (endp x)
        nil
        (is-even (tail x))))

(defmeasure m (x :all) :nat
    (acl2s-size x))

(defsketch-tgt
    (if ???1
        ???2
        (is-odd ???3))
    is-even)
(defsketch-tgt
    (if ???4
        ???5
        (is-even ???6))
    is-odd)

(defhole ???1 :bool (B) is-even)
(defhole ???2 :bool (B) is-even)
(defhole ???3 :unary (U) is-even)

(defhole ???4 :bool (B) is-odd)
(defhole ???5 :bool (B) is-odd)
(defhole ???6 :unary (U) is-odd)

(defnt U (
    nil
    x
    (usucc U)
    (tail U)))
(defnt B (
    t
    nil
    (endp U)))

