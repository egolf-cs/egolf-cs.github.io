(set-subexpr-bound 5)
(deftgt binary-tree-eq (t1 :bintree t2 :bintree) :bool
    (if (atom t1)
        (atom t2)
        (if (atom t2)
            nil
            (if (equal (bt-value t1) (bt-value t2))
                (and (binary-tree-eq (bt-left t1) (bt-left t2))
                     (binary-tree-eq (bt-right t1) (bt-right t2)))
                nil))))

(defmeasure m (t1 :bintree t2 :bintree) :nat
    (acl2s-size t1))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (if ???5
                (and (binary-tree-eq ???6 ???7)
                     (binary-tree-eq ???8 ???9))
                ???10))))

(defhole ???1 :bool (B))
(defhole ???2 :bool (NIL B))
(defhole ???3 :bool (B))
(defhole ???4 :bool (NIL B))
(defhole ???5 :bool (B))
(defhole ???6 :bintree (BASE TREE))
(defhole ???7 :bintree (BASE TREE))
(defhole ???8 :bintree (BASE TREE))
(defhole ???9 :bintree (BASE TREE))
(defhole ???10 :bool (NIL B))
(defnt NIL (
    nil))
(defnt BASE (
    t1
    t2))
(defnt B (
    (atom BASE)
    (equal INT INT :distinct)))
(defnt INT (
    (bt-value BASE)
    (bt-value TREE)))
(defnt TREE (
    (bt-left BASE)
    (bt-right BASE)
    (bt-left TREE)
    (bt-right TREE)))

(defsketch
    (if ???1
        ???2
        (if ???3
            ???4
            (and (binary-tree-eq ???6 ???7)
                 (binary-tree-eq ???8 ???9)))))

(defsketch
    (if ???1
        ???2
        (if ???3
            ???4
            ???10)))

(defsketch
    (if ???1
        ???2
        (if ???5
            (and (binary-tree-eq ???6 ???7)
                 (binary-tree-eq ???8 ???9))
            ???10)))

(defsketch
    (if ???1
        ???2
        ???4))

(defsketch
    (if ???1
        ???2
        (and (binary-tree-eq ???6 ???7)
             (binary-tree-eq ???8 ???9))))
