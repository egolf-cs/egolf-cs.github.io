(deftgt tt-depth (x :ttree) :int
    (if (atom x)
        0
        (1+ (max3 (tt-depth (tt-left x)) (tt-depth (tt-middle x)) (tt-depth (tt-right x))))))

(deftgt tt-cmp (x :ttree x1 :ttree) :compare
    (int-cmp (tt-depth x) (tt-depth x1)))

(defmeasure m (x :all) :nat
    (if (consp x)
        (+ 1 (m (car x)) (m (cdr x)))
        1))

(defsketch-tgt
    (if ???1
        ???2
        (1+ (max3 (tt-depth ???3) (tt-depth ???4) (tt-depth ???5))))
    tt-depth)

(defsketch-tgt
    (int-cmp (tt-depth ???6) (tt-depth ???7))
    tt-cmp)

(defhole ???1 :bool (B) tt-depth)
(defhole ???2 :nat (N) tt-depth)
(defhole ???3 :ttree (TTREE) tt-depth)
(defhole ???4 :ttree (TTREE) tt-depth)
(defhole ???5 :ttree (TTREE) tt-depth)
(defhole ???6 :ttree (TTREE1) tt-cmp)
(defhole ???7 :ttree (TTREE1) tt-cmp)
(defnt N (
    0
    1
    (1+ N)))
(defnt B (
    (atom TTREE)))
(defnt TTREE (
    'leaf
    x
    (tt-left TTREE)
    (tt-middle TTREE)
    (tt-right TTREE)))
(defnt TTREE1 (
    'leaf
    x
    x1
    (tt-left TTREE1)
    (tt-middle TTREE1)
    (tt-right TTREE1)))
