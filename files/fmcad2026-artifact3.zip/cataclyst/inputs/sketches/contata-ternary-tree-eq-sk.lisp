(set-subexpr-bound 5)
(deftgt ttree-eq (t1 :ttree t2 :ttree) :bool
    (if (atom t1)
        (atom t2)
        (if (atom t2)
            nil
            (if (equal (tt-value t1) (tt-value t2))
                (and (ttree-eq (tt-left t1) (tt-left t2))
                     (ttree-eq (tt-middle t1) (tt-middle t2))
                     (ttree-eq (tt-right t1) (tt-right t2)))
                nil))))

(defmeasure m (t1 :ttree t2 :ttree) :nat
    (if (atom t1)
        0
        (+ 1
           (m (tt-left t1) t2)
           (m (tt-middle t1) t2)
           (m (tt-right t1) t2))))

(defsketch-tgt
    (if ???1
        ???2
        (if ???3
            ???4
            (if ???5
                (and (ttree-eq ???6 ???7)
                     (ttree-eq ???8 ???9)
                     (ttree-eq ???10 ???11))
                ???12))))

(defhole ???1 :bool (B))
(defhole ???2 :bool (NIL B))
(defhole ???3 :bool (B))
(defhole ???4 :bool (NIL B))
(defhole ???5 :bool (B))
(defhole ???6 :ttree (TREE))
(defhole ???7 :ttree (TREE))
(defhole ???8 :ttree (TREE))
(defhole ???9 :ttree (TREE))
(defhole ???10 :ttree (TREE))
(defhole ???11 :ttree (TREE))
(defhole ???12 :bool (NIL B))
(defnt NIL (
    nil))
(defnt BASE (
    t1
    t2))
(defnt B (
    (atom BASE)
    (equal INT INT :distinct)))
(defnt INT (
    (tt-value BASE)))
(defnt TREE (
    (tt-left BASE)
    (tt-middle BASE)
    (tt-right BASE)
    (tt-left TREE)
    (tt-middle TREE)
    (tt-right TREE)))
