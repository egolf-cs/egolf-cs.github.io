(deftgt count-leaves-tree (tr :itree) :nat
    (if (itemptyp tr)
        0
        (count-leaves-forest (itchildren tr))))
(deftgt count-leaves-forest (fr :iforest) :nat
    (if (ifnilp fr)
        1
        (+ (count-leaves-tree (ifhead fr)) (count-leaves-forest (iftail fr)))))

(defmeasure m (x :all) :nat
    (acl2s-size x))

(defsketch
    (if ???1
        ???2
        (1+ (count-leaves-tree ???3a)))
    count-leaves-tree)
(defsketch
    (if ???1
        ???2
        (count-leaves-tree ???3a))
    count-leaves-tree)
(defsketch
    (if ???1
        ???2
        (+ (count-leaves-tree ???3a) (count-leaves-forest ???3)))
    count-leaves-tree)
(defsketch
    (if ???1
        ???2
        (1+ (count-leaves-forest ???3)))
    count-leaves-tree)
(defsketch-tgt
    (if ???1
        ???2
        (count-leaves-forest ???3))
    count-leaves-tree)

(defsketch
    (if ???4
        ???5
        (count-leaves-tree ???6))
    count-leaves-forest)
(defsketch
    (if ???4
        ???5
        (count-leaves-forest ???7))
    count-leaves-forest)
(defsketch
    (if ???4
        ???5
        (1+ (count-leaves-tree ???6)))
    count-leaves-forest)
(defsketch
    (if ???4
        ???5
        (1+ (count-leaves-forest ???7)))
    count-leaves-forest)
(defsketch-tgt
    (if ???4
        ???5
        (+ (count-leaves-tree ???6) (count-leaves-forest ???7)))
    count-leaves-forest)

(defhole ???1 :bool (B) count-leaves-tree)
(defhole ???2 :nat (N) count-leaves-tree)
(defhole ???3 :iforest (FOREST) count-leaves-tree)
(defhole ???3a :itree (TREE) count-leaves-tree)

(defhole ???4 :bool (B1) count-leaves-forest)
(defhole ???5 :nat (N) count-leaves-forest)
(defhole ???6 :itree (TREE1) count-leaves-forest)
(defhole ???7 :iforest (FOREST1) count-leaves-forest)

(defnt N (
    0 1))
(defnt B (
    (itemptyp TREE)
    (ifnilp FOREST)))
(defnt TREE (
    'itempty
    tr
    (ifhead FOREST)))
(defnt FOREST (
    'ifnil
    (iftail FOREST)
    (itchildren TREE)))

(defnt B1 (
    (itemptyp TREE1)
    (ifnilp FOREST1)))
(defnt TREE1 (
    'itempty
    (ifhead FOREST1)))
(defnt FOREST1 (
    'ifnil
    fr
    (iftail FOREST1)
    (itchildren TREE1)))





