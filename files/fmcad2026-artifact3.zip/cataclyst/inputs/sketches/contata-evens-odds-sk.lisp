(deftgt ilevens (x :int-list) :int-list
    (if (endp x)
        x
        (cons (head x) (ilodds (tail x)))))

(deftgt ilodds (x :int-list) :int-list
    (if (endp x)
        x
        (ilevens (tail x))))

(defmeasure m (args :all) :nat
    (acl2s-size args))

(defsketch
    (if ???1
        ???2
        (ilevens ???4))
    ilevens)

(defsketch
    (if ???1
        ???2
        (cons ???3 (ilevens ???4)))
    ilevens)

(defsketch
    (if ???1
        ???2
        (ilodds ???4))
    ilevens)

(defsketch-tgt
    (if ???1
        ???2
        (cons ???3 (ilodds ???4)))
    ilevens)

(defsketch
    (if ???5
        ???6
        (cons ???7 (ilodds ???8)))
    ilodds)

(defsketch
    (if ???5
        ???6
        (ilodds ???8))
    ilodds)

(defsketch
    (if ???5
        ???6
        (cons ???7 (ilevens ???8)))
    ilodds)

(defsketch-tgt
    (if ???5
        ???6
        (ilevens ???8))
    ilodds)

(defhole ???1 :bool (B) ilevens)
(defhole ???2 :int-list (NIL INT-LIST) ilevens)
(defhole ???3 :int (INT) ilevens)
(defhole ???4 :int-list (NIL INT-LIST) ilevens)
(defhole ???5 :bool (B) ilodds)
(defhole ???6 :int-list (INT-LIST) ilodds)
(defhole ???7 :int (INT) ilodds)
(defhole ???8 :int-list (INT-LIST) ilodds)
(defnt B (
    (endp INT-LIST)))
(defnt INT-LIST (
    nil
    x
    (tail INT-LIST)))
(defnt INT (
    0
    (head INT-LIST)))
