(set-contata-bench ext-mirror-ternary_test2.mls)

(ld contata-mirror-ternary-test2.lisp)
(ld preambles/contata-ext-mirror-ternary-test-pre.lisp)


