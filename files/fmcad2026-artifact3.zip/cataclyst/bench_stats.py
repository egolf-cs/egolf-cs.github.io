#!/usr/bin/env python3
"""Benchmark sketch and synthesis-output statistics for next-artifact.

Parses Cataclyst benchmark ``.lisp`` inputs and linked sketches under
``sketches/`` or ``unreal-sketches/`` (names ending in ``-sk.lisp`` or
``-sk-smt.lisp``), plus solver output files under a caller-supplied output base
directory.
``summary.py`` uses this module for holes, grammar NT/rule counts, and
completion size. Input-side stats come from each benchmark ``.lisp`` and its
sketch
``(ld ...)``; completion size also reads the solver output ``.lisp`` and matches
synthesized bodies to sketches in memory (no auxiliary report files).
"""

import argparse
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

import sexpdata as sx

_CATACLYST_DIR = Path(__file__).resolve().parent
_DEFAULT_DATA_DIR = str(_CATACLYST_DIR)
_SKETCH_LD_DIR_PREFIXES = ("sketches/", "unreal-sketches/")


def _import_path_is_sketch_ld(import_path: str) -> bool:
    """Return True when ``import_path`` is a synthesis sketch ``(ld ...)`` path.

    Regular benchmarks load ``sketches/...``; ``unreal-`` benchmarks use
    ``unreal-sketches/...``. Names end with ``-sk.lisp`` or, for SMT,
    ``-sk-smt.lisp``. Paths ending only in ``-sk.lisp`` missed the SMT case and
    left grammar and hole stats at zero.
    """
    if not any(import_path.startswith(p) for p in _SKETCH_LD_DIR_PREFIXES):
        return False
    if not import_path.endswith(".lisp"):
        return False
    name = Path(import_path).name
    return name.endswith("-sk.lisp") or name.endswith("-sk-smt.lisp")


class BenchmarkData:
    """Represents all data for a single benchmark, with processing methods."""
    
    def __init__(self, name: str):
        self.name = name
        self.input_file: Optional[Path] = None
        self.sketch_file: Optional[Path] = None
        self.output_files: Dict[str, Path] = {}  # approach -> file path
        
        # Raw parsed data
        self._signatures: Set[str] = set()
        self._sketch_functions: Set[str] = set()
        self._sketch_holes: Set[str] = set()
        self._sketch_holes_in_targets: int = 0
        self._max_holes_in_any_sketch: int = 0
        self._max_size_in_any_sketch_combination: int = 0
        self._grammar_non_terminals: int = 0
        self._grammar_rules: int = 0
        self._sketch_sizes: int = 0
        self._alternative_sketch_sizes: Dict[str, int] = {}  # function_name -> alternative_sketch_size
        self._alternative_holes_counts: Dict[str, int] = {}  # function_name -> alternative_holes_count
        self._completion_sizes: Dict[str, int] = {}  # function_name -> total_completion_size
        self._actual_bindings_counts: Dict[str, int] = {}  # function_name -> actual_bindings_count
        self._actual_sketch_sizes: Dict[str, int] = {}  # function_name -> actual_sketch_size_used
        self._target_sizes: int = 0
        self._synthesized_functions: Dict[str, List[str]] = {}  # approach -> [function names]
        self._synthesized_sizes: Dict[str, List[int]] = {}  # approach -> [function sizes]
        self._synthesized_discounted_sizes: Dict[str, List[int]] = {}  # approach -> [discounted sizes]
        
    def set_input_file(self, path: Path):
        """Set the input file path."""
        self.input_file = path
        
    def set_sketch_file(self, path: Path):
        """Set the sketch file path."""
        self.sketch_file = path
        
    def set_output_file(self, approach: str, path: Path):
        """Set an output file for a specific approach."""
        self.output_files[approach] = path

    def _add_signatures_from_prenex(self, prenex_expr: List) -> None:
        """Register Skolem functions declared with (E name ...) in a prenex block.

        Example: (prenex ((A x :int) (E index-of (x :int xs :int-list) :nat))
        <body>) adds `index-of` alongside names from `defsig`.
        """
        if len(prenex_expr) < 2:
            return
        bindings_block = prenex_expr[1]
        if not isinstance(bindings_block, list):
            return
        for binding in bindings_block:
            if not isinstance(binding, list) or len(binding) < 2:
                continue
            if binding[0] != sx.Symbol('E'):
                continue
            fn_token = binding[1]
            if isinstance(fn_token, sx.Symbol):
                self._signatures.add(str(fn_token))

    def _collect_exists_names_in_sexp(self, sexp: Any) -> None:
        """Add every `(exists <name> ...)` witness name found under `sexp`."""
        if not isinstance(sexp, list) or len(sexp) == 0:
            return
        if sexp[0] == sx.Symbol('exists') and len(sexp) >= 2:
            tok = sexp[1]
            if isinstance(tok, sx.Symbol):
                self._signatures.add(str(tok))
        for child in sexp:
            if isinstance(child, list):
                self._collect_exists_names_in_sexp(child)

    def _add_signatures_from_ex_property(self, ex_prop_expr: List) -> None:
        """Register Skolem names from `(exists ...)` in an `ex-property` form."""
        for part in ex_prop_expr[2:]:
            self._collect_exists_names_in_sexp(part)

    def _add_signatures_from_defsigs(self, defsigs_expr: List) -> None:
        """Register each target name from a mutual-recursion `(defsigs (...))` group.

        Example: (defsigs ((is-open (x :t) :bool) (is-close (x :t) :bool)))
        adds `is-open` and `is-close`, matching `deftgt` / `defsketch-tgt` names.
        """
        if len(defsigs_expr) < 2:
            return
        group = defsigs_expr[1]
        if not isinstance(group, list):
            return
        for sig_entry in group:
            if not isinstance(sig_entry, list) or len(sig_entry) < 2:
                continue
            name_tok = sig_entry[0]
            if isinstance(name_tok, sx.Symbol):
                self._signatures.add(str(name_tok))

    def parse_signatures(self, visited_files: Set[Path] = None):
        """Parse function signatures from input file and its imports."""
        if not self.input_file or not self.input_file.exists():
            return
            
        if visited_files is None:
            visited_files = set()
            
        if self.input_file in visited_files:
            return
            
        visited_files.add(self.input_file)
        
        try:
            with open(self.input_file, 'r') as f:
                content = f.read()
            
            parsed_expressions = sx.parse(content)
            
            for expr in parsed_expressions:
                if isinstance(expr, list) and len(expr) > 0:
                    if expr[0] == sx.Symbol('defsig') and len(expr) >= 2:
                        func_name = str(expr[1])
                        self._signatures.add(func_name)
                    elif expr[0] == sx.Symbol('defsigs'):
                        self._add_signatures_from_defsigs(expr)
                    elif expr[0] == sx.Symbol('prenex'):
                        self._add_signatures_from_prenex(expr)
                    elif expr[0] == sx.Symbol('ex-property'):
                        self._add_signatures_from_ex_property(expr)
                    elif expr[0] == sx.Symbol('ld') and len(expr) >= 2:
                        import_path = str(expr[1]).strip('"')
                        if _import_path_is_sketch_ld(import_path):
                            sketch_path = self.input_file.parent / import_path
                            self.set_sketch_file(sketch_path)
                        elif import_path.endswith('.lisp'):
                            # This is a preamble file to recursively parse
                            preamble_path = self.input_file.parent / import_path
                            if preamble_path.exists():
                                temp_benchmark = BenchmarkData(f"{self.name}_preamble")
                                temp_benchmark.set_input_file(preamble_path)
                                temp_benchmark.parse_signatures(visited_files)
                                self._signatures.update(temp_benchmark._signatures)
                                # Also copy over sketch file if discovered during recursive parsing
                                if temp_benchmark.sketch_file and not self.sketch_file:
                                    self.set_sketch_file(temp_benchmark.sketch_file)
                                
        except Exception as e:
            print(f"Warning: Could not parse signatures from {self.input_file}: {e}")
            
    def parse_sketch_data(self):
        """Parse sketch file data including functions, holes, and sizes."""
        if not self.sketch_file or not self.sketch_file.exists():
            return
            
        try:
            with open(self.sketch_file, 'r') as f:
                content = f.read()
                
            parsed_expressions = sx.parse(content)
            
            # Track sketches by function name to compute valid combinations
            sketches_by_function = {}  # function_name -> [hole_counts]
            sketch_sizes_by_function = {}  # function_name -> [sketch_sizes]
            
            for expr in parsed_expressions:
                if isinstance(expr, list) and len(expr) > 0:
                    if expr[0] == sx.Symbol('defsketch-tgt'):
                        # Extract sketch body and target function name
                        if len(expr) >= 2:
                            sketch_body = expr[1]
                            if len(expr) >= 3:
                                # Has target function name
                                target_func = str(expr[2])
                                self._sketch_functions.add(target_func)
                            else:
                                # Default function name - all unnamed sketches belong to the same function
                                target_func = "main_function"
                            
                            # Count holes in sketch body and compute size
                            holes_in_this_sketch = self._count_holes_in_expression(sketch_body)
                            size_of_this_sketch = self._count_sexp_size(sketch_body)
                            self._sketch_holes_in_targets += holes_in_this_sketch
                            self._sketch_sizes += size_of_this_sketch
                            
                            # Track by function
                            if target_func not in sketches_by_function:
                                sketches_by_function[target_func] = []
                                sketch_sizes_by_function[target_func] = []
                            sketches_by_function[target_func].append(holes_in_this_sketch)
                            sketch_sizes_by_function[target_func].append(size_of_this_sketch)
                            
                    elif expr[0] == sx.Symbol('defsketch'):
                        # Also count holes in alternative sketches
                        if len(expr) >= 2:
                            sketch_body = expr[1]
                            holes_in_this_sketch = self._count_holes_in_expression(sketch_body)
                            size_of_this_sketch = self._count_sexp_size(sketch_body)
                            
                            # Get function name for defsketch
                            if len(expr) >= 3:
                                func_name = str(expr[2])
                            else:
                                # All unnamed defsketch belong to the same function as defsketch-tgt
                                func_name = "main_function"
                            
                            # Track by function
                            if func_name not in sketches_by_function:
                                sketches_by_function[func_name] = []
                                sketch_sizes_by_function[func_name] = []
                            sketches_by_function[func_name].append(holes_in_this_sketch)
                            sketch_sizes_by_function[func_name].append(size_of_this_sketch)
                            
                    elif expr[0] == sx.Symbol('deftgt') and len(expr) >= 5:
                        func_name = str(expr[1])
                        func_body = expr[-1]  # Last element is the function body
                        self._sketch_functions.add(func_name)
                        self._target_sizes += self._count_sexp_size(func_body)
                        
                    elif expr[0] == sx.Symbol('defhole') and len(expr) >= 2:
                        hole_name = str(expr[1])
                        self._sketch_holes.add(hole_name)
                        
                    elif expr[0] == sx.Symbol('defnt') and len(expr) >= 3:
                        # Count non-terminals and rules: (defnt NT_NAME (rule1 rule2 ...))
                        self._grammar_non_terminals += 1
                        rules_list = expr[2]  # The list of rules
                        if isinstance(rules_list, list):
                            self._grammar_rules += len(rules_list)
            
            # Compute maximum holes and sizes across all valid sketch combinations
            self._max_holes_in_any_sketch = self._compute_max_holes_in_valid_combinations(sketches_by_function)
            self._max_size_in_any_sketch_combination = self._compute_max_holes_in_valid_combinations(sketch_sizes_by_function)
                        
        except Exception as e:
            print(f"Warning: Could not parse sketch data from {self.sketch_file}: {e}")
    
    def _compute_max_holes_in_valid_combinations(self, sketches_by_function):
        """Compute maximum total holes across all valid combinations of sketches."""
        if not sketches_by_function:
            return 0
            
        function_names = list(sketches_by_function.keys())
        if len(function_names) == 1:
            # Single function case - just return max holes in any sketch for that function
            return max(sketches_by_function[function_names[0]])
        
        # Multi-function case - compute all valid combinations
        import itertools
        
        # Get all possible combinations where each function gets exactly one sketch
        sketch_lists = [sketches_by_function[func] for func in function_names]
        all_combinations = list(itertools.product(*sketch_lists))
        
        if not all_combinations:
            return 0
            
        # Find the combination with maximum total holes
        max_total_holes = max(sum(combination) for combination in all_combinations)
        return max_total_holes
            
    def parse_synthesized_data(self, approach: str):
        """Parse synthesized function data for a specific approach."""
        if approach not in self.output_files:
            return
            
        output_file = self.output_files[approach]
        if not output_file.exists():
            return
            
        try:
            with open(output_file, 'r') as f:
                content = f.read()
                
            # Check if synthesis failed
            if "; Synthesized functions:\nNone" in content:
                self._synthesized_functions[approach] = []
                self._synthesized_sizes[approach] = []
                self._synthesized_discounted_sizes[approach] = []
                return
                
            # Find synthesized functions section
            synth_section_match = re.search(r'; Synthesized functions:\n(\(.*?\n\))', content, re.DOTALL)
            if not synth_section_match:
                self._synthesized_functions[approach] = []
                self._synthesized_sizes[approach] = []
                self._synthesized_discounted_sizes[approach] = []
                return
                
            synth_content = synth_section_match.group(1)
            
            function_names = []
            function_sizes = []
            function_discounted_sizes = []
            
            try:
                parsed_synth = sx.parse(synth_content)
                
                # The parsed result is a list containing one element which is the list of definec expressions
                if len(parsed_synth) > 0 and isinstance(parsed_synth[0], list):
                    definec_expressions = parsed_synth[0]
                else:
                    definec_expressions = parsed_synth
                
                for expr in definec_expressions:
                    if isinstance(expr, list) and len(expr) > 0:
                        if expr[0] == sx.Symbol('definec') and len(expr) >= 7:
                            func_name = str(expr[1])
                            body = expr[-1]  # Last element is function body
                            
                            # Convert wrapper functions to mutual recursion units
                            if func_name.endswith('-wrapper'):
                                function_names.append("mutual-rec-1")
                            else:
                                function_names.append(func_name)
                                
                            # Calculate sizes
                            body_size = self._count_sexp_size(body)
                            function_sizes.append(body_size)
                            
                            # Calculate discounted size for wrapper functions
                            if func_name.endswith('-wrapper'):
                                discounted_size = self._compute_wrapper_discounted_size(body)
                            else:
                                discounted_size = body_size
                            function_discounted_sizes.append(discounted_size)
                            
            except Exception as parse_error:
                print(f"Warning: Could not parse synthesized functions S-expression in {output_file}: {parse_error}")
                # Fall back to regex parsing
                definec_pattern = r'\(\s*definec\s+([^\s\(]+)'
                matches = re.findall(definec_pattern, synth_content)
                
                for func_name in matches:
                    if func_name.endswith('-wrapper'):
                        function_names.append("mutual-rec-1")
                    else:
                        function_names.append(func_name)
                    function_sizes.append(0)  # Can't compute size with regex fallback
                    function_discounted_sizes.append(0)
                    
            self._synthesized_functions[approach] = function_names
            self._synthesized_sizes[approach] = function_sizes
            self._synthesized_discounted_sizes[approach] = function_discounted_sizes
            
        except Exception as e:
            print(f"Warning: Could not parse synthesized data from {output_file}: {e}")
            self._synthesized_functions[approach] = []
            self._synthesized_sizes[approach] = []
            self._synthesized_discounted_sizes[approach] = []
            
    def _count_holes_in_expression(self, expr) -> int:
        """Count hole references (???N) in an S-expression."""
        if isinstance(expr, sx.Symbol):
            symbol_str = str(expr)
            if symbol_str.startswith('???'):
                return 1
            return 0
        elif isinstance(expr, list):
            return sum(self._count_holes_in_expression(sub_expr) for sub_expr in expr)
        else:
            return 0
            
    def _count_sexp_size(self, expr) -> int:
        """Count the size of an S-expression (1 for atoms, 1 + sum of arg sizes for lists)."""
        if isinstance(expr, list):
            if len(expr) == 0:
                return 1  # Empty list is an atom
            else:
                # For non-empty lists: 1 + sum of sizes of arguments (skip operator/head)
                return 1 + sum(self._count_sexp_size(arg) for arg in expr[1:])
        else:
            return 1  # Any atom (including symbols, numbers, etc.)
            
    def _compute_wrapper_discounted_size(self, function_body) -> int:
        """Compute discounted size for mutual recursion wrapper functions."""
        core_bodies = self._extract_mutual_recursion_core_logic(function_body)
        if len(core_bodies) > 1:
            # Multiple core bodies found - this is a mutual recursion wrapper
            return sum(self._count_sexp_size(body) for body in core_bodies)
        else:
            # Not a mutual recursion wrapper or couldn't extract - use normal size
            return self._count_sexp_size(function_body)
            
    def _extract_mutual_recursion_core_logic(self, function_body) -> List[Any]:
        """Extract core logic from mutual recursion wrapper functions."""
        if not isinstance(function_body, list) or len(function_body) == 0:
            return [function_body]
            
        # Look for match expression
        if function_body[0] == sx.Symbol('match') and len(function_body) >= 3:
            match_var = function_body[1]
            cases = function_body[2:]
            
            core_bodies = []
            wrapper_name = self._find_wrapper_function_name(function_body)
            
            for case in cases:
                if isinstance(case, list) and len(case) >= 2:
                    case_pattern = case[0]
                    case_body = case[1]
                    
                    # Extract constructor name from pattern
                    if isinstance(case_pattern, list) and len(case_pattern) > 0:
                        constructor = str(case_pattern[0])
                        # Transform wrapper calls in the case body
                        transformed_body = self._transform_wrapper_calls(case_body, wrapper_name, constructor)
                        core_bodies.append(transformed_body)
                    else:
                        core_bodies.append(case_body)
                        
            return core_bodies if len(core_bodies) > 1 else [function_body]
        else:
            return [function_body]
            
    def _find_wrapper_function_name(self, expr) -> str:
        """Find the wrapper function name (ending with -wrapper) in an expression."""
        if isinstance(expr, sx.Symbol):
            symbol_str = str(expr)
            if symbol_str.endswith('-wrapper'):
                return symbol_str
        elif isinstance(expr, list):
            for sub_expr in expr:
                result = self._find_wrapper_function_name(sub_expr)
                if result:
                    return result
        return ""
        
    def _transform_wrapper_calls(self, expr, wrapper_name: str, current_constructor: str):
        """Transform wrapper function calls to direct target function calls."""
        if isinstance(expr, list) and len(expr) > 0:
            if (isinstance(expr[0], sx.Symbol) and str(expr[0]) == wrapper_name and 
                len(expr) >= 2 and isinstance(expr[1], list) and len(expr[1]) > 0):
                
                # This is a call to the wrapper function
                constructor_call = expr[1]
                if isinstance(constructor_call[0], sx.Symbol):
                    constructor_name = str(constructor_call[0])
                    # Extract target function name by removing -args suffix
                    if constructor_name.endswith('-args'):
                        target_func = constructor_name[:-5]  # Remove '-args'
                        # Replace with direct call: (target_func arg1 arg2 ...)
                        return [sx.Symbol(target_func)] + constructor_call[1:]
                        
            # Recursively transform sub-expressions
            return [self._transform_wrapper_calls(sub_expr, wrapper_name, current_constructor) 
                   for sub_expr in expr]
        else:
            return expr
            
    # Getter methods for accessing processed data
    def get_signatures_count(self) -> int:
        """Get number of function signatures."""
        return len(self._signatures)
        
    def get_sketches_count(self) -> int:
        """Get number of sketch functions."""
        return len(self._sketch_functions)
        
    def get_holes_count(self) -> int:
        """Get number of declared holes."""
        return len(self._sketch_holes)
        
    def get_holes_in_targets_count(self) -> int:
        """Get number of hole references in sketch targets."""
        return self._sketch_holes_in_targets
    
    def get_max_holes_in_any_sketch(self) -> int:
        """Get maximum number of holes in any single sketch."""
        return self._max_holes_in_any_sketch
    
    def get_max_size_in_any_sketch_combination(self) -> int:
        """Get maximum total size across all valid sketch combinations."""
        return self._max_size_in_any_sketch_combination
    
    def get_grammar_non_terminals(self) -> int:
        """Get number of non-terminals in the grammar."""
        return self._grammar_non_terminals
    
    def get_grammar_rules(self) -> int:
        """Get total number of grammar rules."""
        return self._grammar_rules
        
    def get_sketch_size(self) -> int:
        """Get total size of sketch bodies."""
        return self._sketch_sizes
    
    def set_alternative_sketch_size(self, function_name: str, alternative_size: int):
        """Set the alternative sketch size for a function."""
        self._alternative_sketch_sizes[function_name] = alternative_size
    
    def get_alternative_sketch_size(self, function_name: str) -> Optional[int]:
        """Get the alternative sketch size for a function, if any."""
        return self._alternative_sketch_sizes.get(function_name)
    
    def has_alternative_sketch(self, function_name: str) -> bool:
        """Check if a function used an alternative sketch."""
        return function_name in self._alternative_sketch_sizes
    
    def set_alternative_holes_count(self, function_name: str, holes_count: int):
        """Set the holes count for the alternative sketch used by a function."""
        self._alternative_holes_counts[function_name] = holes_count
    
    def get_alternative_holes_count(self, function_name: str) -> Optional[int]:
        """Get the holes count for the alternative sketch used by a function, if any."""
        return self._alternative_holes_counts.get(function_name)
    
    def set_completion_size(self, function_name: str, completion_size: int):
        """Set the completion size for a function."""
        self._completion_sizes[function_name] = completion_size
    
    def get_completion_size(self, function_name: str) -> int:
        """Get the completion size for a function, returns 0 if not found."""
        return self._completion_sizes.get(function_name, 0)
    
    def set_actual_bindings_count(self, function_name: str, bindings_count: int):
        """Set the actual bindings count for a function from pattern matching."""
        self._actual_bindings_counts[function_name] = bindings_count
    
    def set_actual_sketch_size(self, function_name: str, sketch_size: int):
        """Set the actual sketch size used for a function from pattern matching."""
        self._actual_sketch_sizes[function_name] = sketch_size
    
    def get_total_actual_sketch_size(self, approach: str) -> int:
        """Get the total actual sketch size for all functions in an approach."""
        synthesized_functions = self.get_synthesized_functions(approach)
        total_size = 0
        
        for func_name in synthesized_functions:
            # Check if this is a mutual recursion wrapper by looking for core functions
            core_index = 1
            found_any_core = False
            while True:
                core_func_name = f"{func_name}_core_{core_index}"
                if core_func_name in self._actual_sketch_sizes:
                    # Found a core function that was pattern matched
                    total_size += self._actual_sketch_sizes[core_func_name]
                    core_index += 1
                    found_any_core = True
                else:
                    break  # No more core functions
            
            # If no core functions were found, treat as regular function
            if not found_any_core and func_name in self._actual_sketch_sizes:
                total_size += self._actual_sketch_sizes[func_name]
        
        return total_size

    def get_total_actual_bindings_count(self, approach: str) -> int:
        """Get the total actual bindings count for all functions in an approach."""
        synthesized_functions = self.get_synthesized_functions(approach)
        total_count = 0
        
        for func_name in synthesized_functions:
            # Check if this is a mutual recursion wrapper by looking for core functions
            core_index = 1
            found_any_core = False
            while True:
                core_func_name = f"{func_name}_core_{core_index}"
                if core_func_name in self._actual_bindings_counts:
                    # Found a core function that was pattern matched
                    total_count += self._actual_bindings_counts[core_func_name]
                    core_index += 1
                    found_any_core = True
                else:
                    break  # No more core functions
            
            # If no core functions were found, treat as regular function
            if not found_any_core and func_name in self._actual_bindings_counts:
                total_count += self._actual_bindings_counts[func_name]
        
        return total_count

    def get_total_completion_size(self, approach: str) -> int:
        """Get the total completion size for all functions in an approach."""
        synthesized_functions = self.get_synthesized_functions(approach)
        total_size = 0
        
        for func_name in synthesized_functions:
            # Check if this is a mutual recursion wrapper by looking for core functions
            core_index = 1
            found_any_core = False
            while True:
                core_func_name = f"{func_name}_core_{core_index}"
                if core_func_name in self._completion_sizes:
                    # Found a core function that was pattern matched
                    core_size = self._completion_sizes[core_func_name]
                    total_size += core_size
                    core_index += 1
                    found_any_core = True
                else:
                    break  # No more core functions
            
            # If no core functions were found, treat as regular function
            if not found_any_core:
                regular_size = self.get_completion_size(func_name)
                total_size += regular_size
        
        return total_size
        
    def get_target_size(self) -> int:
        """Get total size of target bodies."""
        return self._target_sizes
        
    def get_synthesized_count(self, approach: str) -> int:
        """Get number of synthesized functions for an approach."""
        return len(self._synthesized_functions.get(approach, []))
        
    def get_synthesized_size(self, approach: str) -> int:
        """Get total size of synthesized functions for an approach."""
        return sum(self._synthesized_sizes.get(approach, []))
        
    def get_synthesized_discounted_size(self, approach: str) -> int:
        """Get total discounted size of synthesized functions for an approach."""
        return sum(self._synthesized_discounted_sizes.get(approach, []))
        
    def get_synthesized_functions(self, approach: str) -> List[str]:
        """Get list of synthesized function names for an approach."""
        return self._synthesized_functions.get(approach, [])
        
    def get_signatures(self) -> Set[str]:
        """Get set of function signatures."""
        return self._signatures.copy()


class TableCell:
    """Represents a single cell in the table with content and formatting."""
    
    def __init__(self, content: str, bold: bool = False, color: str = ""):
        self.content = content
        self.bold = bold
        self.color = color
        
    def render(self) -> str:
        """Render the cell with ANSI formatting - apply codes and always reset."""
        result = ""
        
        # Apply color if specified
        if self.color:
            result += self.color
            
        # Apply bold if specified  
        if self.bold:
            result += "\033[1m"
            
        # Add content
        result += self.content
        
        # Always reset
        result += "\033[0m"
        
        return result
        
    def get_display_width(self) -> int:
        """Get the display width (without ANSI codes)."""
        return len(self.content)


class TableRow:
    """Represents a data row in the table."""
    
    def __init__(self, cells: List[TableCell]):
        self.cells = cells
        
    def render(self, column_widths: List[int], separator: str = " | ") -> str:
        """Render the row with proper alignment and formatting."""
        rendered_cells = []
        
        for i, (cell, width) in enumerate(zip(self.cells, column_widths)):
            cell_content = cell.render()
            padding = width - cell.get_display_width()
            
            # Left-align all columns
            padded_cell = f"{cell_content}{' ' * padding}"
            rendered_cells.append(padded_cell)
            
        return separator.join(rendered_cells)


class TableSectionHeader:
    """Represents a section header that spans the full table width."""
    
    def __init__(self, title: str):
        self.title = title
        
    def render(self, column_widths: List[int], separator: str = " | ") -> str:
        """Render the section header across the full table width."""
        total_width = sum(column_widths) + len(separator) * (len(column_widths) - 1)
        return f"--- {self.title} ---"


class BenchmarkTable:
    """Handles table creation and formatting for benchmark data."""
    
    def __init__(self, benchmarks: List[BenchmarkData], approach: str = "proph"):
        self.benchmarks = benchmarks
        self.approach = approach
        self.rows: List[Any] = []  # Can contain TableRow or TableSectionHeader
        self.column_headers = ["#", "Benchmark", "Signatures", "Sketches", "Holes", 
                              "Synthesized", "Synth Size", "Sketch Size", "Completion Size", "Expected Completion Size", "Tgt Size", "NTs", "Rules"]
        self.column_widths: List[int] = []
        
        self._build_table()

class BenchmarkSummaryTable:
    """Summary table with selected columns from the master table."""
    
    def __init__(self, benchmarks: List[BenchmarkData], approach: str = "proph"):
        self.benchmarks = benchmarks
        self.approach = approach
        self.rows: List[Any] = []  # Can contain TableRow or TableSectionHeader
        self.column_headers = ["#", "Benchmark", "Max Holes", "NTs", "Rules", "Completion Size"]
        self.column_widths: List[int] = []
        
        self._build_table()
    
    def _build_table(self):
        """Build the summary table rows from benchmark data."""
        # Categorize benchmarks using the same logic as the master table
        normal_benchmarks = []
        mutual_recursion_benchmarks = []
        helpers_benchmarks = []
        true_failures_benchmarks = []
        
        for benchmark in self.benchmarks:
            signatures_count = benchmark.get_signatures_count()
            sketches_count = benchmark.get_sketches_count()
            synthesized_count = benchmark.get_synthesized_count(self.approach)
            
            if synthesized_count == 0:
                true_failures_benchmarks.append(benchmark)
            elif signatures_count == sketches_count == synthesized_count:
                normal_benchmarks.append(benchmark)
            elif signatures_count == 1 and sketches_count > 1 and synthesized_count == 1:
                mutual_recursion_benchmarks.append(benchmark)
            elif sketches_count == synthesized_count and sketches_count > signatures_count:
                helpers_benchmarks.append(benchmark)
            else:
                true_failures_benchmarks.append(benchmark)
                
        # Sort categories using the same logic as the master table
        normal_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        mutual_recursion_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        helpers_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        true_failures_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        
        # Build rows in the same order as the master table
        row_num = 1
        
        # Normal benchmarks
        for benchmark in normal_benchmarks:
            self._add_benchmark_row(benchmark, row_num)
            row_num += 1
            
        # Mutual recursion benchmarks
        for benchmark in mutual_recursion_benchmarks:
            self._add_benchmark_row(benchmark, row_num)
            row_num += 1
            
        # Helper benchmarks
        for benchmark in helpers_benchmarks:
            self._add_benchmark_row(benchmark, row_num)
            row_num += 1
            
        # True failure benchmarks
        for benchmark in true_failures_benchmarks:
            self._add_benchmark_row(benchmark, row_num)
            row_num += 1
    
    def _add_benchmark_row(self, benchmark: BenchmarkData, row_num: int):
        """Add a benchmark row to the summary table."""
        # Get max holes (the "N" from "N/M" in holes column)
        max_holes_in_any_sketch = benchmark.get_max_holes_in_any_sketch()
        
        # Get grammar data
        non_terminals = benchmark.get_grammar_non_terminals()
        rules = benchmark.get_grammar_rules()
        
        # Get completion size
        completion_size = benchmark.get_total_completion_size(self.approach)
        
        cells = [
            TableCell(str(row_num)),
            TableCell(benchmark.name),
            TableCell(str(max_holes_in_any_sketch)),
            TableCell(str(non_terminals)),
            TableCell(str(rules)),
            TableCell(str(completion_size))
        ]
        
        row = TableRow(cells)
        self.rows.append(row)
    
    def _calculate_column_widths(self):
        """Calculate the width needed for each column."""
        self.column_widths = [len(header) for header in self.column_headers]
        
        for row in self.rows:
            if isinstance(row, TableRow):
                for i, cell in enumerate(row.cells):
                    if i < len(self.column_widths):
                        # Use content length for width calculation
                        self.column_widths[i] = max(self.column_widths[i], len(cell.content))
    
    def render(self) -> str:
        """Render the complete summary table as a string."""
        if not self.rows:
            return "No data to display"
            
        self._calculate_column_widths()
        
        lines = []
        separator = " | "
        
        # Header
        header_line = separator.join(
            header.ljust(width) for header, width in zip(self.column_headers, self.column_widths)
        )
        lines.append(header_line)
        
        # Separator line
        separator_line = "-" * len(header_line)
        lines.append(separator_line)
        
        # Data rows
        for row in self.rows:
            if isinstance(row, TableRow):
                line = row.render(self.column_widths, separator)
                lines.append(line)
        
        return "\n".join(lines)


class BenchmarkTable:
    """Handles table creation and formatting for benchmark data."""
    
    def __init__(self, benchmarks: List[BenchmarkData], approach: str = "proph"):
        self.benchmarks = benchmarks
        self.approach = approach
        self.rows: List[Any] = []  # Can contain TableRow or TableSectionHeader
        self.column_headers = ["#", "Benchmark", "Signatures", "Sketches", "Holes", 
                              "Synthesized", "Synth Size", "Sketch Size", "Completion Size", "Expected Completion Size", "Tgt Size", "NTs", "Rules"]
        self.column_widths: List[int] = []
        
        self._build_table()
        
    def _build_table(self):
        """Build the table rows from benchmark data."""
        # Categorize benchmarks
        normal_benchmarks = []
        mutual_recursion_benchmarks = []
        helpers_benchmarks = []
        true_failures_benchmarks = []
        
        for benchmark in self.benchmarks:
            signatures_count = benchmark.get_signatures_count()
            sketches_count = benchmark.get_sketches_count()
            synthesized_count = benchmark.get_synthesized_count(self.approach)
            
            if synthesized_count == 0:
                true_failures_benchmarks.append(benchmark)
            elif signatures_count == sketches_count == synthesized_count:
                normal_benchmarks.append(benchmark)
            elif signatures_count == 1 and sketches_count > 1 and synthesized_count == 1:
                mutual_recursion_benchmarks.append(benchmark)
            elif sketches_count == synthesized_count and sketches_count > signatures_count:
                helpers_benchmarks.append(benchmark)
            else:
                true_failures_benchmarks.append(benchmark)
                
        # Sort categories
        normal_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        mutual_recursion_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        helpers_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        true_failures_benchmarks.sort(key=lambda b: (b.get_signatures_count(), b.name))
        
        # Build rows
        row_num = 1
        
        # Normal benchmarks
        for benchmark in normal_benchmarks:
            self._add_benchmark_row(benchmark, row_num, "normal")
            row_num += 1
            
        # Add section header for mutual recursion
        if mutual_recursion_benchmarks:
            self._add_section_header("MUTUAL RECURSION (Multiple sketches → Single wrapper)")
            
        for benchmark in mutual_recursion_benchmarks:
            self._add_benchmark_row(benchmark, row_num, "mutual_recursion")
            row_num += 1
            
        # Add section header for helpers
        if helpers_benchmarks:
            self._add_section_header("HELPERS (Sketches include helper functions)")
            
        for benchmark in helpers_benchmarks:
            self._add_benchmark_row(benchmark, row_num, "helpers")
            row_num += 1
            
        # Add section header for failures
        if true_failures_benchmarks:
            self._add_section_header("TRUE FAILURES (Synthesis issues)")
            
        for benchmark in true_failures_benchmarks:
            self._add_benchmark_row(benchmark, row_num, "failures")
            row_num += 1
            
        # Calculate column widths
        self._calculate_column_widths()
        
    def _add_section_header(self, title: str):
        """Add a section header that spans the full table width."""
        section_header = TableSectionHeader(title)
        self.rows.append(section_header)
        
    def _add_benchmark_row(self, benchmark: BenchmarkData, row_num: int, section: str):
        """Add a benchmark data row."""
        signatures_count = benchmark.get_signatures_count()
        sketches_count = benchmark.get_sketches_count()
        synthesized_count = benchmark.get_synthesized_count(self.approach)
        synth_size = benchmark.get_synthesized_size(self.approach)
        discounted_size = benchmark.get_synthesized_discounted_size(self.approach)
        sketch_size = benchmark.get_sketch_size()
        target_size = benchmark.get_target_size()
        
        # Check if any synthesized functions used alternative sketches
        synthesized_functions = benchmark.get_synthesized_functions(self.approach)
        alternative_sketch_sizes = []
        for func_name in synthesized_functions:
            alt_size = benchmark.get_alternative_sketch_size(func_name)
            if alt_size is not None:
                alternative_sketch_sizes.append(alt_size)
        
        # Format sketch size display - show max size vs actual size used
        max_sketch_size_combination = benchmark.get_max_size_in_any_sketch_combination()
        actual_total_sketch_size = benchmark.get_total_actual_sketch_size(self.approach)
        
        # If we have pattern matching data and the sizes differ, show max/actual
        if actual_total_sketch_size > 0 and max_sketch_size_combination != actual_total_sketch_size:
            sketch_size_display = f"{max_sketch_size_combination}/{actual_total_sketch_size}"
        else:
            # Fallback to showing max size (or original sketch size if no max computed)
            if max_sketch_size_combination > 0:
                sketch_size_display = str(max_sketch_size_combination)
            else:
                # Fallback to old logic for cases without pattern matching
                if alternative_sketch_sizes:
                    total_alternative_size = sum(alternative_sketch_sizes)
                    sketch_size_display = f"{sketch_size}/{total_alternative_size}"
                elif section == "mutual_recursion":
                    # For mutual recursion, show actual total sketch size if different from original
                    actual_total_sketch_size_fallback = benchmark.get_total_actual_sketch_size(self.approach)
                    if actual_total_sketch_size_fallback > 0 and actual_total_sketch_size_fallback != sketch_size:
                        sketch_size_display = f"{sketch_size}/{actual_total_sketch_size_fallback}"
                    else:
                        sketch_size_display = str(sketch_size)
                else:
                    sketch_size_display = str(sketch_size)
        
        # Format holes display - show max holes vs actual holes used
        max_holes_in_any_sketch = benchmark.get_max_holes_in_any_sketch()
        actual_bindings_count = benchmark.get_total_actual_bindings_count(self.approach)
        
        # If we have pattern matching data and the counts differ, show max/actual
        if actual_bindings_count > 0 and max_holes_in_any_sketch != actual_bindings_count:
            holes_display = f"{max_holes_in_any_sketch}/{actual_bindings_count}"
        else:
            # Fallback to showing max holes (or declared holes if no max computed)
            if max_holes_in_any_sketch > 0:
                holes_display = str(max_holes_in_any_sketch)
            else:
                # Fallback to old logic for cases without pattern matching
                holes_count = benchmark.get_holes_count()
                holes_in_targets = benchmark.get_holes_in_targets_count()
                if holes_count != holes_in_targets:
                    holes_display = f"{holes_in_targets}/{holes_count}"
                else:
                    holes_display = str(holes_count)
            
        # Format synth size display
        is_mutual_recursion = (signatures_count == 1 and sketches_count > 1 and synthesized_count == 1)
        if is_mutual_recursion and synth_size != discounted_size:
            synth_size_display = f"{synth_size}/{discounted_size}"
            size_comparison_value = discounted_size
        else:
            synth_size_display = str(synth_size)
            size_comparison_value = synth_size
            
        # Determine section colors
        section_color = ""
        if section == "mutual_recursion":
            section_color = "\033[93m"  # Yellow
        elif section == "helpers":
            section_color = "\033[94m"  # Blue
        elif section == "failures":
            section_color = "\033[91m"  # Red
            
        # Calculate actual completion size
        actual_completion_size = benchmark.get_total_completion_size(self.approach)
        
        # Calculate expected completion size: Expected = Synth Size - Sketch Size + Actual Bindings Count
        # Use the actual sketch size and bindings count from pattern matching
        actual_sketch_size = sketch_size
        actual_bindings_count = benchmark.get_total_actual_bindings_count(self.approach)
        synthesized_functions = benchmark.get_synthesized_functions(self.approach)
        if synthesized_functions:
            # Check if any synthesized function used an alternative sketch
            for func_name in synthesized_functions:
                alt_size = benchmark.get_alternative_sketch_size(func_name)
                alt_holes = benchmark.get_alternative_holes_count(func_name)
                if alt_size is not None and alt_holes is not None:
                    actual_sketch_size = alt_size
                    actual_bindings_count = alt_holes  # For alternative sketches, use the holes count from that sketch
                    break  # Use the first alternative found
        
        # For mutual recursion, use discounted synth size and actual sketch sizes from pattern matching
        if section == "mutual_recursion":
            discounted_synth_size = benchmark.get_synthesized_discounted_size(self.approach)
            actual_total_sketch_size = benchmark.get_total_actual_sketch_size(self.approach)
            expected_completion_size = discounted_synth_size - actual_total_sketch_size + actual_bindings_count
        else:
            expected_completion_size = synth_size - actual_sketch_size + actual_bindings_count
        
        # Assert the relationship: Actual Completion Size = Expected Completion Size
        # Check for ALL benchmarks with successful synthesis and pattern matching
        if synth_size > 0 and actual_completion_size > 0 and sketches_count > 0:
            # Determine which synth size and sketch size were used for the calculation
            if section == "mutual_recursion":
                size_used = benchmark.get_synthesized_discounted_size(self.approach)
                size_label = "Discounted Synth Size"
                sketch_size_used = benchmark.get_total_actual_sketch_size(self.approach)
                sketch_size_label = "Actual Total Sketch Size"
            else:
                size_used = synth_size
                size_label = "Synth Size"
                sketch_size_used = actual_sketch_size
                sketch_size_label = "Actual Sketch Size"
            
            assert actual_completion_size == expected_completion_size, (
                f"Completion size mismatch for {benchmark.name}: "
                f"Actual Completion Size ({actual_completion_size}) != Expected Completion Size "
                f"({size_label} ({size_used}) - {sketch_size_label} ({sketch_size_used}) + Actual Bindings ({actual_bindings_count})) "
                f"= {expected_completion_size}. "
                f"Section: {section}, Alternative sketch used: {actual_sketch_size != sketch_size}"
            )
        
        # Orange color for size mismatches
        orange_color = "\033[38;5;208m" if target_size != size_comparison_value and synth_size > 0 else ""
            
        # Create cells with appropriate colors and bold
        cells = [
            TableCell(str(row_num), color=section_color),
            TableCell(benchmark.name, color=section_color),
            TableCell(str(signatures_count), bold=(section == "mutual_recursion"), color=section_color),
            TableCell(str(sketches_count), bold=(section == "helpers"), color=section_color),
            TableCell(holes_display, color=section_color),
            TableCell(str(synthesized_count), bold=(section in ["mutual_recursion", "helpers"]), color=section_color),
            TableCell(synth_size_display, color=(orange_color if orange_color else section_color)),
            TableCell(sketch_size_display, color=section_color),
            TableCell(str(actual_completion_size), color=section_color),
            TableCell(str(expected_completion_size), color=section_color),
            TableCell(str(target_size), color=(orange_color if orange_color else section_color)),
            TableCell(str(benchmark.get_grammar_non_terminals()), color=section_color),
            TableCell(str(benchmark.get_grammar_rules()), color=section_color)
        ]
        
        row = TableRow(cells)
        self.rows.append(row)
        
    def _calculate_column_widths(self):
        """Calculate the width needed for each column."""
        self.column_widths = [len(header) for header in self.column_headers]
        
        for row in self.rows:
            # Only calculate widths for data rows, not section headers
            if isinstance(row, TableRow):
                for i, cell in enumerate(row.cells):
                    if i < len(self.column_widths):
                        self.column_widths[i] = max(self.column_widths[i], cell.get_display_width())
                    
    def render(self) -> str:
        """Render the complete table."""
        lines = []
        
        # Header
        header_cells = [TableCell(header) for header in self.column_headers]
        header_row = TableRow(header_cells)
        lines.append(header_row.render(self.column_widths))
        
        # Separator
        separator = "-" * (sum(self.column_widths) + len(" | ") * (len(self.column_widths) - 1))
        lines.append(separator)
        
        # Data rows and section headers
        for row in self.rows:
            lines.append(row.render(self.column_widths))
            
        return "\n".join(lines)


class BenchmarkAnalyzer:
    """Main analyzer class that coordinates parsing and analysis."""
    
    def __init__(self, input_dir: str, output_base_dir: str, default_approach: str = "proph"):
        self.inputs_path = Path(input_dir)
        self.output_base_path = Path(output_base_dir)
        self.default_approach = default_approach
        self.output_paths = {
            "proph": self.output_base_path / "output-proph",
            "retro": self.output_base_path / "output-retro", 
            "brute": self.output_base_path / "output-brute"
        }
        self.benchmarks: List[BenchmarkData] = []
        
    def discover_benchmarks(self):
        """Discover all benchmark files and create BenchmarkData objects."""
        print("Discovering benchmarks...")
        
        # Find all .lisp files in inputs directory (excluding subdirectories)
        lisp_files = [f for f in self.inputs_path.glob("*.lisp") 
                     if not f.name.endswith('-sk.lisp')]
        
        print(f"Found {len(lisp_files)} potential benchmark files")
        
        for lisp_file in lisp_files:
            benchmark_name = lisp_file.stem
            benchmark = BenchmarkData(benchmark_name)
            benchmark.set_input_file(lisp_file)
            
            # Set output files
            for approach, output_path in self.output_paths.items():
                output_file = output_path / f"{benchmark_name}.lisp"
                if output_file.exists():
                    benchmark.set_output_file(approach, output_file)
                    
            self.benchmarks.append(benchmark)
            
        print(f"Created {len(self.benchmarks)} benchmark objects")
        
    def parse_all_data(self):
        """Parse all data for all benchmarks."""
        print("Parsing benchmark data...")
        
        sketch_files_found = 0
        total_defholes = 0
        total_holes_in_targets = 0
        
        for benchmark in self.benchmarks:
            # Parse signatures (this will also discover sketch files)
            benchmark.parse_signatures()
            
            # Parse sketch data
            benchmark.parse_sketch_data()
            if benchmark.sketch_file:
                sketch_files_found += 1
                
            total_defholes += benchmark.get_holes_count()
            total_holes_in_targets += benchmark.get_holes_in_targets_count()
            
            # Parse synthesized data for each approach
            for approach in self.output_paths.keys():
                benchmark.parse_synthesized_data(approach)
                
        print(f"Found {len([b for b in self.benchmarks if b.get_signatures_count() > 0])} benchmarks with function signatures")
        print(f"Found {sketch_files_found} sketch files")
        print(f"Found {total_defholes} total defhole declarations")
        print(f"Found {total_holes_in_targets} total hole references in defsketch-tgt bodies")
        
        # Print mismatches for debugging
        mismatches = []
        for benchmark in self.benchmarks:
            signatures = benchmark.get_signatures()
            sketch_functions = benchmark._sketch_functions
            if signatures != sketch_functions and len(signatures) > 0 and len(sketch_functions) > 0:
                mismatches.append((benchmark.name, signatures, sketch_functions))
                
        if mismatches:
            for name, sigs, sketches in mismatches[:3]:  # Show first 3
                print(f"  Mismatch in {name}: signatures={sigs}, sketch={sketches}")
            if len(mismatches) > 3:
                print(f"  ... and {len(mismatches) - 3} more mismatches")
                
    def print_table(self, approach: str = "proph"):
        """Print the formatted table."""
        table = BenchmarkTable(self.benchmarks, approach)
        print(table.render())
        
    def print_summary_statistics(self, approach: str = "proph"):
        """Print summary statistics."""
        print("\n" + "=" * 120)
        print("SUMMARY STATISTICS")
        print("=" * 120)
        
        total_expected = sum(b.get_signatures_count() for b in self.benchmarks)
        total_synthesized = sum(b.get_synthesized_count(approach) for b in self.benchmarks)
        
        complete_benchmarks = sum(1 for b in self.benchmarks 
                                if b.get_synthesized_count(approach) == b.get_signatures_count())
        partial_benchmarks = sum(1 for b in self.benchmarks 
                               if 0 < b.get_synthesized_count(approach) < b.get_signatures_count())
        failed_benchmarks = sum(1 for b in self.benchmarks 
                              if b.get_synthesized_count(approach) == 0)
        
        print(f"Total expected functions: {total_expected}")
        print(f"Total synthesized functions: {total_synthesized} ({total_synthesized/total_expected*100:.1f}%)")
        print(f"Benchmarks with complete synthesis: {complete_benchmarks}/{len(self.benchmarks)} ({complete_benchmarks/len(self.benchmarks)*100:.1f}%)")
        print(f"Benchmarks with partial synthesis: {partial_benchmarks}/{len(self.benchmarks)} ({partial_benchmarks/len(self.benchmarks)*100:.1f}%)")
        print(f"Benchmarks with no synthesis: {failed_benchmarks}/{len(self.benchmarks)} ({failed_benchmarks/len(self.benchmarks)*100:.1f}%)")
        
        # Category breakdown
        normal_count = sum(1 for b in self.benchmarks 
                          if (b.get_signatures_count() == b.get_sketches_count() == b.get_synthesized_count(approach)))
        mutual_recursion_count = sum(1 for b in self.benchmarks 
                                   if (b.get_signatures_count() == 1 and b.get_sketches_count() > 1 and b.get_synthesized_count(approach) == 1))
        helpers_count = sum(1 for b in self.benchmarks 
                          if (b.get_sketches_count() == b.get_synthesized_count(approach) and b.get_sketches_count() > b.get_signatures_count()))
        
        print(f"\nCategory breakdown:")
        print(f"Normal (perfect match): {normal_count}/{len(self.benchmarks)} ({normal_count/len(self.benchmarks)*100:.1f}%)")
        print(f"Mutual recursion: {mutual_recursion_count}/{len(self.benchmarks)} ({mutual_recursion_count/len(self.benchmarks)*100:.1f}%)")
        print(f"With helpers: {helpers_count}/{len(self.benchmarks)} ({helpers_count/len(self.benchmarks)*100:.1f}%)")
        print(f"True failures: {failed_benchmarks}/{len(self.benchmarks)} ({failed_benchmarks/len(self.benchmarks)*100:.1f}%)")
        
    def print_detailed_breakdown(self, approach: str = "proph", limit: int = 3):
        """Print detailed function breakdown for debugging."""
        print(f"\nDetailed function breakdown for first few benchmarks:")
        for i, benchmark in enumerate(self.benchmarks[:limit]):
            print(f"\n{benchmark.name}:")
            expected_funcs = sorted(benchmark.get_signatures())
            synthesized_funcs = benchmark.get_synthesized_functions(approach)
            print(f"  Expected: {expected_funcs}")
            print(f"  Synthesized: {synthesized_funcs}")
            
    def analyze(self):
        """Run complete analysis."""
        self.discover_benchmarks()
        self.parse_all_data()
        print("Collecting synthesis results...")
        print(f"Collected results for {len(self.output_paths)} approaches")
        
    def analyze_pattern_matching(self, approach: str = "proph"):
        """Match synthesized code to sketches; set per-benchmark completion sizes."""
        print(
            "Reading sketches and proph outputs to size hole completions...",
            flush=True,
        )
        
        matcher = SketchPatternMatcher(validate_grammar=True)

        for benchmark in self.benchmarks:
            if not benchmark.sketch_file or benchmark.get_synthesized_count(approach) == 0:
                continue
                
            try:
                # Parse sketch file to get defsketch-tgt and defsketch
                sketch_targets, alternative_sketches = self._extract_sketch_targets(benchmark)
                
                # Extract grammar information for validation
                hole_grammars, grammar_rules = self._extract_grammar_info(benchmark)
                
                # Set grammar information in the matcher
                matcher.set_grammar_info(hole_grammars, grammar_rules)
                
                # Parse synthesized functions
                synthesized_functions = self._extract_synthesized_functions(benchmark, approach)
                
                # Analyze each synthesized function
                for synth_func_name, synth_func_body in synthesized_functions:
                    # Handle mutual recursion wrappers
                    if synth_func_name.endswith('-wrapper'):
                        core_bodies = benchmark._extract_mutual_recursion_core_logic(synth_func_body)
                        for i, core_body in enumerate(core_bodies):
                            core_func_name = f"{synth_func_name}_core_{i+1}"
                            match_found = False
                            
                            # First try defsketch-tgt targets
                            if i < len(sketch_targets):
                                sketch_name, sketch_body = sketch_targets[i]
                                match_result = matcher.match_pattern(core_body, sketch_body)
                                
                                if match_result:
                                    # Calculate and store completion size, bindings count, and sketch size
                                    completion_size = self._calculate_completion_size(match_result)
                                    bindings_count = len(match_result)
                                    sketch_size_used = self._count_sexp_size(sketch_body)
                                    # Store using standardized mutual recursion name
                                    standardized_core_name = f"mutual-rec-1_core_{i+1}"
                                    benchmark.set_completion_size(standardized_core_name, completion_size)
                                    benchmark.set_actual_bindings_count(standardized_core_name, bindings_count)
                                    benchmark.set_actual_sketch_size(standardized_core_name, sketch_size_used)

                                    match_found = True
                            
                            # If defsketch-tgt failed, try defsketch alternatives with matching function names
                            if not match_found:
                                # Extract the base function name from core_func_name
                                # e.g., "count-leaves-tree-count-leaves-forest-wrapper_core_1" -> try to match "count-leaves-tree"
                                base_func_name = self._extract_base_function_name_from_core(core_func_name, i)
                                
                                # Try to find matching defsketch by function name
                                alternative_match_found = False
                                for alt_name, alt_sketch_body in alternative_sketches:
                                    if alt_name == base_func_name or alt_name.replace('defsketch_', '') == base_func_name:
                                        match_result = matcher.match_pattern(core_body, alt_sketch_body)
                                        
                                        if match_result:
                                            # Record alternative sketch size, holes count, and completion size
                                            alt_sketch_size = self._count_sexp_size(alt_sketch_body)
                                            alt_holes_count = benchmark._count_holes_in_expression(alt_sketch_body)
                                            completion_size = self._calculate_completion_size(match_result)
                                            bindings_count = len(match_result)
                                            benchmark.set_alternative_sketch_size(core_func_name, alt_sketch_size)
                                            benchmark.set_alternative_holes_count(core_func_name, alt_holes_count)
                                            # Store using standardized mutual recursion name
                                            standardized_core_name = f"mutual-rec-1_core_{i+1}"
                                            benchmark.set_completion_size(standardized_core_name, completion_size)
                                            benchmark.set_actual_bindings_count(standardized_core_name, bindings_count)
                                            benchmark.set_actual_sketch_size(standardized_core_name, alt_sketch_size)

                                            alternative_match_found = True
                                            match_found = True
                                            break
                                
                                # If still no match, try all defsketch alternatives
                                if not alternative_match_found:
                                    for alt_name, alt_sketch_body in alternative_sketches:
                                        match_result = matcher.match_pattern(core_body, alt_sketch_body)
                                        
                                        if match_result:
                                            # Record alternative sketch size, holes count, and completion size
                                            alt_sketch_size = self._count_sexp_size(alt_sketch_body)
                                            alt_holes_count = benchmark._count_holes_in_expression(alt_sketch_body)
                                            completion_size = self._calculate_completion_size(match_result)
                                            bindings_count = len(match_result)
                                            benchmark.set_alternative_sketch_size(core_func_name, alt_sketch_size)
                                            benchmark.set_alternative_holes_count(core_func_name, alt_holes_count)
                                            # Store using standardized mutual recursion name
                                            standardized_core_name = f"mutual-rec-1_core_{i+1}"
                                            benchmark.set_completion_size(standardized_core_name, completion_size)
                                            benchmark.set_actual_bindings_count(standardized_core_name, bindings_count)
                                            benchmark.set_actual_sketch_size(standardized_core_name, alt_sketch_size)

                                            match_found = True
                                            break
                            
                    else:
                        # Regular function - match against corresponding named sketch target
                        matching_sketch = self._find_matching_sketch_target(synth_func_name, sketch_targets)
                        match_found = False
                        
                        if matching_sketch:
                            sketch_name, sketch_body = matching_sketch
                            match_result = matcher.match_pattern(synth_func_body, sketch_body)
                            
                            if match_result:
                                # Calculate and store completion size, bindings count, and sketch size
                                completion_size = self._calculate_completion_size(match_result)
                                bindings_count = len(match_result)
                                sketch_size_used = self._count_sexp_size(sketch_body)
                                benchmark.set_completion_size(synth_func_name, completion_size)
                                benchmark.set_actual_bindings_count(synth_func_name, bindings_count)
                                benchmark.set_actual_sketch_size(synth_func_name, sketch_size_used)

                                match_found = True
                            # If defsketch-tgt match failed, we'll try alternatives below
                        
                        # Try defsketch alternatives if no successful match yet
                        if not match_found:
                            # Try defsketch alternatives as fallback
                            alternative_match_found = False
                            
                            # First try to find a defsketch with matching function name
                            for alt_name, alt_sketch_body in alternative_sketches:
                                if alt_name == synth_func_name or alt_name.replace('defsketch_', '') == synth_func_name:
                                    match_result = matcher.match_pattern(synth_func_body, alt_sketch_body)
                                    
                                    if match_result:
                                        # Record alternative sketch size, holes count, and completion size
                                        alt_sketch_size = self._count_sexp_size(alt_sketch_body)
                                        alt_holes_count = benchmark._count_holes_in_expression(alt_sketch_body)
                                        completion_size = self._calculate_completion_size(match_result)
                                        bindings_count = len(match_result)
                                        benchmark.set_alternative_sketch_size(synth_func_name, alt_sketch_size)
                                        benchmark.set_alternative_holes_count(synth_func_name, alt_holes_count)
                                        benchmark.set_completion_size(synth_func_name, completion_size)
                                        benchmark.set_actual_bindings_count(synth_func_name, bindings_count)
                                        benchmark.set_actual_sketch_size(synth_func_name, alt_sketch_size)

                                        alternative_match_found = True
                                        break
                            
                            # If no named defsketch match, try all defsketch alternatives
                            if not alternative_match_found:
                                for alt_name, alt_sketch_body in alternative_sketches:
                                    match_result = matcher.match_pattern(synth_func_body, alt_sketch_body)
                                    
                                    if match_result:
                                        # Record alternative sketch size, holes count, and completion size
                                        alt_sketch_size = self._count_sexp_size(alt_sketch_body)
                                        alt_holes_count = benchmark._count_holes_in_expression(alt_sketch_body)
                                        completion_size = self._calculate_completion_size(match_result)
                                        bindings_count = len(match_result)
                                        benchmark.set_alternative_sketch_size(synth_func_name, alt_sketch_size)
                                        benchmark.set_alternative_holes_count(synth_func_name, alt_holes_count)
                                        benchmark.set_completion_size(synth_func_name, completion_size)
                                        benchmark.set_actual_bindings_count(synth_func_name, bindings_count)
                                        benchmark.set_actual_sketch_size(synth_func_name, alt_sketch_size)

                                        alternative_match_found = True
                                        break
                            
            except Exception as e:
                print(
                    f"Warning: completion-size pass failed for {benchmark.name}: {e}",
                    flush=True,
                )

        print("Completion size pass finished.", flush=True)

    def _extract_grammar_info(self, benchmark: BenchmarkData) -> Tuple[Dict[str, List[str]], List]:
        """Extract grammar information (hole constraints and grammar rules) from sketch file."""
        import sexpdata as sx
        
        if not benchmark.sketch_file or not benchmark.sketch_file.exists():
            return {}, []
        
        with open(benchmark.sketch_file, 'r') as f:
            content = f.read()
        
        expressions = sx.parse(content)
        hole_grammars = {}  # hole_name -> [non_terminal_names]
        grammar_rules = []  # List of Rule objects (nt, tree, hints)
        all_nts = set()  # Collect all non-terminal names
        
        # First pass: collect all non-terminal names
        for expr in expressions:
            if isinstance(expr, list) and len(expr) > 0:
                if expr[0] == sx.Symbol('defnt') and len(expr) >= 3:
                    nt_name = str(expr[1])
                    all_nts.add(nt_name)
        
        for expr in expressions:
            if isinstance(expr, list) and len(expr) > 0:
                # Parse defhole: (defhole ???1 :bool (B))
                if expr[0] == sx.Symbol('defhole') and len(expr) >= 4:
                    hole_name = str(expr[1])
                    # expr[2] is the type (:bool, :bintree, etc.)
                    non_terminals = expr[3]  # This should be a list of non-terminal names
                    if isinstance(non_terminals, list):
                        hole_grammars[hole_name] = [str(nt) for nt in non_terminals]
                    else:
                        hole_grammars[hole_name] = [str(non_terminals)]
                
                # Parse defnt: (defnt B ((leafp BASE) (< INT INT :distinct) ...))
                elif expr[0] == sx.Symbol('defnt') and len(expr) >= 3:
                    nt_name = str(expr[1])
                    rules_list = expr[2]  # This should be a list of rule expressions
                    if not isinstance(rules_list, list):
                        rules_list = [rules_list]
                    
                    for rule_body in rules_list:
                        # Parse rule body into Tree structure (following synthesis tool logic)
                        parsed_tree, hints = self._parse_rule_body(rule_body, all_nts)
                        grammar_rules.append((nt_name, parsed_tree, hints))
        
        return hole_grammars, grammar_rules
    
    def _extract_base_function_name_from_core(self, core_func_name: str, core_index: int) -> str:
        """
        Extract the base function name from a mutual recursion core function name.
        e.g., "count-leaves-tree-count-leaves-forest-wrapper_core_1" -> "count-leaves-tree"
        """
        # Remove the "_core_N" suffix
        if '_core_' in core_func_name:
            base_wrapper_name = core_func_name.split('_core_')[0]
        else:
            base_wrapper_name = core_func_name
        
        # Remove the "-wrapper" suffix
        if base_wrapper_name.endswith('-wrapper'):
            base_name = base_wrapper_name[:-8]  # Remove "-wrapper"
        else:
            base_name = base_wrapper_name
        
        # For mutual recursion, the function names are typically combined
        # e.g., "count-leaves-tree-count-leaves-forest" contains two function names
        # We need to extract the appropriate one based on the core_index
        
        # Split by common separators and try to identify individual function names
        parts = base_name.split('-')
        
        # Common patterns for mutual recursion function names:
        # Pattern 1: "func1-func2" -> ["func1", "func2"]
        # Pattern 2: "count-leaves-tree-count-leaves-forest" -> need to identify boundaries
        
        # For now, use a heuristic: look for repeated patterns or known function name patterns
        if 'count-leaves' in base_name:
            if core_index == 0:
                return 'count-leaves-tree'
            elif core_index == 1:
                return 'count-leaves-forest'
        
        # Add more patterns as needed for other mutual recursion cases
        if 'is-even' in base_name or 'is-odd' in base_name:
            if core_index == 0:
                return 'is-even'
            elif core_index == 1:
                return 'is-odd'
        
        # Generic fallback: try to split the name and use the core_index
        # This is a simple heuristic that may need refinement
        if len(parts) >= 2:
            # Try to find natural breakpoints
            mid_point = len(parts) // 2
            if core_index == 0:
                return '-'.join(parts[:mid_point])
            else:
                return '-'.join(parts[mid_point:])
        
        # Final fallback: return the original base name
        return base_name
    
    def _calculate_completion_size(self, bindings: Dict[str, Any]) -> int:
        """Calculate the total size of all expressions bound to holes."""
        total_size = 0
        for hole_name, bound_expr in bindings.items():
            total_size += self._count_sexp_size(bound_expr)
        return total_size
    
    def _count_sexp_size(self, expr) -> int:
        """Count the size of an S-expression (same logic as BenchmarkData)."""
        if isinstance(expr, list):
            if len(expr) == 0:
                return 1  # Empty list counts as 1
            # For non-empty lists: 1 + sum of argument sizes (skip the operator/head)
            return 1 + sum(self._count_sexp_size(arg) for arg in expr[1:])
        else:
            return 1  # Any atom (symbol, number, etc.) counts as 1
    
    def _parse_rule_body(self, rule_body, all_nts):
        """Parse a rule body into Tree structure, following synthesis tool logic."""
        import sexpdata as sx
        
        # Extract hints (symbols starting with :)
        if isinstance(rule_body, list):
            hints = [x for x in rule_body if isinstance(x, sx.Symbol) and str(x).startswith(':')]
            clean_body = [x for x in rule_body if not (isinstance(x, sx.Symbol) and str(x).startswith(':'))]
        else:
            hints = []
            clean_body = rule_body
        
        # Parse the clean body recursively
        parsed_tree = self._parse_rule_body_rec(clean_body, all_nts)
        return parsed_tree, hints
    
    def _parse_rule_body_rec(self, rule_body, all_nts):
        """Recursively parse rule body into Terminal/Branch structure."""
        import sexpdata as sx
        
        # If not a list, it's either a non-terminal or terminal
        if not isinstance(rule_body, list):
            if str(rule_body) in all_nts:
                return ('NonTerminal', str(rule_body))
            else:
                return ('Terminal', rule_body)
        
        # Empty list becomes Terminal(False)
        if len(rule_body) == 0:
            return ('Terminal', False)
        
        # Non-empty list becomes Branch
        head = rule_body[0]
        tail = [self._parse_rule_body_rec(x, all_nts) for x in rule_body[1:]]
        return ('Branch', head, tail)
    
    def _extract_sketch_targets(self, benchmark: BenchmarkData) -> Tuple[List[Tuple[str, Any]], List[Tuple[str, Any]]]:
        """Extract defsketch-tgt and defsketch expressions from sketch file."""
        import sexpdata as sx
        
        if not benchmark.sketch_file.exists():
            return [], []
            
        with open(benchmark.sketch_file, 'r') as f:
            content = f.read()
        
        expressions = sx.parse(content)
        sketch_targets = []
        alternative_sketches = []
        
        for expr in expressions:
            if isinstance(expr, list) and len(expr) > 0:
                if expr[0] == sx.Symbol('defsketch-tgt'):
                    if len(expr) >= 2:
                        sketch_body = expr[1]
                        # Function name is the third element (index 2) if present
                        # If no function name, use a default based on position
                        target_name = str(expr[2]) if len(expr) >= 3 else f"target_{len(sketch_targets)+1}"
                        sketch_targets.append((target_name, sketch_body))
                elif expr[0] == sx.Symbol('defsketch'):
                    if len(expr) >= 2:
                        sketch_body = expr[1]
                        # Function name should be the third element (index 2) if present, same as defsketch-tgt
                        # If no function name, use a default based on position
                        func_name = str(expr[2]) if len(expr) >= 3 else f"defsketch_{len(alternative_sketches)+1}"
                        alternative_sketches.append((func_name, sketch_body))
        
        return sketch_targets, alternative_sketches
    
    def _find_matching_sketch_target(self, synth_func_name: str, sketch_targets: List[Tuple[str, Any]]) -> Optional[Tuple[str, Any]]:
        """Find the sketch target that matches the synthesized function name."""
        # Direct name match
        for target_name, sketch_body in sketch_targets:
            if target_name == synth_func_name:
                return (target_name, sketch_body)
        
        # If no direct match, try the first target (fallback for single-function cases)
        if len(sketch_targets) == 1:
            return sketch_targets[0]
            
        # No match found
        return None
    
    def _extract_synthesized_functions(self, benchmark: BenchmarkData, approach: str) -> List[Tuple[str, Any]]:
        """Extract synthesized function bodies."""
        import sexpdata as sx
        import re
        
        if approach not in benchmark.output_files:
            return []
            
        output_file = benchmark.output_files[approach]
        if not output_file.exists():
            return []
            
        with open(output_file, 'r') as f:
            content = f.read()
        
        # Find synthesized functions section
        synth_section_match = re.search(r'; Synthesized functions:\n(\(.*?\n\))', content, re.DOTALL)
        if not synth_section_match:
            return []
            
        synth_content = synth_section_match.group(1)
        parsed_synth = sx.parse(synth_content)
        
        if len(parsed_synth) > 0 and isinstance(parsed_synth[0], list):
            definec_expressions = parsed_synth[0]
        else:
            definec_expressions = parsed_synth
        
        functions = []
        for expr in definec_expressions:
            if isinstance(expr, list) and len(expr) > 0:
                if expr[0] == sx.Symbol('definec') and len(expr) >= 7:
                    func_name = str(expr[1])
                    func_body = expr[-1]  # Last element is the function body
                    functions.append((func_name, func_body))
        
        return functions


class SketchPatternMatcher:
    """Matches synthesized functions against their sketch templates."""
    
    def __init__(self, validate_grammar: bool = True):
        self.validate_grammar = validate_grammar
        self.hole_grammars = {}  # Will store hole -> non-terminals mapping
        self.grammar_rules = {}  # Will store grammar rules
    
    def match_pattern(self, synthesized_expr, sketch_expr) -> Optional[Dict[str, Any]]:
        """
        Match a synthesized expression against a sketch template.
        Returns a dictionary mapping hole names (like "???1") to their bound expressions.
        Returns None if no match is possible.
        """
        bindings = {}
        if self._match_recursive(synthesized_expr, sketch_expr, bindings):
            # Validate grammar constraints if enabled
            if self.validate_grammar and not self._validate_grammar_constraints(bindings):
                return None
            return bindings
        else:
            return None
    
    def _match_recursive(self, synthesized, sketch, bindings: Dict[str, Any]) -> bool:
        """
        Recursively match synthesized expression against sketch template.
        Updates bindings dictionary and returns True if match succeeds.
        """
        import sexpdata as sx
        
        # Case 1: Sketch is a hole (symbol starting with ???)
        if isinstance(sketch, sx.Symbol) and str(sketch).startswith('???'):
            hole_name = str(sketch)
            
            # Check if this hole was already bound
            if hole_name in bindings:
                # Must match existing binding exactly
                return self._expressions_equal(synthesized, bindings[hole_name])
            else:
                # Bind hole to synthesized expression
                bindings[hole_name] = synthesized
                return True
        
        # Case 2: Both are atoms (not lists) - must be equal
        if not isinstance(synthesized, list) and not isinstance(sketch, list):
            return self._expressions_equal(synthesized, sketch)
        
        # Case 3: One is list, other is atom - no match
        if isinstance(synthesized, list) != isinstance(sketch, list):
            return False
        
        # Case 4: Both are lists - must have same length and all elements match
        if isinstance(synthesized, list) and isinstance(sketch, list):
            if len(synthesized) != len(sketch):
                return False
            
            # Recursively match all elements
            for synth_elem, sketch_elem in zip(synthesized, sketch):
                if not self._match_recursive(synth_elem, sketch_elem, bindings):
                    return False
            
            return True
        
        # Should not reach here
        return False
    
    def _expressions_equal(self, expr1, expr2) -> bool:
        """Check if two S-expressions are structurally equal."""
        import sexpdata as sx
        
        # Handle different types
        if type(expr1) != type(expr2):
            return False
        
        # Both are symbols
        if isinstance(expr1, sx.Symbol) and isinstance(expr2, sx.Symbol):
            return str(expr1) == str(expr2)
        
        # Both are lists
        if isinstance(expr1, list) and isinstance(expr2, list):
            if len(expr1) != len(expr2):
                return False
            return all(self._expressions_equal(e1, e2) for e1, e2 in zip(expr1, expr2))
        
        # Both are other types (numbers, strings, etc.)
        return expr1 == expr2
    
    def set_grammar_info(self, hole_grammars: Dict[str, List[str]], grammar_rules: List):
        """Set grammar information for validation."""
        self.hole_grammars = hole_grammars
        self.grammar_rules = grammar_rules
    
    def _validate_grammar_constraints(self, bindings: Dict[str, Any]) -> bool:
        """
        Validate that hole bindings respect their grammar constraints.
        Following the exact logic from Tool.py validate_sol_grammar.
        """
        if not self.hole_grammars or not self.grammar_rules:
            # No grammar info available, skip validation
            return True
        
        # For each hole, check if ANY of its non-terminals can generate the bound expression
        for hole_name, bound_expr in bindings.items():
            if hole_name not in self.hole_grammars:
                continue  # No grammar constraint for this hole
            
            nt_seq = self.hole_grammars[hole_name]  # List of non-terminal names
            # Check: any(grammar.generates(nt, expr) for nt in nt_seq)
            can_generate = any(self._generates(nt_name, bound_expr) for nt_name in nt_seq)
            
            if not can_generate:
                return False
        
        return True
    
    def _generates(self, nt_name: str, expr) -> bool:
        """
        Check if a non-terminal can generate the given expression.
        Implements the exact logic from Grammar.generates in Instance.py.
        """
        import sexpdata as sx
        
        # Find all rules for this non-terminal
        for rule_nt, rule_tree, rule_hints in self.grammar_rules:
            if rule_nt != nt_name:
                continue
            
            # Check if this rule can generate the expression
            if self._tree_generates(rule_tree, expr):
                return True
        
        return False
    
    def _tree_generates(self, rule_tree, expr) -> bool:
        """
        Check if a rule tree can generate the expression.
        Implements the logic from Grammar.generates for Terminal/Branch trees.
        """
        import sexpdata as sx
        
        tree_type = rule_tree[0]
        
        if tree_type == 'Terminal':
            # Terminal rule: direct comparison using sx.dumps
            terminal_value = rule_tree[1]
            return sx.dumps(terminal_value) == sx.dumps(expr)
        
        elif tree_type == 'Branch':
            # Branch rule: (head, [child_trees])
            branch_head = rule_tree[1]
            branch_children = rule_tree[2]
            
            # Expression must be a non-empty list
            if not isinstance(expr, list) or len(expr) == 0:
                return False
            
            # Head must match
            if branch_head != expr[0]:
                return False
            
            # Number of children must match
            if len(branch_children) != len(expr) - 1:
                return False
            
            # All children must match recursively
            for child_tree, sub_expr in zip(branch_children, expr[1:]):
                if child_tree[0] == 'NonTerminal':
                    # Recursive call to generates for non-terminal
                    child_nt_name = child_tree[1]
                    if not self._generates(child_nt_name, sub_expr):
                        return False
                else:
                    # Direct tree match for terminal/branch
                    if not self._tree_generates(child_tree, sub_expr):
                        return False
            
            return True
        
        else:
            # Unknown tree type
            return False


def test_pattern_matching():
    """Test cases for the pattern matching module."""
    import sexpdata as sx
    
    matcher = SketchPatternMatcher()
    
    print("=== PATTERN MATCHING TEST CASES ===\n")
    
    # Test Case 1: Perfect Match - List Insertion (Reference Implementation)
    print("Test Case 1: Perfect Match - List Insertion")
    sketch_1 = sx.parse("(if ???1 ???2 (icons ???3 (contata-list-insertion ???4 ???5)))")[0]
    synthesized_1 = sx.parse("(if (inilp xs) (icons x 'inil) (icons (ihead xs) (contata-list-insertion x (itail xs))))")[0]
    
    print("Sketch:")
    print(sx.dumps(sketch_1, pretty_print=True))
    print("\nSynthesized:")
    print(sx.dumps(synthesized_1, pretty_print=True))
    
    expected_bindings_1 = {
        "???1": "(inilp xs)",
        "???2": "(icons x 'inil)", 
        "???3": "(ihead xs)",
        "???4": "x",
        "???5": "(itail xs)"
    }
    print(f"\nExpected bindings: {expected_bindings_1}")
    
    result_1 = matcher.match_pattern(synthesized_1, sketch_1)
    print(f"Actual result: {result_1}")
    print(f"Should succeed: {result_1 is not None}")
    print()
    
    # Test Case 2: Structural Mismatch - BST Insertion (Missing Equality Check)
    print("Test Case 2: Structural Mismatch - BST Insertion")
    sketch_2 = sx.parse("(if ???1 ???2 (if ???3 ???4 (if ???5 (node (contata-insert ???6 ???7) ???8 ???9) (node ???10 ???11 (contata-insert ???12 ???13)))))")[0]
    synthesized_2 = sx.parse("(if (leafp tr) (node 'leaf x 'leaf) (if (< x (bt-value tr)) (node (contata-insert x (bt-left tr)) (bt-value tr) (bt-right tr)) (node (bt-left tr) (bt-value tr) (contata-insert x (bt-right tr)))))")[0]
    
    print("Sketch:")
    print(sx.dumps(sketch_2, pretty_print=True))
    print("\nSynthesized:")
    print(sx.dumps(synthesized_2, pretty_print=True))
    
    print("\nExpected: No match (synthesized has 2 conditions, sketch expects 3)")
    
    result_2 = matcher.match_pattern(synthesized_2, sketch_2)
    print(f"Actual result: {result_2}")
    print(f"Should fail: {result_2 is None}")
    print()
    
    # Test Case 3: Simple Atom Match
    print("Test Case 3: Simple Atom Match")
    sketch_3 = sx.parse("???1")[0]
    synthesized_3 = sx.parse("(leafp tr)")[0]
    
    print(f"Sketch: {sketch_3}")
    print(f"Synthesized: {sx.dumps(synthesized_3)}")
    
    expected_bindings_3 = {"???1": "(leafp tr)"}
    print(f"Expected bindings: {expected_bindings_3}")
    
    result_3 = matcher.match_pattern(synthesized_3, sketch_3)
    print(f"Actual result: {result_3}")
    print(f"Should succeed: {result_3 is not None}")
    print()
    
    # Test Case 4: Inconsistent Hole Bindings
    print("Test Case 4: Inconsistent Hole Bindings")
    sketch_4 = sx.parse("(if ???1 ???1 ???2)")[0]  # Same hole used twice
    synthesized_4 = sx.parse("(if (leafp tr) (nilp xs) 42)")[0]  # Different expressions for same hole
    
    print("Sketch:")
    print(sx.dumps(sketch_4, pretty_print=True))
    print("\nSynthesized:")
    print(sx.dumps(synthesized_4, pretty_print=True))
    
    print("\nExpected: No match (???1 would bind to both '(leafp tr)' and '(nilp xs)')")
    
    result_4 = matcher.match_pattern(synthesized_4, sketch_4)
    print(f"Actual result: {result_4}")
    print(f"Should fail: {result_4 is None}")
    print()
    
    # Test Case 5: Partial Match with Extra Structure
    print("Test Case 5: Partial Match with Extra Structure")
    sketch_5 = sx.parse("(if ???1 ???2 ???3)")[0]
    synthesized_5 = sx.parse("(if (leafp tr) (node 'leaf x 'leaf) (if (< x y) left right))")[0]
    
    print("Sketch:")
    print(sx.dumps(sketch_5, pretty_print=True))
    print("\nSynthesized:")
    print(sx.dumps(synthesized_5, pretty_print=True))
    
    expected_bindings_5 = {
        "???1": "(leafp tr)",
        "???2": "(node 'leaf x 'leaf)",
        "???3": "(if (< x y) left right)"
    }
    print(f"Expected bindings: {expected_bindings_5}")
    
    result_5 = matcher.match_pattern(synthesized_5, sketch_5)
    print(f"Actual result: {result_5}")
    print(f"Should succeed: {result_5 is not None}")
    print()
    
    # Test Case 6: Reference Implementation Match (Target = Synthesized)
    print("Test Case 6: Reference Implementation Match")
    target_6 = sx.parse("(if (inilp xs) (icons x 'inil) (icons (ihead xs) (contata-list-insertion x (itail xs))))")[0]
    sketch_6 = sx.parse("(if ???1 ???2 (icons ???3 (contata-list-insertion ???4 ???5)))")[0]
    
    print("Target (used as synthesized):")
    print(sx.dumps(target_6, pretty_print=True))
    print("\nSketch:")
    print(sx.dumps(sketch_6, pretty_print=True))
    
    print("\nExpected: Perfect match (reference implementations should always match)")
    
    result_6 = matcher.match_pattern(target_6, sketch_6)
    print(f"Actual result: {result_6}")
    print(f"Should succeed: {result_6 is not None}")
    print()


def main():
    parser = argparse.ArgumentParser(description='Analyze benchmark synthesis data')
    parser.add_argument(
        "--data-dir",
        "-d",
        default=_DEFAULT_DATA_DIR,
        help=(
            "Directory containing benchmark data "
            f"(default: {_DEFAULT_DATA_DIR})"
        ),
    )
    parser.add_argument('--input-dir', '-i',
                       help='Directory containing input files (overrides data-dir/inputs)')
    parser.add_argument('--output-dir', '-o',
                       help='Base directory containing output subdirectories (overrides data-dir)')
    parser.add_argument('--approach', '-a',
                       default="proph", 
                       choices=["proph", "retro", "brute"],
                       help='Analysis approach to use (default: proph)')
    
    args = parser.parse_args()
    
    # Determine input and output directories
    if args.input_dir:
        input_dir = args.input_dir
    else:
        input_dir = f"{args.data_dir}/inputs"
    
    if args.output_dir:
        output_base_dir = args.output_dir
    else:
        output_base_dir = args.data_dir
    
    approach = args.approach
    
    print(f"Analyzing benchmark data:")
    print(f"  Input directory: {input_dir}")
    print(f"  Output base directory: {output_base_dir}")
    print(f"  Using approach: {approach}")
    
    analyzer = BenchmarkAnalyzer(input_dir, output_base_dir, approach)
    analyzer.analyze()
    
    print(
        "Sizing hole completions from inputs and synthesis output...",
        flush=True,
    )
    analyzer.analyze_pattern_matching(approach)
    
    # Print final master table with alternative sketch information
    analyzer.print_table(approach)
    
    # Print summary table with selected columns
    print("\n" + "=" * 80)
    print("SUMMARY TABLE")
    print("=" * 80)
    summary_table = BenchmarkSummaryTable(analyzer.benchmarks, approach)
    print(summary_table.render())
    
    analyzer.print_summary_statistics(approach)
    analyzer.print_detailed_breakdown()


if __name__ == "__main__":
    # Uncomment to run pattern matching tests
    # test_pattern_matching()
    main()
