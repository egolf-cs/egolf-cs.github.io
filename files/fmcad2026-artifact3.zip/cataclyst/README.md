# Cataclyst Artifact

## Inputs

Our benchmarks are in the `inputs` directory. Each `*.lisp` file is the
top-level entry point for a benchmark. Benchmarks prefixed with `unreal-`
correspond to unrealizable benchmarks. Top-level entry points may load other
files with `ld` directives. E.g., all benchmarks load their `sketch/` file from
that directory. Many benchmarks depend on libraries in the `lib/` directory.
Some benchmarks have a common preamble that is loaded from `preambles/`. Mixed
quantifier benchmarks encode the mixed quantifier property as an `smt2` file in
the `smt/` directory. 

Sketch files often contain a `deftgt` directive that gives a reference solution
for the problem. We emphasize that this exists only for the sake of debugging
and is not used to compute the solution.

## Outputs

The `FROZEN_OUTPUT/` directory contains the data we report in our paper. The
lisp files in this directory contain the synthesized function(s) and the timing
data. We note that we measure "tgt-validation-time" and "total-solve-time"
separately. The former is the time taken to validate our reference
implementation (again, for debugging), and the latter is the time taken to
synthesize the solution. We report "total-solve-time" in the paper.

The acl2s files in the `FROZEN_OUTPUT/` directory can be run with ACL2s. They
contain the auxiliary definitions, synthesized functions, and properties from
which the functions were synthesized (as `defthm`s). 

Run `python summary.py` to get a summary of the results in `FROZEN_OUTPUT/`.
This will produce an ascii table that is equivalent to the one in Appendix A
of our paper.

## Proofs

See `proofs/README.md` for details about proofs.

## Setup

If you wish to run the code, you will need to install acl2s and add it to your
path.

[ACL2s Installation Scripts](https://gitlab.com/acl2s/external-tool-support/scripts)

You will also need to install the following python packages:

```bash
pip install sexpdata jinja2 pexpect z3-solver graphviz call-function-with-timeout matplotlib
```

## Smoke Test

To run one benchmark with one of the variants (proph, retro, no-gen), run, e.g.:

```bash
python driver.py inputs/contata-list-insertion.lisp --proph
python driver.py inputs/contata-list-insertion.lisp --retro
python driver.py inputs/contata-list-insertion.lisp --no-gen
```

Each of the above takes ~10s.

Data will be written to `output/output-{proph,retro,brute}`. This data will
have the same anatomy as the data in `FROZEN_OUTPUT/` but will not be frozen.
Note: the `--no-gen` variant writes to `output/output-brute`.

## Running Cataclyst

The following commands summarize the usage of `driver.py`. Time estimates
below are based on the data in `FROZEN_OUTPUT/` and may vary with hardware.

To run all benchmarks with one of the variants, run, e.g.:

```bash
python driver.py inputs/ --proph
```

The above takes ~3h.

To run all benchmarks with all variants, run:

```bash
python driver.py inputs/ --all
```

The above takes ~25.5h.

To exclude benchmarks beginning with `unreal-` run, e.g.:

```bash
python driver.py inputs/ --all --exclude-unreal
python driver.py inputs/ --proph --exclude-unreal
```

The above take ~6.5h and ~45min, respectively.

To run ONLY benchmarks beginning with `unreal-` run, e.g.:

```bash
python driver.py inputs/ --all --only-unreal
python driver.py inputs/ --proph --only-unreal
```

The above take ~19h and ~2h, respectively.

We recommend running the following:

```bash
python driver.py inputs/ --proph --exclude-unreal
python driver.py inputs/ --retro --exclude-unreal
python driver.py inputs/ --no-gen --exclude-unreal
python driver.py inputs/ --proph --only-unreal
python driver.py inputs/ --retro --only-unreal
python driver.py inputs/ --no-gen --only-unreal
```

The above take ~45min, ~2h, ~3.5h, ~2h, ~7.5h, and ~9h,
respectively.

