from pprint import pprint
from Generalizer import PruningConstraint, satisfies_constraints
from Structs import Tree, Terminal

class ConstrainedProduct:

    def __init__(self, xss):
        self.xss = xss
        # print("xss", xss, flush=True)
        self.constraints : list[PruningConstraint] = []
        self.gen = self._mk_generator()

    def bad_prefix(self, prefix):
        for constraint in self.constraints:
            max_idx = max([x[0] for x in constraint.clauses])
            if len(prefix) <= max_idx:
                continue
            if not constraint.sat(prefix):
                return True
        return False

    def _mk_generator_rec(self, prefix):
        depth = len(prefix)
        if self.bad_prefix(prefix):
            return None
        if depth == len(self.xss): 
            yield prefix
            return None
        for x in self.xss[depth]:
            assert isinstance(x, Tree)
            new_prefix = prefix + [x]
            for result in self._mk_generator_rec(new_prefix):
                yield result
        return None

    def _mk_generator(self):
        return self._mk_generator_rec([])

    def next(self):
        # print("XSS")
        # pprint(self.xss)
        # print("XSS end", flush=True)
        return next(self.gen, None)

class ConstrainedChain:

    def __init__(self):
        self.constraints : list[PruningConstraint] = []
        self.products = []
        self.current_product = None

    def next(self):
        while True:
            # print("# products:", len(self.products), flush=True)
            if self.current_product is None:
                succ = self.mk_next_product()
                if not succ:
                    return None
            assert isinstance(self.current_product, ConstrainedProduct)
            # print("Querying current product for next tuple...", flush=True)
            nxt = self.current_product.next()
            # print(">>>")
            if nxt is None:
                # print("Current product exhausted, moving to next product.", flush=True)
                succ = self.mk_next_product()
                if not succ:
                    return None
                continue
            violation = satisfies_constraints(nxt, self.constraints)
            # violation = self.satisfies_constraints(nxt)
            if violation is not None:
                raise ValueError(
                    "Generated tuple does not satisfy constraints: "
                    f"{nxt} with constraints {self.constraints}")
            return nxt 

    def satisfies_constraints(self, tpl):
        return satisfies_constraints(tpl, self.constraints)

    def mk_next_product(self):
        if len(self.products) == 0:
            return None
        self.current_product = self.products.pop(0)
        self.current_product.constraints = self.constraints
        return self.current_product

    def add_constraint(self, constraint : PruningConstraint):
        # print("Adding constraint", constraint)
        self.constraints.append(constraint)
        if self.current_product is not None:
            assert len(self.constraints) == len(self.current_product.constraints)

    def add_product(self, product):
        if not isinstance(product, ConstrainedProduct):
            raise ValueError("Only ConstrainedProduct instances can be added.")
        self.products.append(product)

if __name__ == "__main__":
    cc = ConstrainedChain()
    pc = PruningConstraint([(2, Terminal(6))], 0)
    # for x in range(10):
    cnt = 0
    # for x in range(2):
    xs1 = [Terminal(1), Terminal(2), Terminal(3)]
    xs2 = [Terminal(4), Terminal(5)]
    xs3 = [Terminal(6), Terminal(7)]
    cp = ConstrainedProduct([xs1, xs2, xs3])
    cc.add_product(cp)
    # cc.add_constraint(pc)
    while True:
        tpl = cc.next()
        if tpl is None:
            print("Exhausted")
            break
        # if tpl[2] == Terminal(6) and x == 0:
        if tpl[2] == Terminal(6):
            # print("Adding constraint")
            cc.add_constraint(pc)
        cnt += 1
        print("tpl:", tpl)
    
    print("Done generating tuples.")
    print("Generated", cnt, "tuples.")
    print("Expected:", len(xs1) * len(xs2) * len(xs3), "tuples.")
