import sexpdata as sx
from Structs import Expression, UserSpace
from Structs import dumps

class ContractViolation:
    pass

class PropagateError(Exception):
    pass

class OuterPropagateError(Exception):
    pass



# deprecated
def is_tree(x):
    if is_nil(x):
        return False
    if isinstance(x, list):
        if isinstance(x[0], int):
            return all(is_tree(y) for y in x[1:])
        return False
    if isinstance(x, sx.Quoted):
        xx = x.x
        if not isinstance(xx, sx.Symbol):
            raise ValueError(f"Expected a symbol in quoted value, got {xx}")
        sxx = dumps(xx).strip().lower()
        if sxx == "leaf":
            return True
        raise ValueError(
            f"Unexpected quoted value: {x}. This error may be spurious.")
    return False

# deprecated
def is_forest(x):
    if not isinstance(x, list):
        return False
    return all(is_tree(y) for y in x)

def is_nil(x):
    if isinstance(x, list):
        return len(x) == 0
    if isinstance(x, bool):
        return not x
    return False

def is_list(x):
    if isinstance(x, list):
        return True
    if isinstance(x, bool):
        return not x
    return False

def cons(head, tail):
    if isinstance(tail, bool) and not tail:
        return [head]
    if isinstance(tail, list):
        return [head] + tail
    raise ValueError(f"Expected a list or nil for tail, got {tail}")

def is_str(x):
    return (
        (not isinstance(x, sx.Symbol))
        and (not isinstance(x, sx.Quoted))
        and isinstance(x, str))

def acl2s_size(x):
    if is_nil(x):
        return 0
    if isinstance(x, list):
        assert len(x) > 0
        return 1 + acl2s_size(x[0]) + acl2s_size(x[1:])
    if isinstance(x, int):
        return abs(x)
    if is_str(x):
        return len(x)
    return 0


# deprecated
def is_bintree_rec(x):
    if is_nil(x):
        return True
    if not isinstance(x, list):
        return False
    if len(x) != 3:
        return False
    left, value, right = x
    if not is_bintree_rec(left):
        return False
    if not is_bintree_rec(right):
        return False
    if not isinstance(value, int):
        return False
    return True

# deprecated
def is_terntree_rec(x):
    if is_nil(x):
        return True
    if not isinstance(x, list):
        return False
    if len(x) != 4:
        return False
    left, value, middle, right = x
    if not is_terntree_rec(left):
        return False
    if not is_terntree_rec(middle):
        return False
    if not is_terntree_rec(right):
        return False
    if not isinstance(value, int):
        return False
    return True
    
def _local_eval(expr : Expression, sub, user_sp, depth):
    try:
        res = __local_eval(expr, sub, user_sp, depth+1)
    except PropagateError:
        print("Offender:", expr, type(expr), flush=True)
        print("Substitution:", sub, flush=True)
        if isinstance(expr, list) and len(expr) == 3:
            left = __local_eval(expr[1], sub, user_sp, depth+2)
            right = __local_eval(expr[2], sub, user_sp, depth+2)
            print("Left:", left, type(left))
            print("Right:", right, type(right))
        raise OuterPropagateError()
    if (
            isinstance(res, list) 
            and len(res) != 0 
            and res[0] in [sx.Symbol("."), sx.Quoted(sx.Symbol("."))]):
        raise ValueError(
            "Found '.' in head of result. This indicates a fatal parsing error"
            " in another part of the code. Sorry.")
    return res

def __local_eval(expr : Expression, sub, user_sp, depth):
    if sub is None:
        sub = dict()
    sub = dict(sub)
    if isinstance(expr, bool):
        if expr:
            return True
        else:
            return False
    if isinstance(expr, int):
        return expr
    if isinstance(expr, sx.Symbol):
        if expr in sub:
            return sub[expr]
        raise ValueError(f"Symbol {expr} not found in substitution {sub}")
    if is_str(expr):
        return expr
    if isinstance(expr, sx.Quoted):
        arg = expr.x
        if isinstance(arg, int):
            return arg
        if isinstance(arg, bool):
            return arg
        if is_str(arg):
            return arg
        if isinstance(arg, sx.Symbol):
            if arg in sub:
                raise ValueError(
                    "Found quoted variable in expression. This error may"
                    f" be spurious... expr: {expr}")
            return expr
        if len(arg) == 0:
            return []
        new_arg = []
        for a in arg:
            if a == sx.Symbol("."):
                raise ValueError(
                    "Found '.' in quoted expression. Support for this is"
                    " not yet implemented. Consider refactoring so that '.'"
                    " is not used in your code and so that counterexamples"
                    " returned by acl2s do not contain '.'. Concretely, see"
                    " if any defdata definitions have cons x y, where y is not"
                    " a cons. Alternatively, contribute to local_eval.py.")
            new_arg.append(sx.Quoted(a))
        return [_local_eval(a, sub, user_sp, depth) for a in new_arg]


    if not isinstance(expr, list):
        raise ValueError(f"Expected a list, got {expr}")

    if len(expr) == 0:
        return []


    head, tail = expr[0], expr[1:]
    if not isinstance(head, sx.Symbol):
        raise ValueError(
            f"Expected a symbol, got head={head} in expr={expr}."
            f" This may be due to a '(X Y Z) quoted list form. Replace"
            " '(X Y Z) with (list X Y Z)")
    if head in [sx.Symbol("."), sx.Quoted(sx.Symbol("."))]:
        raise ValueError(
            "Found '.' as head of expression. This indicates a"
            " fatal parsing error in another part of the code."
            " cons as . is not well supported."
            " Sorry.")

    user_sp.trace(head)

    if user_sp.member(head):
        uf = user_sp.get(head)
        args = uf.args
        body = uf.body
        guard = uf.guard()
        if len(tail) != len(args):
            raise ValueError(f"Expected {len(args)} arguments for {head}, got {len(tail)}")
        new_sub = {
            arg : _local_eval(value, sub, user_sp, depth)
            for arg, value in zip(args, tail)
        }
        user_sp.extended_trace_note_user_call(
            head,
            [new_sub[arg] for arg in args],
        )
        sub.update(new_sub)
        if guard is not None:
            gvalue = _local_eval(guard, sub, user_sp, depth)
            if not gvalue:
                raise PropagateError()
        return _local_eval(body, sub, user_sp, depth)

    if head == sx.Symbol("let"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for let, got {expr}")
        bindings, body = tail[0], tail[1]
        if not isinstance(bindings, list):
            raise ValueError(f"Expected a list of bindings, got {bindings}")
        new_subs = dict()
        for binding in bindings:
            if not isinstance(binding, list):
                raise ValueError(f"Expected a list for binding, got {binding}")
            if len(binding) != 2:
                raise ValueError(f"Expected a binding of the form (name value), got {binding}")
            name, raw_value = binding
            if not isinstance(name, sx.Symbol):
                raise ValueError(f"Expected a symbol for name, got {name}")
            value = _local_eval(raw_value, sub, user_sp, depth)
            new_subs[name] = value
        sub.update(new_subs)
        return _local_eval(body, sub, user_sp, depth)
    if head == sx.Symbol("equal"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for equal, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        return left == right
    if head == sx.Symbol("list"):
        return [_local_eval(arg, sub, user_sp, depth) for arg in tail]
    if head == sx.Symbol("if"):
        if len(tail) != 3:
            raise ValueError(f"Expected three arguments for if, got {expr}")
        condition, true_branch, false_branch = tail
        condition_value = _local_eval(condition, sub, user_sp, depth)
        if not is_nil(condition_value):
            return _local_eval(true_branch, sub, user_sp, depth)
        else:
            return _local_eval(false_branch, sub, user_sp, depth)
    if head == sx.Symbol("ite"):
        if len(tail) != 3:
            raise ValueError(f"Expected three arguments for if, got {expr}")
        condition, true_branch, false_branch = tail
        condition_value = _local_eval(condition, sub, user_sp, depth)
        if not is_nil(condition_value):
            return _local_eval(true_branch, sub, user_sp, depth)
        else:
            return _local_eval(false_branch, sub, user_sp, depth)
    if head == sx.Symbol("and"):
        return all(not is_nil(_local_eval(arg, sub, user_sp, depth)) for arg in tail)
    if head == sx.Symbol("or"):
        return any(not is_nil(_local_eval(arg, sub, user_sp, depth)) for arg in tail)
    if head == sx.Symbol("not"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for not, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        return is_nil(arg)
    if head == sx.Symbol("=>"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for =>, got {expr}")
        p, q = tail
        p_value = _local_eval(p, sub, user_sp, depth)
        if is_nil(p_value):
            return True
        q_value = _local_eval(q, sub, user_sp, depth)
        if is_nil(q_value):
            return False
        return q_value
       
    if head == sx.Symbol("boolp"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for boolp, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        return is_nil(arg) or isinstance(arg, bool)
    if head == sx.Symbol("natp"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for natp, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        return isinstance(arg, int) and arg >= 0
    if head == sx.Symbol("intp"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for intp, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        return isinstance(arg, int)
    if head == sx.Symbol("zp"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for zp, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        return arg == 0
    if head == sx.Symbol("<"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for <, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not isinstance(left, int) or not isinstance(right, int):
            raise PropagateError()
        return left < right
    if head == sx.Symbol(">"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for >, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not isinstance(left, int) or not isinstance(right, int):
            raise PropagateError()
        return left > right
    if head == sx.Symbol("<="):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for <=, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not isinstance(left, int) or not isinstance(right, int):
            raise PropagateError()
        return left <= right
    if head == sx.Symbol(">="):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for >=, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not isinstance(left, int) or not isinstance(right, int):
            raise PropagateError()
        return left >= right
    if head == sx.Symbol("+"):
        res = 0
        for arg in tail:
            term = _local_eval(arg, sub, user_sp, depth)
            if not isinstance(term, int):
                raise PropagateError()
            res += term
        return res
    if head == sx.Symbol("-"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for -, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not isinstance(left, int) or not isinstance(right, int):
            raise PropagateError()
        return left - right
    if head == sx.Symbol("*"):
        res = 1
        for arg in tail:
            term = _local_eval(arg, sub, user_sp, depth)
            if not isinstance(term, int):
                raise PropagateError()
            res *= term
        return res
    if head == sx.Symbol("1-"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for 1-, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not isinstance(arg, int):
            raise PropagateError()
        return arg - 1
    if head == sx.Symbol("1+"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for 1+, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not isinstance(arg, int):
            raise PropagateError()
        return arg + 1
    if head == sx.Symbol("max"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for max, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not isinstance(left, int) or not isinstance(right, int):
            raise PropagateError()
        return max(left, right)
    if head == sx.Symbol("min"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for min, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not isinstance(left, int) or not isinstance(right, int):
            raise PropagateError()
        return min(left, right)
    if head == sx.Symbol("endp"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for endp, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        return is_nil(arg)
    if head == sx.Symbol("consp"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for consp, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if is_nil(arg):
            return False
        return is_list(arg)
    if head == sx.Symbol("allp"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for allp, got {expr}")
        tail = _local_eval(tail[0], sub, user_sp, depth)
        return True
    if head == sx.Symbol("member"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for member, got {expr}")
        element = _local_eval(tail[0], sub, user_sp, depth)
        lst = _local_eval(tail[1], sub, user_sp, depth)
        if not is_list(lst):
            raise PropagateError()
        if is_nil(lst):
            return False
        if element not in lst:
            return False
        idx = lst.index(element)
        return lst[idx:]
    if head == sx.Symbol("length"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for length, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        if is_nil(arg):
            return 0
        return len(arg)
    if head == sx.Symbol("cons"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for cons, got {expr}")
        head_value = _local_eval(tail[0], sub, user_sp, depth)
        tail_value = _local_eval(tail[1], sub, user_sp, depth)
        if not is_list(tail_value):
            raise PropagateError()
        return cons(head_value, tail_value)
    if head == sx.Symbol("flatten"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for flatten, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        if is_nil(arg):
            return []
        res = []
        for item in arg:
            if not is_list(item):
                raise PropagateError()
            if is_nil(item):
                continue
            res += item
        return res
    if head == sx.Symbol("append"):
        if len(tail) != 2:
            raise ValueError(f"Expected two arguments for append, got {expr}")
        left = _local_eval(tail[0], sub, user_sp, depth)
        right = _local_eval(tail[1], sub, user_sp, depth)
        if not is_list(left) or not is_list(right):
            raise PropagateError()
        if is_nil(left):
            return right
        if is_nil(right):
            return left
        return left + right
    if head == sx.Symbol("second"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for second, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        if is_nil(arg) or len(arg) < 2:
            return []
        return arg[1]
    if head == sx.Symbol("third"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for third, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        if is_nil(arg) or len(arg) < 3:
            return []
        return arg[2]
    if head == sx.Symbol("fourth"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for fourth, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        if is_nil(arg) or len(arg) < 4:
            return []
        return arg[3]
    if head in [sx.Symbol("car"), sx.Symbol("first")]:
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for car, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        if is_nil(arg):
            return []
        return arg[0]
    if head == sx.Symbol("cdr"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for cdr, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if not is_list(arg):
            raise PropagateError()
        if is_nil(arg):
            return []
        return arg[1:]
    if head == sx.Symbol("atom"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for atom, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        return not is_list(arg)
    if head == sx.Symbol("head"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for head, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if is_nil(arg):
            raise PropagateError()
        if not isinstance(arg, list):
            raise PropagateError()
        return arg[0]
    if head == sx.Symbol("tail"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for tail, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        if is_nil(arg):
            raise PropagateError()
        if not isinstance(arg, list):
            raise PropagateError()
        return arg[1:]
    if head == sx.Symbol("acl2s-size"):
        if len(tail) != 1:
            raise ValueError(f"Expected one argument for acl2s-size, got {expr}")
        arg = _local_eval(tail[0], sub, user_sp, depth)
        return acl2s_size(arg)
    if head == sx.Symbol("match"):
        if len(tail) < 1:
            raise ValueError(f"Expected at least one argument for match, got {expr}")
        arg_expr, *clauses = tail

        if not isinstance(arg_expr, sx.Symbol):
            raise ValueError(f"Expected a symbol as match argument, got {arg_expr}")

        if arg_expr not in sub:
            raise ValueError(f"Match variable {arg_expr} not found in substitution")

        val = sub[arg_expr]

        for clause in clauses:
            assert isinstance(clause, list)
            if len(clause) != 2:
                raise ValueError(f"Invalid clause in match: {clause}")
            pattern, body = clause

            if not isinstance(pattern, list) or len(pattern) < 1:
                raise ValueError(f"Match pattern must be a non-empty list, got: {pattern}")

            tag = pattern[0]
            binders = pattern[1:]

            if not isinstance(tag, sx.Quoted) or not isinstance(tag.x, sx.Symbol):
                raise ValueError(f"First element of pattern must be a quoted symbol, got: {tag}")

            if not all(isinstance(sym, sx.Symbol) for sym in binders):
                raise ValueError(f"All binders in match pattern must be symbols, got: {binders}")

            if not (is_list(val) and len(val) == len(binders) + 1):
                continue  # try next clause

            if not isinstance(val[0], sx.Quoted) or val[0] != tag:
                continue  # tag doesn't match

            bindings = dict(zip(binders, val[1:]))
            new_sub = dict(sub)
            new_sub.update(bindings)
            return _local_eval(body, new_sub, user_sp, depth)

        raise ValueError(f"Match failure: no clause matched argument value {val}")


    raise ValueError(
        f"Unknown function {head} in {expr}. if {head} is defdata predicate,"
        f" you may need to manually add it as deflocal, written in terms of"
        f" acl2s primitives supported in local_eval.py. E.g. see int-listp in"
        f" examples. If {head} is an acl2s primitive, you may need to add it"
        f" to local_eval.py. Sorry.")

def local_eval(expr: Expression, sub=None, user_space=None) -> Expression|ContractViolation:
    if sub is None:
        sub = dict()
    sub = dict(sub)
    if user_space is None:
        user_space = UserSpace([])
    try:
        return _local_eval(expr, sub, user_space, 0)
    except OuterPropagateError:
        return ContractViolation()

if __name__ == "__main__":
    # test = "(let ((xs ()) (ys '(1))) (if (and (not (endp xs))) (memberp (head xs) xs) t))"
    # test = "(let ((xs ()) (ys '(1))) (and (not (endp xs))))"
    test = "(let ((xs ()) (ys '(1))) (not (endp xs)))"
    test = """
(let ((ys '(0)) (xs '(115 -2 0))) 
    (if (and (and (int-listp xs) (int-listp ys)) (and (not (endp xs)))) 
        (< (m xs xs) (m xs ys)) 
        t))
"""
    test = """
(let ((ys '(0)) (xs '(115 -2 0))) (int-listp xs))
"""
    expr = sx.loads(test)
    result = local_eval(expr)
    print(f"Result: {result}")

            



