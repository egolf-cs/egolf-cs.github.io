from pprint import pprint
import sexpdata as sx
from Structs import Expression
from Structs import sx_sub_symbol, sx_filter, dumps

def is_exists(prop):
    return (
        isinstance(prop, list) 
        and len(prop) > 0 
        and prop[0] == sx.Symbol("exists"))

def mk_option_type(ty):
    assert isinstance(ty, sx.Symbol)
    assert str(ty).startswith(":")
    rtype = sx.Symbol(f":{str(ty)[1:]}-option")
    return rtype

def proc_body(expr : Expression):
    if not isinstance(expr, list):
        return expr
    elif len(expr) == 0:
        return expr
    elif expr[0] == sx.Symbol("exists"):
        assert len(expr) == 5 

        assert isinstance(expr[2], list)
        assert len(expr[2]) % 2 == 0
        fn = expr[1]

        runed_tgt_type = expr[3]
        assert str(runed_tgt_type).startswith(":")
        tgt_type = sx.Symbol(str(runed_tgt_type)[1:])
        tgt_type_pred = sx.Symbol(f"{tgt_type}p")

        type_term = [tgt_type_pred, fn]

        body = proc_body(expr[-1])
         
        return [sx.Symbol("and"), type_term, body]
    else:
        assert isinstance(expr[0], sx.Symbol)
        return [expr[0]] + [proc_body(e) for e in expr[1:]]

def proc_prenex_sigs(prop):
    """
    Given a prenex expression, return a list of defsig forms
    for all existential function declarations.
    """
    assert isinstance(prop, list)
    assert len(prop) == 3
    assert prop[0] == sx.Symbol("prenex")

    quantifiers = prop[1]
    sigs = []

    for decl in quantifiers:
        tag = decl[0]
        if tag == sx.Symbol("E"):
            fn = decl[1]
            args = decl[2]
            rtype = decl[3]
            sigs.append([sx.Symbol("defsig"), fn, args, rtype])
        elif tag == sx.Symbol("A"):
            continue
        else:
            raise ValueError(f"Unexpected quantifier tag {tag}")
    return sigs


def proc_prenex_prop(prop):
    assert prop[0] == sx.Symbol("prenex")
    quantifiers = prop[1]
    body = prop[2]

    args = []
    sigs = []

    for decl in quantifiers:
        tag = decl[0]
        if tag == sx.Symbol("A"):
            var, ty = decl[1], decl[2]
            args.extend([var, ty])
        elif tag == sx.Symbol("E"):
            fn, fn_args, rtype = decl[1], decl[2], decl[3]
            sigs.append([sx.Symbol("defsig"), fn, fn_args, rtype])

    for sig in reversed(sigs):
        fn, fn_args, _rtype = sig[1], sig[2], sig[3]
        replacement = [fn] + fn_args[::2]   # extract just symbols, skip types
        body = sx_sub_symbol(body, fn, replacement)

    return [sx.Symbol("property"), args, body]


class ExistHandler:

    def __init__(self, ex_props, prenex_props):
        self.ex_props = ex_props
        self.prenex_props = prenex_props

    def aux(self):
        exist_exprs = sx_filter(self.ex_props, is_exists)
        aux = [x[1:-1] for x in exist_exprs]
        d = dict()
        for a in aux:
            fn = a[0]
            val = a[1:]
            if fn in d:
                assert d[fn] == val
            else:
                d[fn] = val
        return d

    def ex_sigs(self):
        aux = self.aux()
        sigs = []
        seen = dict()  

        for fn, val in aux.items():
            assert isinstance(fn, sx.Symbol)
            assert isinstance(val, list)
            assert len(val) == 2
            args = val[0]
            rtype = val[1]
            assert isinstance(args, list)
            assert len(args) % 2 == 0
            rtype = mk_option_type(rtype)
            sig = [sx.Symbol("defsig"), fn, args, rtype]
            sigs.append(sig)
            seen[fn] = (args, rtype)
        return sigs, seen


    def sigs(self):
        sigs, seen = self.ex_sigs()

        # ---- prenex sigs ----
        for prop in self.prenex_props:
            for sig in proc_prenex_sigs(prop):
                fn, args, rtype = sig[1], sig[2], sig[3]

                if fn in seen:
                    old_args, old_rtype = seen[fn]
                    if old_args != args or old_rtype != rtype:
                        raise ValueError(
                            f"Signature mismatch for {fn}: "
                            f"{(old_args, old_rtype)} vs {(args, rtype)}"
                        )
                    continue

                sigs.append(sig)
                seen[fn] = (args, rtype)

        return sigs

    def defdatas(self):
        acc = []
        tys = set([ty for _, ty in self.aux().values()])
        for ty in tys: 
            opt = mk_option_type(ty)
            opt = sx.Symbol(str(opt)[1:])
            ty = sx.Symbol(str(ty)[1:])
            defdata = [
                sx.Symbol("defdata"), opt, 
                [sx.Symbol("oneof"), sx.Quoted(sx.Symbol("none")), ty]]
            acc.append(defdata)
        return acc

    def deflocals (self):
        acc = []
        tys = set([ty for _, ty in self.aux().values()])
        for ty in tys: 
            ty_p = sx.Symbol(f"{str(ty)[1:]}p")
            opt = mk_option_type(ty)
            opt = sx.Symbol(f"{str(opt)[1:]}p")
            args = [sx.Symbol("x"), sx.Symbol(":all")]
            rtype = sx.Symbol(":bool")
            body = [
                sx.Symbol("or"), 
                [ty_p, sx.Symbol("x")],
                [sx.Symbol("equal"), sx.Symbol("x"), sx.Quoted(sx.Symbol("none"))]]
            deflocal = [
                sx.Symbol("deflocal"), opt, args, rtype, body]
            acc.append(deflocal)
        return acc

    def post_proc(self, og_prop, proc_prop):
        """Substitute witness function name with witness function application.
        Ensure that the inner most existential is processed first.
        """
        ordering = sx_filter(og_prop, is_exists)
        ordering = [x[1] for x in ordering][::-1]
        sigs, _ = self.ex_sigs()
        sigs = sorted(sigs, key=lambda x: ordering.index(x[1]))
        for sig in sigs:
            sym = sig[1]
            args = sig[2][::2]
            replacement = [sym] + args
            proc_prop = sx_sub_symbol(proc_prop, sym, replacement)
        return proc_prop

    def proc_ex_prop(self, prop):
        assert isinstance(prop, list)
        assert len(prop) == 3
        assert prop[0] == sx.Symbol("ex-property")
        prop_args = prop[1]

        prop_body = proc_body(prop[2])

        prop_body = self.post_proc(prop, prop_body)
        return [sx.Symbol("property"), prop_args, prop_body]

    def properties(self):
        p1 = [self.proc_ex_prop(prop) for prop in self.ex_props]
        p2 = [proc_prenex_prop(prop) for prop in self.prenex_props]
        return p1 + p2



