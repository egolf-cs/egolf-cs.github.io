from itertools import chain

import sexpdata as sx
from Candidate import Concept
from EnumerationInterface import ConceptSpace, RuleEnumerator
from local_eval import ContractViolation, local_eval
from Structs import Interpretation, UserSpace, dumps, tree_to_expr
from VerifierAux import Session


class DefaultConceptSpace(ConceptSpace):

    def __init__(
        self,
        rule_enumerators: list[RuleEnumerator],
        subexpr_bound: int,
        base_concepts: list[Concept],
    ):
        super().__init__(rule_enumerators)
        self.subexpr_bound = subexpr_bound
        self.base_concepts = base_concepts
        self.gen = (x for x in base_concepts)

    def concepts(self):
        res = []
        for x in self.base_concepts:
            res.append(x)
        for r in self.rule_enumerators:
            res.extend(r.concepts())
        return res

    def next(self) -> Concept | None:
        while True:
            # concepts = [x for x in self.gen]
            # print(f"Concepts in generator: {concepts}")
            # input("Press Enter to continue...")
            # self.gen = (x for x in concepts)
            concept = next(self.gen, None)
            if concept is None:
                return None
            if concept.size() > self.subexpr_bound:
                # print(f"Skipping concept {concept} of size {concept.size()} larger than subexpr_bound {self.subexpr_bound}.")
                continue
            # print(f"Generated concept: {concept.tree}")
            self.add_concept(concept)
            # print(f"Yielding concept: {concept}")
            return concept

    def add_concept(self, concept: Concept):
        for rule_enum in self.rule_enumerators:
            new_gen = (x for x in rule_enum.add_subconcept(concept))
            self.gen = chain(self.gen, new_gen)

    def add_interpretation(self, interpretation: Interpretation):
        pass
