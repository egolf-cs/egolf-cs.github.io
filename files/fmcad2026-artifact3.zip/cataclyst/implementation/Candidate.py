from pprint import pprint, pformat
from itertools import chain
import sexpdata as sx
from Sketch import Sketch, dumps, DEFINEC, sx_filter, sx_substitute_holes
from Structs import NonTerminal, Tree, tree_size, tree_to_expr, Expression
from Structs import TerminationProperty
from Structs import UserFunction
from Structs import sx_substitute_applications

class Concept:
    
    def __init__(self, nt : NonTerminal, tree : Tree):
        assert isinstance(nt, NonTerminal)
        self.nt = nt
        self.tree = tree

    def size(self) -> int:
        return tree_size(self.tree)
    def __repr__(self):
        return f"Concept({self.nt}, {self.tree})"
    def __str__(self):
        return self.__repr__()

class Emergent:

    def __init__(self, tpl : list[Tree]):
        self.tpl = tpl
    def __repr__(self):
        return str(self.tpl)
    def __str__(self):
        return self.__repr__()

class Candidate:

    def __init__(self, emergent : Emergent, sketches : list[Sketch]):
        self.emergent = emergent
        assert isinstance(sketches, list)
        self.sketches = sketches

    def pstr(self) -> str:
        res = self.definec_exprs()
        sub = self.mk_sub()
        res = sx_substitute_holes(res, sub)
        assert isinstance(res, list)
        res = [sx.dumps(x, indent=2, pretty_print=True) for x in res]
        res = "\n".join(res)
        return res

    def __repr__(self):
        res = self.definec_exprs()
        sub = self.mk_sub()
        res = sx_substitute_holes(res, sub)
        return sx.dumps(res, indent=2, pretty_print=True)

    def __str__(self):
        return self.__repr__()

    def definec_exprs(self) -> list[Expression]:
        res = []
        for sk in self.sketches:
            expr = sk.definec()
            res.append(expr)
        return res

    def sketch_ids(self) -> tuple[int,...]:
        return tuple(id(sketch) for sketch in self.sketches)

    def hole_names(self) -> list[sx.Symbol]:
        res = []
        for sketch in self.sketches:
            res.extend(sketch.hole_names())
        return res

    def hole_sketch(self, hname : sx.Symbol) -> Sketch:
        for sketch in self.sketches:
            if hname in sketch.hole_names():
                return sketch
        raise ValueError(f"Hole {hname} not found in sketches")

    def hole_function(self, hname : sx.Symbol) -> sx.Symbol|None:
        if hname not in self.hole_names():
            return None
        sketch = self.hole_sketch(hname)
        return sketch.hole_function(hname)

    def hole_expression(self, hname) -> Expression:
        """Returns the expression for a hole in the emergent."""
        if hname not in self.hole_names():
            raise ValueError(f"Hole {hname} not found in sketches")
        index = self.hole_names().index(hname)
        return tree_to_expr(self.emergent.tpl[index])

    def no_hole_ic(self, hname) -> tuple[Expression, list[sx.Symbol]]:
        """Returns the input contract for a hole after substituting
        the emergent into the input contract. Also returns the hole names
        appearing in the input contract.
        """
        sketch = self.hole_sketch(hname)
        ic = sketch.input_contract(hname)
        holes_in_ic = sketch.input_contract_deps(hname)
        sub = [
            (k,v) for k, v in zip(self.hole_names(), self.emergent.tpl)]
        sub = [(k, tree_to_expr(v)) for k, v in sub]
        ic = sx_substitute_holes(ic, sub)
        return ic, holes_in_ic

    def input_contract_deps(self, hname) -> list[sx.Symbol]:
        """Returns the hole names appearing in the input contract of a hole."""
        sketch = self.hole_sketch(hname)
        return sketch.input_contract_deps(hname)

    def mk_type_hyp_hole(self, hname : sx.Symbol) -> Expression:
        sketch = self.hole_sketch(hname)
        return sketch.mk_type_hyp_hole(hname)

    def mk_sub(self):
        return [
            (k, tree_to_expr(v)) 
            for k, v in zip(self.hole_names(), self.emergent.tpl)]

    def mk_sub_nil_list(self):
        """Build hole substitutions with int-list nil specialized to nil-list.

        NOTE: this needs to be generalized and possibly inferred from user
        input. It is also a bit brittle and heuristic, since in principle
        a list valued expression could contain a nil of type boolean.

        Returns substitutions like `mk_sub`, but for holes with return type
        `:int-list`, any empty-list or False literals in the replacement 
        expression are rewritten to the symbol `nil-list`.
        """
        def replace_empty_list_with_nil_list(expr : Expression) -> Expression:
            """Recursively replace empty-list literals with `nil-list` symbol."""
            if expr == []:
                return sx.Symbol("nil-list")
            if isinstance(expr, bool) and not expr:
                return sx.Symbol("nil-list")
            if not isinstance(expr, list):
                return expr
            return [replace_empty_list_with_nil_list(x) for x in expr]

        int_list_type = sx.Symbol(":int-list")
        res = []
        for k, v in zip(self.hole_names(), self.emergent.tpl):
            expr = tree_to_expr(v)
            if self.hole_sketch(k).hole_type(k) == int_list_type:
                expr = replace_empty_list_with_nil_list(expr)
            res.append((k, expr))
        return res

    def guard_holes(self) -> list[sx.Symbol]:
        res = []
        for sketch in self.sketches:
            res.extend(sketch.guard_holes())
        return res

    def termination_properties(self) -> list[TerminationProperty]:
        res = []
        for sketch in self.sketches:
            res.extend(sketch.termination_properties)
        return res

    def definecs(self) -> list[str]:
        res = []
        for sketch in self.sketches:
            definec = sketch.definec()
            if isinstance(definec, list):
                definec = dumps(definec)
            res.append(definec)
        return res

    def mk_definec_sk(
            self,
            sketch : Sketch,
            sub : dict[sx.Symbol, sx.Symbol],
            ) -> str:
        primary = sub[sketch.name]
        definec = sketch.definec()
        sub_lst = [(k, v) for k, v in sub.items()]
        definec = sx_substitute_applications(definec, sub_lst)
        assert isinstance(definec, list)
        definec = [definec[0], primary] + definec[2:]
        return dumps(definec)

    def user_functions_sk(self, sketch) -> list[UserFunction]:
        uftop = UserFunction(
            sketch.name,
            sketch.top_args,
            sketch.top_arg_types,
            sketch.top_return_type,
            True,
            sketch._body())
        hole_ufs = []
        for hname, htype in zip(
                sketch.hole_names(), sketch.hole_types()):
            ic, _ = self.no_hole_ic(hname)
            body = self.hole_expression(hname)
            args = sketch.hole_args(hname)
            arg_types = sketch.hole_arg_types(hname)
            uf = UserFunction(
                hname, args, arg_types, htype,
                ic, body)
            hole_ufs.append(uf)
        return [uftop, *hole_ufs]

    def user_functions(self) -> list[UserFunction]:
        res = []
        for sketch in self.sketches:
            res.extend(self.user_functions_sk(sketch))
        return res

    def definec_hole(
            self, 
            hname: sx.Symbol, 
            hlabels : dict[sx.Symbol, sx.Symbol]) -> str:

        sketch = self.hole_sketch(hname)

        args = sketch.hole_args(hname)
        ic = sketch.input_contract(hname)
        ic = sx_substitute_holes(ic, [(k, [v, *args]) for k, v in hlabels.items()])
        expr = self.hole_expression(hname)
        argtypes = sketch.hole_arg_types(hname)
        argzs = [x for x in zip(args, argtypes)]
        argzs = list(chain(*argzs))
        ignorable = [sx.Symbol("declare"), [sx.Symbol("ignorable"), *args]]
        htype = sketch.hole_type(hname)
        definec = [
            DEFINEC, hlabels[hname], argzs, htype,
            ignorable, sx.Symbol(":ic"), ic, 
            expr]
        return dumps(definec)

    def definec_holes_sk(self, sketch : Sketch) -> list[tuple[sx.Symbol, str]]:
        hnames = sketch.hole_names()
        htypes = sketch.hole_types()
        assert len(hnames) == len(htypes)
        assert len(hnames) == len(self.emergent.tpl)
        res = []
        for hname, htype, tree in zip(hnames, htypes, self.emergent.tpl):
            args = sketch.hole_args(hname)
            argtypes = sketch.hole_arg_types(hname)
            argzs = [x for x in zip(args, argtypes)]
            argzs = list(chain(*argzs))
            ignorable = [sx.Symbol("declare"), [sx.Symbol("ignorable"), *args]]
            ic = sketch.input_contract(hname)
            expr = tree_to_expr(tree) 
            definec = [
                DEFINEC, hname, argzs, htype, 
                ignorable, sx.Symbol(":ic"), ic, 
                expr]
            res.append((hname, dumps(definec)))
        return res

    def definec_holes(self) -> list[tuple[sx.Symbol, str]]:
        res = []
        for sketch in self.sketches:
            res.extend(self.definec_holes_sk(sketch))
        return res

