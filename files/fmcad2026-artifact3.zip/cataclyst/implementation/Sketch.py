from typing import Callable
from pprint import pprint

import sexpdata as sx
from Structs import Hole, Expression
from Structs import dumps, sx_filter
from Structs import TerminationProperty

DEFINEC = sx.Symbol("definec")

def get_functions(expr):
    exprs = sx_filter(expr, lambda x: isinstance(x, list) and len(x) > 0)
    fs = set([expr[0] for expr in exprs if isinstance(expr[0], sx.Symbol)])
    return fs

def sx_substitute_holes(
        expr : Expression, 
        substitutions : list[tuple[sx.Symbol, Expression]]) -> Expression:
    """Traverses expr recursively. If expr matches a predicate in
    substitutions, replaces it with the corresponding expression.
    """
    if not isinstance(expr, list):
        return expr
    if len(expr) == 0:
        return expr
    for hname, replacement in substitutions:
        b = expr[0] == hname 
        if b:
            return replacement
    return [sx_substitute_holes(x, substitutions) for x in expr]
     

def hole_paths(expr : Expression, hole_names, path : list | None = None) -> dict[sx.Symbol, list]:
    """Recursively index the execution path leading to each hole.
    """
    if path is None:
        path = []
    results = {}
    
    if isinstance(expr, sx.Symbol):
        if expr in hole_names:
            results[expr] = path
        return results

    if not isinstance(expr, list):
        return results

    if len(expr) == 4 and expr[0] == sx.Symbol("if"):
        condition, then_branch, else_branch = expr[1], expr[2], expr[3]
        results.update(hole_paths(condition, hole_names, path))
        results.update(hole_paths(then_branch,  hole_names, path + [(condition, True)]))
        results.update(hole_paths(else_branch,  hole_names, path + [(condition, False)]))
    else:
        for sub_expr in expr:
            results.update(hole_paths(sub_expr,  hole_names, path))
    return results

def exec_path_to_property(path : list) -> Expression:
    res : Expression = [sx.Symbol("and")]
    for condition, polarity in path:
        if polarity:
            res.append(condition)
        else:
            res.append([sx.Symbol("not"), condition])
    if len(res) == 1:
        return True
    if len(res) == 2: # type:ignore
        return res[1]
    return res

def match_paths(expr, pred, path=None) -> list[tuple[Expression, list]]:
    """
    Recursively find subexpressions in `expr` matching `pred`,
    associating each with its execution path.

    Returns a list of (match, path) pairs.
    """
    if path is None:
        path = []

    results = []
    
    # Always explore, even if a match
    if pred(expr):
        results.append((expr, path))

    if isinstance(expr, list):
        if len(expr) == 4 and expr[0] == sx.Symbol("if"):
            condition, then_branch, else_branch = expr[1], expr[2], expr[3]
            results += match_paths(condition, pred, path)
            results += match_paths(then_branch, pred, path + [(condition, True)])
            results += match_paths(else_branch, pred, path + [(condition, False)])
        else:
            for sub_expr in expr:
                results += match_paths(sub_expr, pred, path)
    
    return results

class Sketch:

    def __init__(
            self,
            name : sx.Symbol,
            args : list[sx.Symbol],
            arg_types : list[sx.Symbol],
            return_type : sx.Symbol,
            body : Expression,
            measure : sx.Symbol,
            measure_arity : int,
            holes : list[Hole]):
        self.name = name
        self.top_args = args
        self.top_arg_types = arg_types
        if len(args) != len(arg_types):
             raise ValueError(
                    f"Number of args ({len(args)}) does not match number of"
                    f" arg_types ({len(arg_types)})")
        self.top_return_type = return_type
        self.body = body
        self.measure = measure
        self.measure_arity = measure_arity
        self.holes = holes

        self.__prec_hole_names = [h.name for h in self.holes]
        self._execution_paths = hole_paths(self._body(), self.__prec_hole_names)
        self._hole_names = [h.name for h in self.holes if h.name in self._execution_paths]
        self._input_contracts = {}
        self.termination_properties = self._termination_properties()

    def hole_names(self) -> list[sx.Symbol]:
        return self._hole_names
    
    def hole_types(self) -> list[sx.Symbol]:
        hs = self.hole_names()
        return [h.return_type for h in self.holes if h.name in hs]

    def hole_type(self, hname : sx.Symbol) -> sx.Symbol:
        hole = next((h for h in self.holes if h.name == hname), None)
        if hole is None:
            raise ValueError(f"Unknown hole: {hname}")
        return hole.return_type

    def hole_args(self, hname : sx.Symbol) -> list[sx.Symbol]:
        hole = next((h for h in self.holes if h.name == hname), None)
        if hole is None:
             raise ValueError(f"Unknown hole: {hname}")
        return hole.args

    def hole_arg_types(self, hname : sx.Symbol) -> list[sx.Symbol]:
        hole = next((h for h in self.holes if h.name == hname), None)
        if hole is None:
             raise ValueError(f"Unknown hole: {hname}")
        return hole.arg_types

    def hole_function(self, hname : sx.Symbol) -> sx.Symbol|None:
        hole = next((h for h in self.holes if h.name == hname), None)
        if hole is None:
            raise ValueError(f"Unknown hole: {hname}")
        return hole.tgt_function

    def holes_function(self, hnames : list[sx.Symbol]) -> sx.Symbol|None:
        """Returns the target function for the holes hnames. If all holes
        have the same target function, returns that function. If they
        have different target functions, raises an error.
        """
        res = None
        for hname in hnames:
            fn = self.hole_function(hname)
            if res is None:
                res = fn
            elif res != fn:
                raise ValueError(
                    f"Hole {hname} has different target function ({fn}) "
                    f"than previous holes ({res}). This is probably a bug in how "
                    "we handle mutual recursion. Please report this bug")
        return res

    def _body_rec(self, body : Expression) -> Expression:
        """Recursively replaces all ???i with (???i *{hole_args()})"""
        if isinstance(body, sx.Symbol):
            if body in self.__prec_hole_names:
                args = self.hole_args(body)
                return [body, *args]
            return body
        elif isinstance(body, list):
            return [self._body_rec(x) for x in body]
        else:
            return body

    def _body(self) -> Expression:
        """Replaces all ???i with (???i *{hole_args()})"""
        return self._body_rec(self.body)

    def definec(self) -> Expression:
        args = []
        for i in range(len(self.top_args)):
            args.append(self.top_args[i])
            args.append(self.top_arg_types[i])
        return [
            DEFINEC, self.name, args, self.top_return_type, 
            sx.Symbol(":skip-admissibilityp"), True,
            self._body()]

    def defun(self) -> Expression:
        declare = [sx.Symbol("declare"), 
            [sx.Symbol("xargs"), sx.Symbol(":mode"), sx.Symbol(":program")]],
        return [
            sx.Symbol("defun"), self.name, 
            self.top_args, #type:ignore
            *declare,
            self._body()]

    def _input_contract(self, hname : sx.Symbol) -> tuple[list[sx.Symbol],Expression]:
        """Returns the input contract for the hole hname.
        Does not include input contract generated by the hole's
        arguments, just those generated from the execution path
        leading to the hole.
        """
        if hname not in self._execution_paths:
            raise ValueError(f"Unknown hole: {hname}")
        path = self._execution_paths[hname]
        res = exec_path_to_property(path)
        holes_in_res = sx_filter(
            res, lambda x: isinstance(x, sx.Symbol) and x in self.hole_names())
        holes_in_res = [x for x in self.hole_names() if x in holes_in_res]
        return holes_in_res, res

    def input_contract(self, hname : sx.Symbol) -> Expression:
        if hname not in self._input_contracts:
            self._input_contracts[hname] = self._input_contract(hname)
        return self._input_contracts[hname][1]

    def input_contract_deps(self, hname : sx.Symbol) -> list[sx.Symbol]:
        if hname not in self._input_contracts:
            self._input_contracts[hname] = self._input_contract(hname)
        return self._input_contracts[hname][0]

    def recursive_calls(self) -> list[tuple[Expression, list]]:
        """Returns a list of recursive calls in the body. Associates each
        with its execution path.
        """
        paths = match_paths(
            self._body(), 
            lambda x: isinstance(x, list) and len(x) > 0 and x[0] == self.name)
        return paths

    def guard_holes(self) -> list[sx.Symbol]:
        ifs = sx_filter(
            self.body,
            lambda x: isinstance(x, list) and len(x) > 0 and x[0] == sx.Symbol("if"))
        res = [x[1] for x in ifs if x[1] in self.hole_names()]
        return res

    def mk_type_hyp_top(self) -> Expression:
        type_hyp : Expression = [sx.Symbol("and")]
        for arg, arg_type in zip(self.top_args, self.top_arg_types):
            t = dumps(arg_type)
            assert t.startswith(":")
            type_hyp.append([sx.Symbol(f"{t[1:]}p"), arg])
        if len(type_hyp) == 1:
            type_hyp = True
        if len(type_hyp) == 2: # type:ignore
            type_hyp = type_hyp[1] # type:ignore
        return type_hyp

    def mk_type_hyp_hole(self, hname : sx.Symbol) -> Expression:
        type_hyp : Expression = [sx.Symbol("and")]
        args = self.hole_args(hname)
        arg_types = self.hole_arg_types(hname)
        for arg, arg_type in zip(args, arg_types):
            t = dumps(arg_type)
            assert t.startswith(":")
            type_hyp.append([sx.Symbol(f"{t[1:]}p"), arg])
        if len(type_hyp) == 1:
            type_hyp = True
        if len(type_hyp) == 2: # type:ignore
            type_hyp = type_hyp[1] # type:ignore
        return type_hyp

    def mk_type_hyp_holes(self, hnames : list[sx.Symbol]) -> Expression:
        """Ensures that all holes have the same type hypothesis and
        returns it.
        """
        hyps = [self.mk_type_hyp_hole(hname) for hname in hnames]
        for i in range(len(hyps)):
            for j in range(i+1, len(hyps)):
                if hyps[i] == hyps[j]:
                    continue
                raise ValueError(
                    f"Type hypotheses for holes {hnames[i]} and {hnames[j]} are not equal: "
                    f"{dumps(hyps[i])} != {dumps(hyps[j])}. This is probably a bug in how "
                    "we handle mutual recursion. Please report this bug")
        if len(hyps) == 0:
            raise ValueError("No holes provided for type hypothesis")
        return hyps[0]

    def mk_additional_term_hyp(self, hnames : list[sx.Symbol]) -> Expression:
        holes = [h for h in self.holes if h.name in hnames]
        hyps = [h.additional_term_hyp for h in holes]
        for i in range(len(hyps)):
            for j in range(i+1, len(hyps)):
                if hyps[i] == hyps[j]:
                    continue
                raise ValueError(
                    f"Additional term hypotheses for holes {hnames[i]} and"
                    f" {hnames[j]} are not equal:"
                    f" {hyps[i]} != {hyps[j]}. This is probably"
                    " a bug in how we handle mutual recursion."
                    " Please report this bug")
        if len(hyps) == 0:
            raise ValueError("No holes provided for additional term hypothesis")
        hyp = hyps[0]
        if hyp is None:
            hyp = True
        return hyp


    def _termination_properties(self) -> list[TerminationProperty]:
        """Returns a list of termination properties for the sketch.
        Each property is an obligation that must hold for termination.
        """
        paths = self.recursive_calls() 
        top_type_hyp : Expression = self.mk_type_hyp_top()
        properties = []
        if len(self.top_args) != self.measure_arity:
            print(
                f"WARNING: {self.name} takes {len(self.top_args)} arguments,"
                f" but measure has arity {self.measure_arity}. This will cause"
                f" an error if {self.name} is recursive."
                "\nTODO : Per function/function block termination properties")
        for expr, path in paths:
            assert isinstance(expr, list)
            path_hyp = exec_path_to_property(path)
            lhs = [self.measure, *expr[1:]]
            rhs = [self.measure, *self.top_args]
            if len(lhs) != self.measure_arity + 1:
                raise ValueError(
                    f"Expected lhs to have length {self.measure_arity + 1},"
                    f" got {lhs} with length {len(lhs)}. self.name = {self.name}, "
                    f" measure = {self.measure}, measure_arity = {self.measure_arity}.")
            if len(rhs) != self.measure_arity + 1:
                raise ValueError(
                    f"Expected rhs to have length {self.measure_arity + 1},"
                    f" got {rhs} with length {len(rhs)}. self.name = {self.name}, "
                    f" measure = {self.measure}, measure_arity = {self.measure_arity}.")
            hnames = (
                sx_filter(
                    path_hyp, lambda x: isinstance(x, sx.Symbol) and x in self.hole_names())
                + sx_filter(
                    lhs, lambda x: isinstance(x, sx.Symbol) and x in self.hole_names()))
            hole_type_hyp = self.mk_type_hyp_holes(hnames)
            hole_term_hyp = self.mk_additional_term_hyp(hnames)
            lt = [sx.Symbol("<"), lhs, rhs]
            cmd = [sx.Symbol("implies"), [sx.Symbol("and"), 
                top_type_hyp, hole_type_hyp, hole_term_hyp, path_hyp], 
                lt]
            cmd = [sx.Symbol("test?"), cmd]
            tgt_function = self.holes_function(hnames)
            property = TerminationProperty(cmd, hnames, tgt_function)
            properties.append(property)
        return properties


