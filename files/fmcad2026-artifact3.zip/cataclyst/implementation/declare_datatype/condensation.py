from declare_datatype.ddt_graph import DDTGraph, Node

class Condensation:
    def __init__(
            self,
            sccs : list[list[Node]],
            edges : dict[int, set[int]],
            node_to_scc: dict[Node, int]):
        self.sccs = sccs
        self.idxs = [i for i, _ in enumerate(sccs)]
        self.edges = edges

        self._node_to_scc = node_to_scc
        self._in_degrees = self._compute_in_degrees()

    def node_to_scc(self, node: Node) -> list[Node]:
        idx = self._node_to_scc[node]
        return self._idx_to_scc(idx)
    def roots(self) -> list[list[Node]]:
        idxs = self._roots()
        return [self._idx_to_scc(i) for i in idxs]
    def leaves(self) -> list[list[Node]]:
        idxs = self._leaves()
        return [self._idx_to_scc(i) for i in idxs]
    def rank_n(self, n : int) -> list[list[Node]]:
        """Return rank n sccs of the condensation graph.
        """
        res = self._rank_n(n)
        return [self._idx_to_scc(i) for i in res]
    def is_normal_form(self) -> bool:
        roots = set(self._roots())
        leaves = set(self._leaves())
        if len(roots) != 1:
            return False
        return leaves - roots == set(self.idxs) - roots
        

    def _idx_to_scc(self, idx : int) -> list[Node]:
        return self.sccs[idx]   
    def _compute_in_degrees(self) -> dict[int, int]:
        in_degrees = {i: 0 for i in self.idxs}
        for _, targets in self.edges.items():
            for tgt in targets:
                in_degrees[tgt] += 1
        return in_degrees
    def _in_degree(self, idx : int) -> int:
        if idx not in self._in_degrees:
            raise ValueError(f"Idx {idx} does not exist in the condensation graph.")
        return self._in_degrees[idx]
    def _roots(self) -> list[int]:
        res = [idx for idx in self.idxs if self._in_degree(idx) == 0]
        return res
    def _leaves(self) -> list[int]:
        """Return the indices of the condensation graph that have no successors.
        """
        res = [idx for idx in self.idxs if len(self.edges[idx]) == 0]
        return res
    def _rank_n(self, n: int) -> list[int]:
        """Return the indices of the condensation graph that have rank n.
        """
        assert n >= 0, "Rank must be non-negative."
        if n == 0:
            return self._leaves()
        rank_pred = self._rank_n(n - 1)
        res = []
        for idx in self.idxs:
            if idx in rank_pred:
                continue
            b = True
            for neighbor in self.edges[idx]:
                if neighbor not in rank_pred:
                    b = False
                    break
            if b:
                res.append(idx)
        return res

def scc(ddtg: DDTGraph) -> list[list[Node]]:
    return condensation(ddtg).sccs

def condensation(ddtg: DDTGraph) -> Condensation:
    index = 0
    index_map: dict[Node, int] = {}
    lowlink_map: dict[Node, int] = {}
    on_stack: set[Node] = set()
    stack: list[Node] = []
    sccs: list[list[Node]] = []
    node_to_scc: dict[Node, int] = {}

    def strongconnect(v: Node):
        nonlocal index
        index_map[v] = index
        lowlink_map[v] = index
        index += 1
        stack.append(v)
        on_stack.add(v)

        for w in ddtg.successors(v):
            if w not in index_map:
                strongconnect(w)
                lowlink_map[v] = min(lowlink_map[v], lowlink_map[w])
            elif w in on_stack:
                lowlink_map[v] = min(lowlink_map[v], index_map[w])

        if lowlink_map[v] == index_map[v]:
            component = []
            while True:
                w = stack.pop()
                on_stack.remove(w)
                component.append(w)
                node_to_scc[w] = len(sccs)
                if w == v:
                    break
            sccs.append(component)

    for node in ddtg.nodes:
        if node not in index_map:
            strongconnect(node)

    edges: dict[int, set[int]] = {i: set() for i in range(len(sccs))}
    for src in ddtg.nodes:
        for dst in ddtg.successors(src):
            src_scc = node_to_scc[src]
            dst_scc = node_to_scc[dst]
            if src_scc != dst_scc:
                edges[src_scc].add(dst_scc)

    return Condensation(sccs=sccs, edges=edges, node_to_scc=node_to_scc)

