from pprint import pprint
import sexpdata as sx
from declare_datatype.ddt_graph import DDTGraph, DDTGraphSequence
from declare_datatype.ddt_graph import Node, Type, Constructor, Nullary, Extern, ConExtern

from declare_datatype.normal_form import is_normal_form, normalize_ddtg, normalize
from declare_datatype.condensation import condensation
# from declare_datatype.ddt_graph_viz import visualize_ddt_graph

def mk_nth(var_name, idx):
    assert isinstance(var_name, sx.Symbol)
    assert isinstance(idx, int)
    res = [sx.Symbol("cdr"), var_name]
    for _ in range(idx):
        res = [sx.Symbol("cdr"), res]
    return [sx.Symbol("car"), res]

class Defdata:
    def __init__(self, name : sx.Symbol, body : list|sx.Quoted):
        self.name = name
        assert isinstance(name, sx.Symbol)
        self.body = body
class Defdatas:
    def __init__(self, ds : list[Defdata]):
        self.ds = ds
    def compile(self):
        if len(self.ds) == 0:
            return []
        if len(self.ds) == 1:
            d = self.ds[0]
            return [sx.Symbol("defdata"), d.name, d.body]
        res = [sx.Symbol("defdata")] + [[d.name, d.body] for d in self.ds]
        return res
    def __repr__(self):
        res = []
        x = self.compile()
        if isinstance(x[1], list):
            for y in x[1:]:
                res.append(f"  {sx.dumps(y)}")
            lines = "\n".join(res)
            return f"({sx.dumps(x[0])}\n{lines})" 
        else:
            return sx.dumps(x)

class Predicate:
    def __init__(self, name, nullary_names, con_names, is_nullary=None):
        if is_nullary is None:
            is_nullary = False
        self.name = name
        self.nullary_names = nullary_names
        self.con_names = con_names
        self.is_nullary = is_nullary
    def compile(self):
        pname = sx.Symbol(f"{self.name}p")
        rtype = sx.Symbol(":bool")
        args = [sx.Symbol("x"), sx.Symbol(":all")]


        if self.is_nullary:
            # Treat as nullary predicate
            q = sx.Quoted(sx.Symbol(self.name))
            body = [sx.Symbol("equal"), q, sx.Symbol("x")]
            return [sx.Symbol("deflocal"), pname, args, rtype, body]


        elif len(self.nullary_names) == 0 and len(self.con_names) == 0:
            # Treat as constructor predicate
            q = sx.Quoted(sx.Symbol(self.name))
            body = [sx.Symbol("and"),
                [sx.Symbol("consp"), sx.Symbol("x")],
                [sx.Symbol("equal"), q, [sx.Symbol("car"), sx.Symbol("x")]]]
            return [sx.Symbol("deflocal"), pname, args, rtype, body]
        else:
            # Treat as type predicate
            body : list = [sx.Symbol("or")]
            for inner_name in self.nullary_names:
                # inner_name = mk_nullary(Nullary(inner_name))
                # body.append([sx.Symbol("equal"), inner_name, sx.Symbol("x")])
                inner_pname = sx.Symbol(f"{inner_name}p")
                body.append([inner_pname, sx.Symbol("x")])
            for inner_name in self.con_names:
                inner_pname = sx.Symbol(f"{inner_name}p")
                body.append([inner_pname, sx.Symbol("x")])
            return [sx.Symbol("deflocal"), pname, args, rtype, body]
class ConstructorFn:
    def __init__(self, con_name, des_names, des_types):
        self.con_name = con_name
        self.des_names = des_names
        self.des_types = des_types
        assert len(des_names) == len(des_types)
    def compile(self):
        args = []
        var_names = [
            sx.Symbol(f"var-{self.con_name}-{des_name}") 
            for des_name in self.des_names]
        for var_name, des_type in zip(var_names, self.des_types):
            args.append(var_name)
            args.append(sx.Symbol(f":{des_type}"))
            # args.append(sx.Symbol(f":all"))
        rtype = sx.Symbol(f":{self.con_name}")
        body = [sx.Symbol("list"), sx.Quoted(sx.Symbol(self.con_name))] + var_names
        return [
            sx.Symbol("definec"), sx.Symbol(self.con_name), args, rtype, body]
class Destructor:
    def __init__(self, con_name, des_name, rtype, idx):
        self.con_name = con_name
        self.des_name = des_name
        self.rtype = rtype
        self.idx = idx
    def compile(self):
        var_name = sx.Symbol(f"var-{self.con_name}")
        args = [var_name, sx.Symbol(f":{self.con_name}")]
        rtype = sx.Symbol(f":{self.rtype}")
        body = mk_nth(var_name, self.idx)
        return [
            sx.Symbol("definec"), sx.Symbol(self.des_name), args, rtype, body]
# class Tester:
#     def __init__(self, name, is_nullary=None):
#         self.is_nullary = is_nullary
#         if is_nullary is None:
#             self.is_nullary = False
#         self.name = name
#     def compile(self):
#         pname = sx.Symbol(f"{self.name}p")
#         tester_name = sx.Symbol(f"is-{self.name}")
#         # if self.is_nullary:
#         #     body = [sx.Symbol("equal"), sx.Quoted(sx.Symbol(self.name)), sx.Symbol("x")]
#         # else: 
#         body = [pname, sx.Symbol("x")]
#         args = [sx.Symbol("x"), sx.Symbol(":all")]
#         rtype = sx.Symbol(":bool")
#         return [
#             # sx.Symbol("defmacro"), tester_name, [sx.Symbol("x")], body]
#             sx.Symbol("definec"), tester_name, args, rtype, body]

class DDT:
    def __init__(
            self,
            defdatas : Defdatas,
            predicates : list[Predicate],
            constructors : list[ConstructorFn],
            destructors : list[Destructor]):
            # testers : list[Tester]):
        self.defdatas = defdatas
        self.predicates = predicates
        self.constructors = constructors
        self.destructors = destructors
        # self.testers = testers
    def compile_defdatas(self):
        """Compiles the defdatas to cataclyst.
        """
        return self.defdatas.compile()
    def compile_predicates(self):
        """Compiles the predicates to cataclyst.
        """
        return [pred.compile() for pred in self.predicates]
    def compile_constructors(self):
        return [cons.compile() for cons in self.constructors]
    def compile_destructors(self):
        return [destr.compile() for destr in self.destructors]
    # def compile_testers(self):
    #     return [tester.compile() for tester in self.testers]
    def compile(self):
        """Compiles all components to cataclyst.
        """
        res = []
        res.append(self.defdatas.compile())
        for cons in self.constructors:
            res.append(cons.compile())
        for destr in self.destructors:
            res.append(destr.compile())
        # for tester in self.testers:
        #     res.append(tester.compile())
        for pred in self.predicates:
            res.append(pred.compile())
        return res
    def __repr__(self):
        # pprint(self.compile())
        return "\n".join([sx.dumps(x) for x in self.compile()])

def mk_nullary(node : Nullary):
    return sx.Quoted(sx.Symbol(node.name))

def mk_defdata(node : Node, ddtg : DDTGraph):
    assert not isinstance(node, Extern)
    assert not isinstance(node, ConExtern)
    # assert not isinstance(node, Nullary)
    name = sx.Symbol(node.name)
    body : None|list = None


    if isinstance(node, Nullary):
        return Defdata(name, mk_nullary(node))


    elif isinstance(node, Type):
        body = [sx.Symbol("oneof")]
        succs = ddtg.successors(node)
        if all(isinstance(succ, Nullary) for succ in succs):
            succs = [mk_nullary(succ) for succ in succs] #type:ignore
        else:
            succs = [sx.Symbol(succ.name) for succ in succs]
    elif isinstance(node, Constructor):
        body = [sx.Symbol("list"), sx.Quoted(name)]
        succs = [sx.Symbol(succ.name) for succ, _ in ddtg.constructor_args[node]]
    else:
        raise ValueError(f"Invalid Node")
    assert isinstance(body, list)
    for succ in succs:
        # succ_name = sx.Symbol(succ.name)
        # if isinstance(succ, Nullary):
        #     succ_name = mk_nullary(succ)
        body.append(succ)
    if body[0] == sx.Symbol("oneof") and len(body) == 2:
        body = body[1]
    assert body is not None
    return Defdata(name, body)

def mk_predicates(node : Node, ddtg : DDTGraph) -> list[Predicate]:
    if isinstance(node, Constructor):
        predicate = Predicate(node.name, [], [])
        return [predicate]
    elif isinstance(node, Type):
        nullary_names = []
        con_names = []
        for succ in ddtg.successors(node):
            assert not isinstance(succ, Extern)
            assert not isinstance(succ, Type)
            # assert not isinstance(succ, Constructor)
            if isinstance(succ, Nullary):
                nullary_names.append(succ.name)
            elif isinstance(succ, ConExtern):
                con_names.append(succ.name)
            elif isinstance(succ, Constructor):
                con_names.append(succ.name)
        predicate = Predicate(node.name, nullary_names, con_names)
        return [predicate]
    elif isinstance(node, Nullary):
        predicate = Predicate(
            node.name, [], [], is_nullary=True)
        return [predicate]
    else:
        return []

def mk_constructors(node : Node, ddtg : DDTGraph) -> list[ConstructorFn]:
    if isinstance(node, Constructor):
        des_names = [] 
        des_types = []
        for dst, label in ddtg.constructor_args[node]:
            des_names.append(label)
            des_types.append(dst.name)
        constructor = ConstructorFn(
            con_name=node.name,
            des_names=des_names,
            des_types=des_types)
        return [constructor]
    return []

def mk_destructors(node : Node, ddtg : DDTGraph) -> list[Destructor]:
    if isinstance(node, Constructor):
        destructors = []
        for idx, (dst, label) in enumerate(ddtg.constructor_args[node]):
            destructor = Destructor(
                con_name=node.name,
                des_name=label,
                rtype=dst.name,
                idx=idx
            )
            destructors.append(destructor)
        return destructors
    return []

# def mk_testers(node : Node, ddtg : DDTGraph) -> list[Tester]:
#     if isinstance(node, Constructor):
#         tester = Tester(node.name)
#         return [tester]
#     return []

def nddtg_to_acl2s(ddtg : DDTGraph) -> tuple[list[DDT],DDT]:
    if not is_normal_form(ddtg):
        raise ValueError("nddtg_to_acl2s requires a normal form DDTGraph.")
    cond = condensation(ddtg)
    roots = cond.roots()
    if len(roots) != 1:
        raise ValueError(
            "nddtg_to_acl2s requires a DDTGraph with a single"
            " root in its condensation graph. If using declare-datatypes,"
            " this error suggests that you are defining multiple,"
            " independent datatypes in the same declaration, which is bad"
            " practice and should be avoided.")
    root = roots[0]
    defdatas = []
    predicates = []
    constructors = []
    destructors = []
    # testers = []

    nullaries = []
    for nodes in cond.leaves():
        assert len(nodes) == 1
        node = nodes[0]
        if not isinstance(node, Nullary):
            continue
        inner_defdatas = [mk_defdata(node, ddtg)]
        inner_preds = mk_predicates(node, ddtg)
        # inner_testers = [Tester(node.name, is_nullary=True)]
        inner_ddt = DDT(
            Defdatas(inner_defdatas),
            inner_preds,
            [],
            [],
            # inner_testers
        )
        nullaries.append(inner_ddt)
    for node in root:
        defdata = mk_defdata(node, ddtg)
        predicates += mk_predicates(node, ddtg)
        constructors += mk_constructors(node, ddtg)
        destructors += mk_destructors(node, ddtg)
        # testers += mk_testers(node, ddtg)
        defdatas.append(defdata)
    defdatas = Defdatas(defdatas)
    primary = DDT(
        defdatas,
        predicates,
        constructors,
        destructors,
        # testers
    )
    return nullaries, primary

def ddtg_to_acl2s(ddtg : DDTGraph) -> list[DDT]:
    norms = normalize_ddtg(ddtg)
    res = []
    for norm in norms:
        nullaries, primary = nddtg_to_acl2s(norm)
        res.extend(nullaries)
        res.append(primary)
    return res

def seq_to_acl2s(seq : DDTGraphSequence) -> list[DDT]:
    norm_seq = normalize(seq)
    res = []
    for norm in norm_seq.gs:
        nullaries, primary = nddtg_to_acl2s(norm)
        res.extend(nullaries)
        res.append(primary)
    return res

if __name__ == "__main__":
    from ddt_graph_examples import (
        mk_compare, mk_nat_pair, mk_nat_option, mk_nat_list, mk_forest_tree,
        mk_superfluous_pair_list
    )
    # example, name = mk_compare()
    # example, name = mk_nat_pair()
    # example, name = mk_nat_option()
    example, name = mk_nat_list()
    # example, name = mk_forest_tree()
    # example, name = mk_superfluous_pair_list()
    # visualize_ddt_graph(example)
    res = ddtg_to_acl2s(example)
    for x in res:
        print(x)

