from pprint import pprint
import sexpdata as sx

from declare_datatype.ddt_graph import Type, Constructor, Nullary, Extern, DDTGraph
from declare_datatype.pprint_acl2s import ddtg_to_acl2s

def parse_declare_datatype(sexpr):
    # just reduce this to parse_declare_datatypes
    assert isinstance(sexpr, list)
    assert len(sexpr) == 3
    assert sx.dumps(sexpr[0]) == "declare-datatype"
    sexpr_aux = [
        sx.Symbol("declare-datatypes"), [ [sexpr[1], 0] ], [ sexpr[2] ]]
    # pprint(sexpr_aux)
    # assert False
    return parse_declare_datatypes(sexpr_aux)

def parse_declare_datatypes(sexpr):
    assert isinstance(sexpr, list)
    assert len(sexpr) == 3
    assert sx.dumps(sexpr[0]) == "declare-datatypes"
    sigs = sexpr[1]
    conss = sexpr[2]
    # pprint(conss)
    # print("conss")
    # assert False
    assert isinstance(sigs, list)
    assert isinstance(conss, list)
    assert len(sigs) == len(conss)
    
    ddt_graph = DDTGraph()
    node_map = dict()

    ts = []
    for name, params in sigs:
        assert isinstance(name, sx.Symbol)
        assert isinstance(params, int)
        if params != 0:
            raise NotImplementedError(
                "Parameterizd datatypes not yet supported")
        ts.append(name)
        assert isinstance(name, sx.Symbol)
        dump_name = sx.dumps(name)
        node_map[name] = Type(dump_name)
    
    for cons in conss:
        for con in cons:
            if not isinstance(con, list):
                raise ValueError(
                    f"Constructor should be a list, got: {con}")
            if len(con) == 1:
                assert isinstance(con[0], sx.Symbol)
                node_map[con[0]] = Nullary(sx.dumps(con[0]))
                continue
            assert len(con) > 1
            name = con[0]
            assert isinstance(name, sx.Symbol)
            dump_name = sx.dumps(name)
            node_map[name] = Constructor(dump_name)

            args = con[1:]
            for label, arg in args:
                assert isinstance(label, sx.Symbol)
                assert isinstance(arg, sx.Symbol)
                if arg not in node_map:
                    dump_arg = sx.dumps(arg)
                    assert isinstance(arg, sx.Symbol)
                    node_map[arg] = Extern(dump_arg)
                label = sx.dumps(label)
                ddt_graph.add_edge(node_map[name], node_map[arg], label)

    assert len(ts) == len(conss)
    for t, cons in zip(ts, conss):
        for con in cons:
            con_name = con[0]
            if con_name not in node_map:
                raise ValueError(
                    f"Constructor {con_name} not found in node map.")
            ddt_graph.add_edge(node_map[t], node_map[con_name])

    return ddt_graph
                
if __name__ == "__main__":
    from ddt_examples import mk_forest_tree
    from ddt_examples import mk_nat_list
    from ddt_graph_viz import visualize_ddt_graph
    example, name = mk_forest_tree()
    example, name = mk_nat_list()
    print("Example:", name)
    sexpr = sx.loads(example)
    pprint(sexpr)
    if sexpr[0] != sx.Symbol("declare-datatype"):
        ddt_graph = parse_declare_datatypes(sexpr)
    else:
        ddt_graph = parse_declare_datatype(sexpr)
    visualize_ddt_graph(ddt_graph, view=True) 
    print("acl2s")
    for x in ddtg_to_acl2s(ddt_graph):
        print(x)






