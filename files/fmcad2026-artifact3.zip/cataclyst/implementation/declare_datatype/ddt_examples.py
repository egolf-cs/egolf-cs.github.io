def mk_forest_tree():
    example = """(declare-datatypes (
      (ntree 0)
      (nforest 0)) (
      ;; Tree datatype
      ( (nepsilon)
        (nnode (nnval nat) (nnchildren nforest)) )

      ;; Forest datatype
      ( (nfempty)
        (nfcons (nfhead ntree) (nftail nforest)) )
    ))
    """
    return example, "forest_tree"

def mk_nat_list():
    example = """(declare-datatype nlist (
        (nnil)
        (ncons (nhead nat) (ntail nlist))))
    """
    return example, "nat_list"

