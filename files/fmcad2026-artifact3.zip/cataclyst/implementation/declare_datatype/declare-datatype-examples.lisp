
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; smt-lib declare-datatype form
(declare-datatype int-list (
    (inil)
    (icons (ihead int) (itail int-list))))

; corresponding acl2s defdata form
(defdata int-list (oneof 'inil
                         (icons (ihead . int)
                                (itail . int-list))))

; acl2s Constructors (automatically generated):
; 'inil
; icons : int * int-list -> int-list

; acl2s Testers (automatically generated):
; iconsp : all -> bool
; int-listp : all -> bool
;;; Note: no tester for inil

; acl2s Destructors (nothing generated):
; (mget :ihead xs), where xs is an int-list
; (mget :itail xs), where xs is an int-list

; Avoiding records
(defdata
    (icons (list int int-list))
    (int-list (oneof 'inil icons)))
(definec icons (var-icons-ihead :int var-icons-itail :int-list) :icons
    (list var-icons-ihead var-icons-itail))
(definec ihead (var-icons :icons) :int
    (first var-icons))
(definec itail (var-icons :icons) :int-list
    (second var-icons))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; smt-lib declare-datatype form
(declare-datatype int-pair 
    ((ipair (ileft Int) (iright Int))))

; corresponding acl2s defdata form
(defdata ipair (record (ileft . int)
                       (iright . int)))
(defdata int-pair ipair)

; acl2s Constructors (automatically generated):
; ipair : int * int -> int-pair

; acl2s Testers (automatically generated):
; int-pairp : all -> bool

; acl2s Destructors (nothing generated):
; (mget :ileft xs), where xs is an int-pair
; (mget :iright xs), where xs is an int-pair

; Avoiding records
(defdata
    (ipair (list int int)))
(defdata int-pair ipair)
(definec ipair (var-ipair-ileft :int var-ipair-iright :int) :ipair
    (list var-ipair-ileft var-ipair-iright))
(definec ileft (var-ipair :ipair) :int
    (first var-ipair))
(definec iright (var-ipair :ipair) :int
    (second var-ipair))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; smt-lib declare-datatype form
(declare-datatype compare (
    (cmp_lt)
    (cmp_eq)
    (cmp_gt)))

; corresponding acl2s defdata form
(defdata compare (enum '(cmp_lt 
                         cmp_eq 
                         cmp_gt)))

; No Testers are generated for this enum type.
; Only trivial constructors are generated: 'cmp_lt, 'cmp_eq, 'cmp_gt
; Destructors not needed for enums and not expected by the interface.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; smt-lib declare-datatype form
(declare-datatype int-option (
    (inone)
    (isome (isome-val int))))

; corresponding acl2s defdata form
(defdata isome (record (isome-val . int)))
(defdata int-option (oneof 'inone
                           isome))

; This is almost isomorphic to int-pair, except that it has a nullary 
; constructor.

; Avoiding records
(defdata isome (list int))
(defdata int-option (oneof 'inone isome))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;


(declare-datatypes (
  (itree 0)
  (iforest 0)) (
  ;; Tree datatype
  ( (inode (inval int) (inchildren iforest)) )

  ;; Forest datatype
  ( (ifempty)
    (ifcons (ifhead itree) (iftail iforest)) )
))

; Maybe the cleanest way to make it go through
(defdata
    (inode (list int iforest))
    (itree inode)
    (ifcons (list itree iforest))
    (iforest (oneof 'ifempty ifcons)))
(definec inode (var-inode-inval :int var-inode-inchildren :iforest) :inode
    (list var-inode-inval var-inode-inchildren))
(definec ifcons (var-ifcons-ifhead :itree var-ifcons-iftail :iforest) :ifcons
    (list var-ifcons-ifhead var-ifcons-iftail))
(definec inval (var-inode :inode) :int
    (first var-inode))
(definec inchildren (var-inode :inode) :iforest
    (second var-inode))
(definec ifhead (var-ifcons :ifcons) :itree
    (first var-ifcons))
(definec iftail (var-ifcons :ifcons) :iforest
    (second var-ifcons))

; Ideal defdata form, doesn't go through because of termination
(defdata 
    (itree (inode (inval . int)
                  (inchildren . forest)))
    (iforest (oneof 'ifempty
                   (ifcons (ifhead . tree)
                           (iftail . forest)))))

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; smt-lib declare-datatype form
(declare-datatype int-list-list (
    (ilnil)
    (ilcons (ilhead int-list) (iltail int-list-list))))

; corresponding acl2s defdata form
(defdata int-list-list (oneof 'ilnil
                               (ilcons (ilhead . int-list)
                                       (iltail . int-list-list))))

; Testers/Destructors/Constructors are isomorphic to int-list

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;



; smt-lib declare-datatype form
(declare-datatype int-pair-list (
    (ipnil)
    (ipcons (iphead int-pair) (iptail int-pair-list))))

; corresponding acl2s defdata form
(defdata int-pair-list (oneof 'ipnil
                              (ipcons (iphead . int-pair)
                                      (iptail . int-pair-list))))

; Testers/Destructors/Constructors are isomorphic to int-list
