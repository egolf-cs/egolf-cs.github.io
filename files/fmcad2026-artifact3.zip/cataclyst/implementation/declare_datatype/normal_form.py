from dataclasses import dataclass

from declare_datatype.ddt_graph import DDTGraph, Extern, ConExtern
from declare_datatype.ddt_graph import DDTGraphSequence
from declare_datatype.ddt_graph import Constructor
from declare_datatype.condensation import condensation

def is_normal_form(ddtg : DDTGraph|DDTGraphSequence) -> bool:
    """ddtg is in normal form if its condensation graph has a single root 
    and all other nodes in the condensation graph are leaves (have no 
    successors).
    """
    if isinstance(ddtg, DDTGraph):
        cond = condensation(ddtg)
        return cond.is_normal_form()
    elif isinstance(ddtg, DDTGraphSequence):
        for ddtg in ddtg.gs:
            if not is_normal_form(ddtg):
                return False
        return True
    else:
        raise TypeError(
            "Input must be a DDTGraph or DDTGraphSequence")


@dataclass
class PeeledGraph:
    peeled : DDTGraph
    norms : list[tuple[list[Extern|ConExtern], DDTGraph]]

def peel(ddtg : DDTGraph) -> PeeledGraph:
    """Returns G, Gs where Gs is a map from extern nodes to normal
    form graphs. Substituting Gs into G (replacing the extern nodes
    with the corresponding graph as a subgraph) will yield the input
    ddtg. WARNING: This isn't quite right since all externs in the
    same scc will point to the same 
    """

    cond = condensation(ddtg)
    # print("ddtg succs")
    # for node in ddtg.nodes:
    #     print(f"\t{node} : {ddtg.successors(node)}")
    # print("Condensation graph:")
    # print(cond.sccs)
    # print(cond.edges)
    rank1_sccs = cond.rank_n(1)
    norms = []
    node_to_extern = dict()

    # print(f"Processing {len(rank1_sccs)} rank 1 SCCs.")
    for scc in rank1_sccs:
        new_ddtg = DDTGraph()
        externs = []
        for node in scc:
            if isinstance(node, Constructor):
                extern = ConExtern(node.name)
            else:
                extern = Extern(node.name)
            externs.append(extern)
            node_to_extern[node] = extern
            if isinstance(node, Constructor):
                for dst, label in ddtg.constructor_args[node]:
                    new_ddtg.add_edge(node, dst, label)
            else:
                for dst in ddtg.successors(node):
                    new_ddtg.add_edge(node, dst)
        assert is_normal_form(new_ddtg)
        norms.append((externs, new_ddtg))
    peeled = DDTGraph()
    for src in ddtg.nodes:
        if src in node_to_extern:
            continue
        if isinstance(src, Constructor):
            for dst, label in ddtg.constructor_args[src]:
                if dst in node_to_extern:
                    dst = node_to_extern[dst]
                peeled.add_edge(src, dst, label)
        else:
            for dst in ddtg.successors(src):
                if dst in node_to_extern:
                    dst = node_to_extern[dst]
                peeled.add_edge(src, dst)
    res = PeeledGraph(peeled, norms)
    return res

def normalize_ddtg(ddtg : DDTGraph) -> list[DDTGraph]:
    cond = condensation(ddtg)
    if len(cond.roots()) != 1:
        raise NotImplemented(
            "Input DDTGraph has more than one root in the condensation graph."
            " This is not yet implemented.")
    acc = []
    while True:
        if is_normal_form(ddtg):
            acc.append(ddtg)
            break
        pg = peel(ddtg)
        assert len(pg.norms) > 0
        for externs, norm in pg.norms:
            acc.append(norm)
        ddtg = pg.peeled
    return acc

def normalize(seq : DDTGraphSequence) -> DDTGraphSequence:
    res = []
    for ddtg in seq.gs:
        norms = normalize_ddtg(ddtg)
        res.extend(norms)
    return DDTGraphSequence(res)

def peel_example():
    example, name = mk_nat_pair()
    # example, name = mk_superfluous_pair_list()
    pg = peel(example)
    print()
    print()
    print("Peeled Graph:")
    print(pg.peeled)
    print()
    print("Normal Forms:")
    for externs, norm in pg.norms:
        print()
        print(f"Externs: {[e.name for e in externs]}")
        print(norm)

def normalize_example():
    # example, name = mk_nat_pair()
    example, name = mk_superfluous_pair_list()
    norms = normalize_ddtg(example)
    for norm in norms:
        assert is_normal_form(norm)
        print()
        print(norm)

if __name__ == "__main__":
    from ddt_graph_examples import mk_nat_pair
    from ddt_graph_examples import mk_superfluous_pair_list
    # peel_example()
    normalize_example()


                 



