from graphviz import Digraph
from ddt_graph import DDTGraph, Type, Constructor, Nullary, Extern, ConExtern
from ddt_graph import GRAPH_DIR
from condensation import condensation

def visualize_ddt_graph_basic(graph: DDTGraph, filename: str = "ddt_graph", view: bool = True) -> None:
    dot = Digraph(comment="DDT Graph")

    # Define node appearance by type
    for node in graph.nodes:
        if isinstance(node, Type):
            dot.node(node.name, shape='rect', style='rounded,filled', fillcolor='lightblue')
        elif isinstance(node, Constructor):
            dot.node(node.name, shape='rect', style='filled', fillcolor='lightgreen')
        elif isinstance(node, Nullary):
            dot.node(node.name, shape='diamond', style='filled', fillcolor='orange')
        elif isinstance(node, Extern):
            dot.node(node.name, shape='triangle', style='filled', fillcolor='gray')
        elif isinstance(node, ConExtern):
            dot.node(node.name, shape='ellipse', style='filled', fillcolor='pink')
        else:
            dot.node(node.name)

    # Draw edges with stacked labels and better bidirectional spacing
    for src in graph.nodes:
        for dst in graph.successors(src):
            labels = graph.get_edge_labels(src, dst)
            label_str = "\n".join(sorted(labels)) if labels else ""

            # Add spacing only to one direction of a bidirectional pair
            if graph.is_edge(dst, src) and src.name < dst.name:
                dot.edge(src.name, dst.name,
                         label=label_str,
                         constraint="false",
                         minlen="5",
                         labeldistance="2")
            else:
                dot.edge(src.name, dst.name, label=label_str)

    dot.render(filename, format="pdf", view=view)

def visualize_ddt_graph(graph: DDTGraph, filename: str = "ddt_graph", view: bool = True) -> None:
    dot = Digraph(comment="DDT Graph")
    dot.attr(rankdir='LR', nodesep='0.5', ranksep='0.5 equally')  # Layout: Left to Right
    
    aux = condensation(graph)
    sccs, cond = aux.sccs, aux.edges

    # Create SCC subgraphs
    scc_graphs = {}
    for i, component in enumerate(sccs):
        sub = Digraph(name=f"cluster_{i}")
        sub.attr(style='dashed', label=f"SCC {i}", rank='same')
        for node in component:
            if isinstance(node, Type):
                sub.node(node.name, shape='rect', style='rounded,filled', fillcolor='lightblue')
            elif isinstance(node, Constructor):
                sub.node(node.name, shape='rect', style='filled', fillcolor='lightgreen')
            elif isinstance(node, Nullary):
                sub.node(node.name, shape='diamond', style='filled', fillcolor='orange')
            elif isinstance(node, Extern):
                sub.node(node.name, shape='triangle', style='filled', fillcolor='gray')
            elif isinstance(node, ConExtern):
                sub.node(node.name, shape='ellipse', style='filled', fillcolor='pink')
            else:
                sub.node(node.name)
        scc_graphs[i] = sub
        dot.subgraph(sub)

    # Topologically sort SCCs using cond
    from collections import deque, defaultdict

    in_degree = defaultdict(int)
    for targets in cond.values():
        for tgt in targets:
            in_degree[tgt] += 1
    zero_in_deg = deque(i for i in range(len(sccs)) if in_degree[i] == 0)

    layer_map: dict[int, int] = {}
    current_layer = 0
    while zero_in_deg:
        next_zero = deque()
        for scc_id in zero_in_deg:
            layer_map[scc_id] = current_layer
            for neighbor in cond[scc_id]:
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    next_zero.append(neighbor)
        current_layer += 1
        zero_in_deg = next_zero

    # Add invisible edges to force SCC layout order
    sorted_sccs = sorted(layer_map.items(), key=lambda x: x[1])
    for (scc1, _), (scc2, _) in zip(sorted_sccs, sorted_sccs[1:]):
        # Connect one node from scc1 to scc2 invisibly to preserve layer order
        src = sccs[scc1][0]
        dst = sccs[scc2][0]
        dot.edge(src.name, dst.name, style='invis', weight='10')

    # Draw all edges in original graph
    for src, targets in graph.adj.items():
        for dst in targets:
            labels = graph.get_edge_labels(src, dst)
            label_str = "\n".join(sorted(labels)) if labels else ""
            if graph.is_edge(dst, src) and src.name < dst.name:
                dot.edge(src.name, dst.name,
                         label=label_str,
                         constraint="false",
                         minlen="5",
                         labeldistance="2")
            else:
                dot.edge(src.name, dst.name, label=label_str)

    dot.render(f"{GRAPH_DIR}/{filename}", format="pdf", view=view)


