from pprint import pprint
import sexpdata as sx

GRAPH_DIR = "graphs"

class Node:
    def __init__(self, name):
        self.name = name
        assert isinstance(self.name, str)
    def __repr__(self):
        class_name = self.__class__.__name__
        return f"{class_name}({self.name})"
    def __hash__(self):
        return hash(self.name)
    def __eq__(self, other):
        return self.name == other.name and isinstance(other, self.__class__)

class Type(Node):
    pass
class Constructor(Node):
    pass
class Nullary(Node):
    pass
class Extern(Node):
    pass
class ConExtern(Node):
    pass

class DDTGraph:
    def __init__(self):
        self.nodes : set[Node] = set()
        self.adj : dict[Node,set[Node]] = dict()
        self._ranks : dict[Node, int] = dict()
        self.constructor_args = dict()
    def add_edge(self, src: Node, dst: Node, label: str | None = None):
        self.nodes.add(src)
        self.nodes.add(dst)
        if src not in self.adj:
            self.adj[src] = set()
        self.adj[src].add(dst)
        if label is not None:
            if not isinstance(src, Constructor):
                raise ValueError(f"Source node {src} must be a Constructor to have labeled edges.")
            if src not in self.constructor_args:
                self.constructor_args[src] = []
            self.constructor_args[src].append((dst, label))
        else:
            assert not isinstance(src, Constructor)
    def is_node(self, node: Node) -> bool:
        return node in self.nodes
    def is_edge(self, src: Node, dst: Node) -> bool:
        return src in self.adj and dst in self.adj[src]
    def get_edge_labels(self, src: Node, dst: Node) -> list[str]:
        if not self.is_edge(src, dst):
            raise ValueError(f"Edge from {src} to {dst} does not exist in the graph.")
        res = []
        if src in self.constructor_args:
            for target, label in self.constructor_args[src]:
                if target == dst:
                    res.append(label)
        return res

    def successors(self, node: Node) -> list[Node]:
        if not self.is_node(node):
            raise ValueError(f"Node {node} does not exist in the graph.")
        if node not in self.adj:
            return []
        return list(self.adj[node])
    def __repr__(self):
        adj = []
        for src in self.adj:
            adj.append(f"{src.name} : {self.adj[src]}")
        adj_str = "\n\t".join(adj)
        args = []
        for ctor, labels in self.constructor_args.items():
            args.append(f"{ctor.name} : {labels}")
        args_str = "\n\t".join(args)
        if args_str != "":
            args_str = f"\nconstructor_args=\n\t{args_str}"
        return (
            f"DDTGraph(\nnodes={self.nodes}, "
            f"\nadj=\n\t{adj_str}"
            f", {args_str}"
            "\n)")

class DDTGraphSequence:
    def __init__(self, gs : list[DDTGraph]):
        self.gs = gs

