from ddt_graph import DDTGraph, Type, Constructor, Nullary, Extern
from normal_form import is_normal_form
from ddt_graph_viz import visualize_ddt_graph
from condensation import condensation


def mk_compare():
    graph = DDTGraph()
    compare = Type("compare")
    cmp_lt = Nullary("cmp-lt")
    cmp_gt = Nullary("cmp-gt")
    cmp_eq = Nullary("cmp-eq")
    graph.add_edge(compare, cmp_lt)
    graph.add_edge(compare, cmp_gt)
    graph.add_edge(compare, cmp_eq)
    return graph, "compare"

def mk_nat_pair():
    graph = DDTGraph()
    nat_pair = Type("nat-pair")
    npair = Constructor("npair")
    nat = Extern("nat")
    graph.add_edge(nat_pair, npair)
    graph.add_edge(npair, nat, "nleft")
    graph.add_edge(npair, nat, "nright")
    return graph, "nat_pair"

def mk_nat_option():
    graph = DDTGraph()
    nat_option = Type("nat-option")
    none = Nullary("none")
    some = Constructor("some")
    nat = Extern("nat")
    graph.add_edge(nat_option, none)
    graph.add_edge(nat_option, some)
    graph.add_edge(some, nat, "nsval")
    return graph, "nat_option"

def mk_nat_list():
    graph = DDTGraph()
    nat_list = Type("nlist")
    nil = Nullary("nnil")
    cons = Constructor("ncons")
    nat = Extern("nat")
    graph.add_edge(nat_list, nil)
    graph.add_edge(nat_list, cons)
    graph.add_edge(cons, nat, "nhead")
    graph.add_edge(cons, nat_list, "ntail")
    return graph, "nat_list"

def mk_forest_tree():
    graph = DDTGraph()
    forest = Type("nforest")
    tree = Type("ntree")
    nnode = Constructor("nnode")
    nfcons = Constructor("nfcons")
    nfempty = Nullary("nfempty")
    nat = Extern("nat")
    graph.add_edge(forest, nfempty)
    graph.add_edge(forest, nfcons)
    graph.add_edge(nfcons, tree, "nfhead")
    graph.add_edge(nfcons, forest, "nftail")
    graph.add_edge(tree, nnode)
    graph.add_edge(nnode, nat, "nnval")
    graph.add_edge(nnode, forest, "nnchildren")
    return graph, "forest_tree"

def mk_superfluous_pair_list():
    graph = DDTGraph()
    npair_list = Type("npair-list")
    npnil = Nullary("npnil")
    npcons = Constructor("npcons")
    nat_pair = Type("nat-pair")
    npair = Constructor("npair")
    nat = Extern("nat")
    graph.add_edge(npair_list, npnil)
    graph.add_edge(npair_list, npcons)
    graph.add_edge(npcons, nat_pair, "nphead")
    graph.add_edge(npcons, npair_list, "nptail")
    graph.add_edge(nat_pair, npair)
    graph.add_edge(npair, nat, "npleft")
    graph.add_edge(npair, nat, "npright")
    return graph, "superfluous_pair_list"

def example(mk):
    graph, name = mk()
    print()
    print("Example:", name)
    print("Is normal form:", is_normal_form(graph))
    cond = condensation(graph)
    print("SCCs:", cond.sccs)
    print("Condensation:", cond.edges)
    print("Condensation roots:", cond.roots())
    print()
    visualize_ddt_graph(graph, filename=name, view=False)

if __name__ == "__main__":
    example(mk_compare)
    example(mk_nat_pair)
    example(mk_nat_option)
    example(mk_nat_list)
    example(mk_forest_tree)
    example(mk_superfluous_pair_list)

