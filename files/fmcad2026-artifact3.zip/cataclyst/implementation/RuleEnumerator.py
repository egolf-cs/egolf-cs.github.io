from typing import Generator
from itertools import product, chain
import sexpdata as sx
from EnumerationInterface import RuleEnumerator
from Structs import Rule, NonTerminal, Branch
from Candidate import Concept

def is_distinct(xs) -> bool:
    for i in range(len(xs)):
        for j in range(i + 1, len(xs)):
            if xs[i] == xs[j]:
                return False
    return True

class DefaultRuleEnumerator(RuleEnumerator):

    def __init__(self, rule: Rule):
        super().__init__(rule)
        if not isinstance(self.rule.tree, Branch):
            raise ValueError("Rule tree must be a Branch")
        self.children : list[NonTerminal] = [] 
        self.fn = self.rule.tree.value
        self.nt = self.rule.nt
        self.pools : list[list[Concept]] = []
        for child in self.rule.tree.children:
            if not isinstance(child, NonTerminal):
                raise ValueError(f"Rule must be normal form, got: {rule}")
            self.children.append(child)
            self.pools.append([])

    def concepts(self) -> list[Concept]:
        res = []
        for pool in self.pools:
            res.extend(pool)
        return res

    def add_subconcept(self, subconcept: Concept) -> Generator[Concept, None, None]:
        nt = subconcept.nt
        new_gen : Generator[Concept, None, None] = (x for x in []) 
        for idx, child in enumerate(self.children):
            if child == nt:
                self.pools[idx].append(subconcept)
                gens = []
                for j, _ in enumerate(self.children):
                    if j != idx:
                        gen = (x for x in self.pools[j])
                    else:
                        gen = [subconcept]
                    gens.append(gen)
                prod = product(*gens)
                if sx.Symbol(":distinct") in self.rule.hints:
                    prod = (x for x in prod if is_distinct(x))
                prod = (Concept(self.nt, Branch(self.fn, [y.tree for y in x])) for x in prod)
                new_gen = (x for x in chain(new_gen, prod))
        return new_gen
