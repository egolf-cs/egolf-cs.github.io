import time
from datetime import datetime
from call_function_with_timeout import SetTimeout
from pprint import pprint
import sexpdata as sx
from Candidate import Candidate
from CandidateSpace import CandidateSpace
from VerifierAux import (
    Session,
    ACL2_ERROR,
    TIME_LIMIT_ERROR,
    NoOpCex,
)
from Generalizer import Generalizer
from Structs import dumps, Expression, expr_size
from Instance import Grammar
from Sketch import get_functions
from Verification.SmtPropertyVerifier import SmtPropertyVerifier

PROP_ERR_MSG = """


VALIDATION ERROR:

The user supplied a ground truth solution (to be used for
debugging purposes only). We compared this solution against the properties
and found a counterexample to one of the properties. This may indicate that
the user supplied incorrect properties or an incorrect ground truth. More
info below.
"""

def handle_match(
        tail_key : list[Expression],
        tail_value : list[Expression]) -> None|dict[sx.Symbol, Expression]:
    if len(tail_key) != len(tail_value):
        return None
    arg_key = tail_key[0]
    arg_value = tail_value[0]
    assert isinstance(arg_key, sx.Symbol)
    assert isinstance(arg_value, sx.Symbol)
    if arg_key != arg_value:
        return None
    match_terms_key = tail_key[1:]
    match_terms_value = tail_value[1:]
    if len(match_terms_key) != len(match_terms_value):
        return None
    expr_map = {} 
    for x,y in zip(match_terms_key, match_terms_value):
        assert isinstance(x, list)
        assert isinstance(y, list)
        assert len(x) == 2
        assert len(y) == 2
        pat_key, expr_key = x[0], x[1]
        pat_value, expr_value = y[0], y[1]
        if pat_key != pat_value:
            return None
        inner_expr_map = mk_expr_map(expr_key, expr_value)
        if inner_expr_map is None:
            return None
        expr_map.update(inner_expr_map)
    return expr_map

def handle_let(
        tail_key : list[Expression],
        tail_value : list[Expression]) -> None|dict[sx.Symbol, Expression]:
    assert len(tail_key) == 2
    assert len(tail_value) == 2
    assoc_key, body_key = tail_key[0], tail_key[1]
    assoc_value, body_value = tail_value[0], tail_value[1]
    assert isinstance(assoc_key, list)
    assert isinstance(assoc_value, list)
    # print("assoc_key", assoc_key)
    # print("assoc_value", assoc_value)
    expr_map = {}
    for x,y in zip(assoc_key, assoc_value):
        assert isinstance(x, list)
        assert len(x) == 2
        assert isinstance(y, list)
        assert len(y) == 2
        sym_key, expr_key = x[0], x[1]
        sym_value, expr_value = y[0], y[1]
        assert isinstance(sym_key, sx.Symbol)
        assert isinstance(sym_value, sx.Symbol)
        if sym_key != sym_value:
            return None
        inner_expr_map = mk_expr_map(expr_key, expr_value)
        if inner_expr_map is None:
            return None
        expr_map.update(inner_expr_map)
    # print("body_key", body_key)
    # print("body_value", body_value)
    body_expr_map = mk_expr_map(body_key, body_value)
    if body_expr_map is None:
        return None
    expr_map.update(body_expr_map)
    return expr_map

def mk_expr_map(
        key : Expression, 
        value : Expression) -> None|dict[sx.Symbol, Expression]:
    """Return a map M from symbols to expressions such that substituting
    M into key yields value. If no such map exists, return None.
    """
    # print("key:")
    # pprint(key)
    # print("value:")
    # pprint(value)
    if isinstance(key, sx.Symbol):
        if key == value:
            return {}
        return {key : value}
    elif isinstance(key, list):
        if len(key) == 0:
            if not isinstance(value, list):
                return None
            if len(value) != 0:
                return None
            return {}
        if not isinstance(value, list):
            return None
        if len(value) != len(key): 
            return None
        head_key, tail_key = key[0], key[1:]
        head_value, tail_value = value[0], value[1:]
        if head_key != head_value:
            return None
        if head_key == sx.Symbol("let"):
            return handle_let(tail_key, tail_value)
        if head_key == sx.Symbol("match"):
            return handle_match(tail_key, tail_value)
        if not isinstance(head_key, sx.Symbol):
            raise ValueError(
                "Expected list to be function application, got: "+dumps(key))
        if not isinstance(head_value, sx.Symbol):
            raise ValueError(
                "Expected list to be function application, got: "+dumps(value))
        expr_maps = [mk_expr_map(k, v) for k, v in zip(tail_key, tail_value)]
        expr_map = {}
        for m in expr_maps:
            if m is None:
                return None
            expr_map.update(m)
        return expr_map

class Tool:

    def __init__(
            self,
            candidate_space : CandidateSpace,
            verifier,
            generalizer : Generalizer,
            primitives : list[sx.Symbol] | None,
            instance):
        self.candidate_space = candidate_space
        self.verifier = verifier
        self.generalizer = generalizer
        self.primitives = primitives
        self.instance = instance

        self.solution : Candidate | None = None
        self.solve_time : float | None = None
        # Zero when `(set-validate nil)` skips `validate_sol` in run.py.
        self.tgt_val_time : float = 0.0
        self.is_done : bool|None = None
        self.is_timeout : bool|None = None

    def concepts(self):
        return self.candidate_space.concepts()

    def write_acl2s(self, fname: str,toolname,batchtime,dt) -> None:
        assert fname.endswith(".acl2s")
        fname2 = fname[:-6] + ".lisp"
        content = (
            f"; the following should be identical to that in {fname2}\n"
            f"; (toolname {toolname})\n"
            f"; (batchtime {batchtime})\n"
            f"; (datetime {dt})\n\n\n")
        if self.solution is None:
            content += "nil"
        else:
            preamble = "\n".join(self.instance.preamble())
            solution = self.solution.pstr()
            properties = [
                x.mk_thm(f"thm{i}")
                for i, x in enumerate(self.instance.properties())]
            properties = [dumps(x) for x in properties]
            properties = "\n".join(properties)
            content += "\n" + preamble + "\n\n" + solution + "\n\n" + properties
        with open(fname, "w") as f:
            f.write(content)

    def write_data(
            self, fname: str, total_time, parse_time, init_tool_time,
            toolname, batchtime) -> None:

        assert fname.endswith(".lisp")
        fname2 = fname[:-5] + ".acl2s"

        assert self.solve_time is not None
        solve_time = total_time - self.tgt_val_time

        # preamble = "\n".join(self.verifier.preamble)
        # preamble = "(\n" + preamble + "\n)"
        # solution = str(self.solution)
        # properties = [x.cmd_str for x in self.verifier.properties]
        # properties = "\n\n".join(properties)
        # properties = "(\n" + properties + "\n)"

        dt = datetime.now()
        dt = dt.strftime("%Y-%m-%d_%H:%M:%S")
        
        content = (
            f"; Synthesized functions:\n"
            f"{self.solution}"
            f"\n; ACL2S file located at"
            f"\n(acl2s-file-path {fname2})"
            "\n\n"
            f"(toolname {toolname})\n"
            f"(batchtime {batchtime})\n"
            f"(datetime {dt})"
            "\n\n"
            "; Note: we report total-solve-time in the paper.\n"
            "; We do not include tgt-validation-time because\n"
            "; it is for debugging purposes only.\n"
            f"\n(timeout? {self.is_timeout})"
            f"\n(total-time {total_time:.2f})"
            f"\n  (tgt-validation-time {self.tgt_val_time:.2f})"
            f"\n  (total-solve-time {solve_time:.2f})"
            f"\n    (parse-time {parse_time:.2f})"
            f"\n    (init-tool-time {init_tool_time:.2f})"
            f"\n    (solver-time {self.solve_time:.2f})")
        with open(fname, "w") as f:
            f.write(content)

        self.write_acl2s(fname2,toolname,batchtime,dt)
       
    def solve(self,timeout=None) -> Candidate | None:
        self.start_time = time.time()
        if timeout is not None:
            _solve = SetTimeout(self._solve, timeout)
            self.is_done, self.is_timeout, erro_message, sol = _solve()
            if not self.is_done and not self.is_timeout:
                raise ValueError(
                    "\n\nSolver threw an error:\n\n"+erro_message)
        else:
            self.is_done = True
            self.is_timeout = False
            sol = self._solve()
        end_time = time.time()
        self.solve_time = end_time - self.start_time
        self.solution = sol
        return self.solution

    def validate_sol_properties(
            self, tgts: dict[sx.Symbol, None|Expression]) -> None:
        # checkpoint = "(defun __validation_checkpoint () nil)"
        # self.verifier._send(checkpoint)
        # out = self.verifier._send(dumps(tgt), throw=False)
        session = Session()
        for cmd in self.instance.preamble():
            out = session.send(cmd)
            if (
                    (ACL2_ERROR in out and TIME_LIMIT_ERROR not in out)
                    or "ERROR in translate1-cw" in out):
                raise ValueError(
                    f"VALIDATION ERROR in preamble command:\n"
                    f"{cmd}\n\nOutput:\n{out}\n\n")

        print("WARNING: Using dictionary order to admit functions.")
        print("Probably safe in Python 3.")
        tgt = " ".join([dumps(x) for x in tgts.values() if x is not None])
        out = session.send(tgt)
        # print(tgt)
        # print("^^^ admitting tgt")
        if (
                (ACL2_ERROR in out and TIME_LIMIT_ERROR not in out)
                or "ERROR in translate1-cw" in out):
            raise ValueError(
                f"Ground truth:\n{tgt}\n\nOutput:\n{out}"
                "\n\n"
                "VALIDATION ERROR:\n\n"
                "The user supplied a ground truth solution (to be used for "
                "debugging purposes only). We found an error when trying to "
                "admit this function. More info above.")
        for property in self.instance.properties():
            cmd = property.cmd_str
            out = session.send(cmd)
            if (
                    (ACL2_ERROR in out and TIME_LIMIT_ERROR not in out)
                    or "ERROR in translate1-cw" in out):
                raise ValueError(
                    f"Ground truth:\n{tgt}\n\nOutput:\n{out}"
                    f"cmd: {cmd}"
                    "\n\n"
                    "VALIDATION ERROR:\n\n"
                    "The user supplied a ground truth solution (to be used for "
                    "debugging purposes only). We found an error when trying to "
                    "admit this function. More info above.")
            if "Test? found a counterexample" in out:
                raise ValueError(PROP_ERR_MSG+"\n\nProperty:\n"+cmd+"\n\nOutput:\n"+out)
        # self.verifier._send(":ubt __validation_checkpoint")
        # assert False

    def validate_sol_smt_properties(
            self, tgts: dict[sx.Symbol, None | Expression]) -> None:
        """Validate ground truth against SMT property directives."""
        smt_paths = self.instance.smt_properties()
        if len(smt_paths) == 0:
            return
        fn_bodies : dict[sx.Symbol, Expression] = {}
        for fn_name, tgt in tgts.items():
            if tgt is None:
                continue
            if not isinstance(tgt, list):
                raise ValueError(f"Expected definec for {fn_name}, got {tgt}")
            if len(tgt) == 0:
                raise ValueError(f"Expected definec for {fn_name}, got {tgt}")
            if tgt[0] != sx.Symbol("definec"):
                raise ValueError(f"Expected definec for {fn_name}, got {tgt}")
            body = tgt[-1]
            fn_bodies[fn_name] = body
        validation_candidate = type(
            "ValidationCandidate",
            (),
            {"sketch_ids" : lambda self: tuple()},
        )()
        for smt_path in smt_paths:
            verifier = SmtPropertyVerifier(smt_path, self.instance.user_space)
            out = verifier.verify(fn_bodies, validation_candidate)
            if out is None:
                continue
            raise ValueError(
                "VALIDATION ERROR:\n\n"
                "The user supplied a ground truth solution (to be used for "
                "debugging purposes only). We compared this solution against "
                "an SMT property and found a counterexample.\n"
                f"SMT property file: {smt_path}. Note: you will need to replace"
                "the defstubs with the deftgt bodies provided in the ground truth"
                "during debugging.\n"
            )
        print("Ground truth validated against SMT properties.")

    def validate_sol_grammar(
            self, tgt : Expression, sketch_id : int, grammar : Grammar,
            subexpr_bound : int = 0):
        if not isinstance(tgt, list):
            raise ValueError("Expected definec as tgt, got: "+dumps(tgt))
        if len(tgt) == 0:
            raise ValueError("Expected definec as tgt, got: "+dumps(tgt))
        if tgt[0] != sx.Symbol("definec"):
            raise ValueError("Expected definec as tgt, got: "+dumps(tgt))
        # inner_space = self.candidate_space.id_map[sketch_id]
        # sketch_body = inner_space.sketch.body
        sketch = self.candidate_space.sketch_by_id(sketch_id)
        expr_map = mk_expr_map(sketch.body, tgt[-1])
        if expr_map is None:
            # print("tgt", tgt, type(tgt))
            # print("sketch_body", sketch_body, type(sketch_body))
            raise ValueError(
                "User supplied ground truth does not match the designated"
                " sketch body."
                f"Ground truth: {dumps(tgt)}\n"
                f"Sketch body: {dumps(sketch.body)}\n")
        for k in expr_map:
            if k not in sketch.hole_names():
                print("expr map:")
                pprint(expr_map)
                raise ValueError(
                    "Expected expr_map to pick out hole names, got\n"
                    f"{k} not in {sketch.hole_names()}\n"
                    f"Expr map: see above.\n"
                    f"Ground truth: {dumps(tgt)}\n"
                    f"Sketch body: {dumps(sketch.body)}\n")
        for hname, expr in expr_map.items():
            if subexpr_bound == 0:
                break
            if expr_size(expr) > subexpr_bound:
                raise ValueError(
                    "User supplied ground truth contains a subexpression"
                    " whose size exceeds the supplied subexpression bound."
                    " The default subexpression bound can be set using"
                    " (set-subexpr-bound n) where n is the desired bound."
                    " Not all CandidateSpaces take subexpression bound as a"
                    " parameter. If the selected CandidateSpace does not,"
                    " then this error is spurious and something is wrong.\n"
                    f"Expression: {expr}\n"
                    f"Hole: {hname}\n"
                    f"Expression size: {expr_size(expr)}\n"
                    f"Subexpression bound: {subexpr_bound}")
        # nts = inner_space.emergent_space.nts 
        nts = self.candidate_space.nts_by_sketch_id(sketch_id)
        assoc = [
            (nt_seq, expr_map[hname]) for nt_seq, hname
            in zip(nts, sketch.hole_names())]
        for nt_seq, expr in assoc:
            b = any(grammar.generates(nt, expr) for nt in nt_seq)
            if b:
                continue
            raise ValueError(
                f"User supplied ground truth does not match the grammar.\n"
                f"Ground truth: {dumps(tgt)}\n"
                f"Sketch ID: {sketch_id}\n"
                f"Sketch body: {dumps(sketch.body)}\n"
                f"Grammar: {grammar}\n"
                f"Failed to generate {expr} from {nt_seq}.\n"
                "This may indicate that the grammar is incorrect or that the "
                "user supplied an incorrect ground truth solution."
            )

    def validate_sol_primitives(self, tgt: Expression, fn_names):
        if self.primitives is None:
            return
        assert isinstance(tgt, list)
        assert len(tgt) > 0
        # pprint(tgt[-1])
        tgt_primitives = get_functions(tgt[-1])
        tgt_primitives = [
            x for x in tgt_primitives if x not in [
                sx.Symbol("if"), 
                sx.Symbol("match")] + fn_names]
        for prim in tgt_primitives:
            if prim not in self.primitives:
                raise ValueError(
                    "User supplied ground truth contains a primitive that is"
                    " not declared in the instance.\n"
                    f"Primitive: {prim}\n"
                    f"Ground truth: {dumps(tgt)}\n"
                    f"Declared primitives: {self.primitives}")

    def validate_sol(
            self, 
            tgts : dict[sx.Symbol, Expression|None], sketch_ids : dict[sx.Symbol, int|None],
            grammar : Grammar,
            subexpr_bound : int = 0):

        start_time = time.time()

        assert isinstance(tgts, dict)
        assert isinstance(sketch_ids, dict)
        assert set(sketch_ids.keys()) == set(tgts.keys())
        tgt_fn_names = list(tgts.keys())

        for k in tgts:
            tgt = tgts[k]
            sketch_id = sketch_ids[k]
            if tgt is None:
                continue
            if sketch_id is None:
                raise ValueError(
                    f"Sketch ID for target {k} is None, but target is not None."
                    f" Target: {dumps(tgt)}")
            self.validate_sol_grammar(tgt, sketch_id, grammar, subexpr_bound)
            self.validate_sol_primitives(tgt, tgt_fn_names)

        self.validate_sol_properties(tgts)
        self.validate_sol_smt_properties(tgts)
        self.tgt_val_time = time.time() - start_time

    def _solve(self) -> Candidate | None:
        n = 0
        if hasattr(self.candidate_space.concept_space, "subexpr_bound"):
            print("Subexpr bound:", self.candidate_space.concept_space.subexpr_bound) #type: ignore
        while True:
            n += 1
            # if n > 1000000:
            #     print("Stopping search after 1,000,000 iterations.")
            #     return None
            # Attempt to get the next candidate from the candidate space
            print(
                "\n\n\n"
                f"Elapsed time: {time.time() - self.start_time:.2f} seconds.\n"
                "Searching for next candidate...")
            candidate = self.candidate_space.next()
            if candidate is None:
                return None
            
            # Verify the candidate

            show_candidate = [
                (x,y) for x,y in 
                zip(candidate.hole_names(), candidate.emergent.tpl)]
            show_candidate = "\n".join(
                [f"{name} : {tree}" for name, tree in show_candidate])
            bodies = [dumps(sketch.body) for sketch in candidate.sketches]
            # show_candidate += "\n" + dumps(candidate.sketch.body)
            bodies = "\n".join(bodies)
            show_candidate += "\n" + bodies

            # show_candidate = candidate.emergent
            # show_candidate = candidate
            print(f"Verifying candidate #{n}: \n{show_candidate}")
            cex = self.verifier.verify(candidate)
            if cex is None:
                print(
                    "\n\n\n"
                    f"Elapsed time: {time.time() - self.start_time:.2f} seconds.\n")
                return candidate
            if isinstance(cex, NoOpCex):
                print(f"NoOpCex found for candidate #{n}. Excluding without generalization.")
                continue
            print(f"Counterexample found: {cex}")

            # Learn from the counterexample, manipulate the candidate space
            # print("ADDING INTERPRETATION AND CONSTRAINTS")
            for interp in cex.interpretations():
                self.candidate_space.add_interpretation(interp)
            # self.candidate_space.add_interpretation(cex.interpretation)

            pcs = self.generalizer.generalize(candidate, cex)
            print("LEN GENERALIZED PCS", len(pcs))
            for pc in pcs:
                self.candidate_space.add_constraint(pc)
