from pprint import pprint
from itertools import product, chain

from Structs import NonTerminal
from Candidate import Emergent, Concept
from EnumerationInterface import EmergentSpace
from Generalizer import PruningConstraint, satisfies_constraints

from ConstrainedGenerator import ConstrainedProduct, ConstrainedChain


def base_add_concept(self, concept: Concept):
    for idx, nts in enumerate(self.nts):
        if concept.nt not in nts:
            continue
        self.pools[idx].append(concept.tree)
        gens = []
        for j, _ in enumerate(self.nts):
            if j != idx:
                gen = (x for x in self.pools[j])
            else:
                gen = [concept.tree]
            gens.append(gen)
        prod = product(*gens)
        self.gen = chain(self.gen, prod)

class DefaultEmergentSpace(EmergentSpace):

    def __init__(self, nts : list[list[NonTerminal]]):
        super().__init__(nts)
        self.gen = (x for x in [])
        self.pools = [[] for _ in nts]

    def next(self) -> Emergent | None:
        tpl = next(self.gen, None)
        if tpl is None:
            return None
        return Emergent(list(tpl))

    def add_concept(self, concept: Concept):
        return base_add_concept(self, concept)

    def add_constraint(self, pc: PruningConstraint):
        pass

class ConstrainedEmergentSpace(EmergentSpace):

    def __init__(self, nts : list[list[NonTerminal]]):
        super().__init__(nts)
        self.gen = (x for x in [])
        self.pools = [[] for _ in nts] 

        self.constraints = []

    def next(self) -> Emergent | None:
        while True:
            tpl = next(self.gen, None)
            if tpl is None:
                return None
            violation = satisfies_constraints(tpl, self.constraints)
            if violation is None:
                return Emergent(list(tpl))
            else:
                pass

    def add_concept(self, concept: Concept):
        return base_add_concept(self, concept)

    def add_constraint(self, pc: PruningConstraint):
        self.constraints.append(pc)

class ReducedEmergentSpace(EmergentSpace):

    def __init__(self, nts: list[list[NonTerminal]]):
        super().__init__(nts)
        self.pools = [[] for _ in nts] 
        self.chain = ConstrainedChain()
        self.constraints = []

    def next(self) -> Emergent | None:
        tpl = self.chain.next()
        if tpl is None:
            return None
        violation = satisfies_constraints(tpl, self.constraints)
        if violation is not None:
            raise ValueError(
                "Generated tuple does not satisfy constraints: "
                f"{tpl} with constraints {self.constraints}")
        return Emergent(list(tpl))

    def add_concept(self, concept : Concept):
        added = False
        for idx, nts in enumerate(self.nts):
            if concept.nt not in nts:
                continue
            self.pools[idx].append(concept.tree)
            gens = []
            for j, _ in enumerate(self.nts):
                if j != idx:
                    gen = [x for x in self.pools[j]]
                else:
                    added = True
                    gen = [concept.tree]
                gens.append(gen)
            prod = ConstrainedProduct(gens)
            self.chain.add_product(prod)

    def add_constraint(self, pc: PruningConstraint):
        self.chain.add_constraint(pc)
        self.constraints.append(pc)
