
FNAMES0 = [
    "vampire-assoc-add.lisp",
    "vampire-division.lisp",
    "vampire-double.lisp",
    "vampire-last-element-smt.lisp",
    "vampire-len-concat.lisp",
    "vampire-list-max.lisp",
    "vampire-prefix-given-suffix.lisp",
    "vampire-square-root.lisp",
    "vampire-subtraction.lisp",
    "vampire-tree-max.lisp",
]

FNAMES0 = [
    # "prefixmin-smt.lisp",
    # "index-of-contains-smt.lisp",
    # "monotonic-smt.lisp",
    # "prefixb-smt.lisp",
    # "suffixb-smt.lisp",
    # "threshold-smt.lisp",
    # "tree-k-path-smt.lisp",
    # "tree-sum-path-smt.lisp",
    "prefixmin-full.lisp",
    "index-of-contains-full.lisp",
    "monotonic-full.lisp",
    "prefixb-full.lisp",
    "suffixb-full.lisp",
]

# critical subset for debugging
FNAMES0 = [
    "contata-binary-tree-eq.lisp",
    "contata-ext-list-cmp.lisp",
    "contata-list-cmp.lisp",
    # "contata-ternary-tree-eq.lisp",
    "contata-trie-eq.lisp",
    "index-of-contains.lisp",
    "monotonic.lisp",
    "prefixb.lisp",
    "suffixb.lisp",
    "prefixmin.lisp",
]

# all
FNAMES = [
    "contata-list-insertion.lisp",
    "contata-list-insertion2.lisp",
    "contata-list-removal.lisp",
    "contata-list-sort.lisp",
    # Contata fails
    "contata-list-insertion3.lisp",
    "contata-list-removal2.lisp",
    "contata-binary-tree-eq.lisp",
    "contata-split-on.lisp",
    "contata-bst-insertion.lisp",
    "contata-trie-eq.lisp",

    # # Cataclyst fails (as of Jul 2025) commented out if no timeout
    "contata-ternary-tree-eq.lisp",
    # # Mutual recursion/dependence
    "contata-tree-forest-size.lisp",
    "contata-tree-forest-leaves.lisp",
    "contata-evens-odds.lisp",
    "contata-even-odd.lisp",
    "contata-even-odd2.lisp",
    "contata-parenthesis.lisp",
    "contata-binary-tree-depth.lisp",
    # Contata fails and dependence
    "contata-ternary-tree-depth.lisp",

    # Contata returns non-recursive
    "contata-list-eq.lisp",
    "contata-list-cmp.lisp",
    "contata-sized-list.lisp",
    "contata-mirror-tree-test.lisp",
    "contata-mirror-tree-test2.lisp",
    "contata-mirror-ternary-test.lisp",
    "contata-mirror-ternary-test2.lisp",
    "contata-nested-list-eq.lisp",
    "contata-list-rev-twice.lisp",
    "contata-pairs.lisp",
    "contata-zip-same-len.lisp",
    # Contata returns non-recursive: added additional properties
    "contata-ext-nested-list-eq.lisp",
    "contata-ext-list-eq.lisp",
    "contata-ext-list-cmp.lisp",
    "contata-ext-mirror-tree-test.lisp",
    "contata-ext-mirror-tree-test2.lisp",
    "contata-ext-mirror-ternary-test.lisp",
    "contata-ext-mirror-ternary-test2.lisp",

    # # Existential
    "tree-k-path-smt.lisp",
    "threshold-smt.lisp",
    "tree-sum-path-smt.lisp",

    "monotonic-smt.lisp",
    "index-of-contains-smt.lisp",
    "prefixb-smt.lisp",
    "suffixb-smt.lisp",
    # AEA
    "prefixmin-smt.lisp",

    # skolemized
    "prefixmin-full.lisp",
    "index-of-contains-full.lisp",
    "monotonic-full.lisp",
    "prefixb-full.lisp",
    "suffixb-full.lisp",

    # Vampire
    "vampire-assoc-add.lisp",
    "vampire-division.lisp",
    "vampire-double.lisp",
    "vampire-last-element-smt.lisp",
    "vampire-len-concat.lisp",
    "vampire-list-max.lisp",
    "vampire-prefix-given-suffix.lisp",
    "vampire-square-root.lisp",
    "vampire-subtraction.lisp",
    "vampire-tree-max.lisp",
]


FNAMES = [f"unreal-{fname}" for fname in FNAMES]
print(f"Total number of benchmarks: {len(FNAMES)}")
# assert len(FNAMES) == len(set(FNAMES)), "Duplicate file names"

