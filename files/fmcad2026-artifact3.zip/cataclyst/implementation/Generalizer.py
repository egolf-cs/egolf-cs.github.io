import sexpdata as sx
from VerifierAux import Cex, ContractCex, Session, TerminationCex, PropertyCex
from Candidate import Candidate, Emergent
from Structs import Tree, tree_to_expr
from Sketch import dumps

class PruningConstraint:

    def __init__(
            self, 
            clauses : list[tuple[int, Tree]], 
            sk_ids : tuple[int,...],
            annotation : str|None = None):
        self.clauses = clauses
        assert isinstance(sk_ids, tuple)
        self.sk_ids = sk_ids
        self.annotation = annotation
        if len(self.clauses) == 0:
            raise ValueError("PruningConstraint must have at least one clause.")

    def sat(self, tpl : list[Tree]) -> bool:
        """Returns True if there exists a clause (idx, expr) such that
        tpl[idx] != expr. Otherwise, returns False.      
        """
        for clause in self.clauses:
            idx, expr = clause
            cand_expr = tpl[idx]
            assert isinstance(cand_expr, Tree)
            if cand_expr != expr:
                return True
        return False

    def __repr__(self):
        if self.annotation is not None:
            return f"PruningConstraint({self.clauses}, {self.annotation})"
        return f"PruningConstraint({self.clauses})"

def satisfies_constraints(
        tpl : list[Tree], pcs : list[PruningConstraint]) -> PruningConstraint | None:
    for pc in pcs:
        if not pc.sat(tpl):
            return pc
    return None

class Generalizer:

    def generalize(
            self, candidate : Candidate, cex : Cex) -> list[PruningConstraint]:
        raise NotImplementedError("Child class implements this method")

class DefaultGeneralizer(Generalizer):

    def generalize(
            self, candidate : Candidate, cex : Cex) -> list[PruningConstraint]:
        return []

def contract_generalize(
        candidate : Candidate, cex : ContractCex) -> list[PruningConstraint]:
    direct = cex.hole_name
    deps = candidate.input_contract_deps(direct)
    clauses = []
    for dep in deps:
        idx = candidate.hole_names().index(dep)
        expr = candidate.emergent.tpl[idx]
        clauses.append((idx, expr))
    idx = candidate.hole_names().index(direct)
    expr = candidate.emergent.tpl[idx]
    clauses.append((idx, expr))
    sk_id = candidate.sketch_ids()
    return [PruningConstraint(clauses, sk_id, "contract")]

def const_guard_generalize(
        self, candidate : Candidate) -> list[PruningConstraint]:
    """Determines if any guards in candidate are constant (upto their 
    execution path/input contract). If so, returns a list of pruning 
    constraints that eliminate those guards in the future.

    For instance, if ???1 := (endp xs) and ???3 := (memberp (head xs) xs), then
    ???3 always evaluates to True if not ???1 is a necessary condition to reach
    ???3. We would add the constraint 

            [(idx(???1), (endp xs)), (idx(???3), (memberp (head xs) xs))] 

    to indicate that all candidates with these guards can be skipped.
    """
    # Iterate over the guard holes.
    # For each, check if it is a constant under its :ic.
    # If so, identify the other guard holes that appear in the :ic.
    # Use this information to create pruning constraints.
    guard_holes = candidate.guard_holes()
    deps = None
    ghole_idx = None
    found = False
    for ghole in guard_holes:
        ghole_idx = candidate.hole_names().index(ghole)
        expr = tree_to_expr(candidate.emergent.tpl[ghole_idx])
        ic, deps = candidate.no_hole_ic(ghole)
        type_hyp = candidate.mk_type_hyp_hole(ghole)
        hyp = [sx.Symbol("and"), type_hyp, ic]

        imp_pos = [sx.Symbol("implies"), hyp, expr]
        cmd_pos = [sx.Symbol("test?"), imp_pos]
        cmd_pos = dumps(cmd_pos)
        if self.check(cmd_pos):
            found = True
            break
        
        imp_neg = [sx.Symbol("implies"), hyp, [sx.Symbol("not"), expr]]
        cmd_neg = [sx.Symbol("test?"), imp_neg]
        cmd_neg = dumps(cmd_neg)
        if self.check(cmd_neg):
            found = True
            break

    if found:
        assert deps is not None
        assert ghole_idx is not None
        idxs = [candidate.hole_names().index(x) for x in deps]
        clauses = [(idx, candidate.emergent.tpl[idx]) for idx in idxs]
        clauses.append((ghole_idx, candidate.emergent.tpl[ghole_idx]))
        sk_id = candidate.sketch_ids()
        return [PruningConstraint(clauses, sk_id, "const_guard")]

    return []

def termination_generalize(
        candidate : Candidate, cex : TerminationCex) -> list[PruningConstraint]:
    idxs = [candidate.hole_names().index(x) for x in cex.hole_names]
    clauses = [(idx, candidate.emergent.tpl[idx]) for idx in idxs] 
    sk_id = candidate.sketch_ids()
    return [PruningConstraint(clauses, sk_id, "termination")]

def prop_generalize(
        candidate : Candidate, cex : PropertyCex) -> list[PruningConstraint]:
    rel_holes = cex.relevant_holes(candidate.hole_names())
    if rel_holes is None:
        return []
    if len(rel_holes) == len(candidate.hole_names()):
        # If all holes are relevant, we do not generalize.
        return []
    idxs = [candidate.hole_names().index(x) for x in rel_holes]
    clauses = [(idx, candidate.emergent.tpl[idx]) for idx in idxs]
    sk_id = candidate.sketch_ids()
    print("Generalizing property cex with clauses:", clauses)
    return [PruningConstraint(clauses, sk_id, "property")]


class ConstTermPropGeneralizer(Generalizer):
    def __init__(self, session : Session):
        super().__init__()
        self.session = session
        self.cache = dict()

    def check(self, cmd : str) -> bool:
        if cmd not in self.cache:
            output = self.session.send(cmd)
            self.cache[cmd] = "Test? proved the conjecture under consideration." in output
        return self.cache[cmd]

    def generalize(
            self, candidate : Candidate, cex : Cex) -> list[PruningConstraint]:
        res = []
        if isinstance(cex, ContractCex):
            return contract_generalize(candidate, cex)
        if isinstance(cex, TerminationCex):
            pcs = termination_generalize(candidate, cex)
            res += pcs
        if isinstance(cex, PropertyCex):
            pcs = prop_generalize(candidate, cex)
            res += pcs
        pcs = eq_guard_generalize(candidate)
        res += pcs
        return res

def eq_guard_generalize(
        candidate : Candidate) -> list[PruningConstraint]:
    guard_holes = candidate.guard_holes()
    idxs = [candidate.hole_names().index(x) for x in guard_holes]
    pcs = []
    sk_id = candidate.sketch_ids()
    for i in idxs:
        dps = candidate.input_contract_deps(candidate.hole_names()[i])
        js = [candidate.hole_names().index(x) for x in dps if x in guard_holes]
        for j in js:
            expr_i : Tree = candidate.emergent.tpl[i]
            expr_j : Tree = candidate.emergent.tpl[j]
            if expr_i != expr_j:
                continue
            pc = [(i, expr_i), (j, expr_j)]
            pcs.append(PruningConstraint(pc, sk_id, "eq_guard"))
    return pcs


