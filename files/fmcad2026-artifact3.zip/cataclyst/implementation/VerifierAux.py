import re
from pprint import pprint
import sexpdata as sx
import pexpect
from Structs import Interpretation, Trace, Expression, Property
from Structs import dumps
from Sketch import sx_filter

CMD_END = "</CMD>"
ACL2S = "ACL2S !>"
ACL2_ERROR = "ACL2 Error"
TIME_LIMIT_ERROR = "[Time-limit]"
CEX_FOUND = "Test? found a counterexample."

def force_tests(cmd : Expression):
    assert isinstance(cmd, list)
    assert cmd[0] == sx.Symbol("definec")
    cmd = cmd[:-1] + sx.loads("(:skip-tests nil)") + [cmd[-1]]
    return cmd

def parse_output(output : str) -> tuple[Interpretation, list[str]]:
    forms = [
        line for line in output.splitlines() 
        if line.strip().startswith("Form")]
    if "Nothing to test!" in output.replace("\n", " "):
        return Interpretation({}), forms
    cex_block = output[output.find("**We falsified"):].strip()
    assoc = re.search(r'--(.*?)(?:\n\s*\n)', cex_block, re.DOTALL)
    if assoc is None:
        raise ACL2Error("Could not find association list in output:\n" + cex_block)
    assoc = assoc.group(1).strip()
    assoc = sx.loads(assoc)
    assoc = {k : v for k, v in assoc}
    interpretation = Interpretation(assoc)
    return interpretation, forms

class ACL2Error(Exception):
    """Exception raised when ACL2 throws an error.
    """
    def __init__(self, message):
        super().__init__(message)
        self.message = message

class Cex:

    def __init__(
            self, 
            interpretation : Interpretation,
            forms : list[str],
            sketch_ids : tuple[int,...]):
        self.interpretation = interpretation
        self.forms = forms
        self.sketch_ids = sketch_ids

    def interpretations(self):
        return [self.interpretation]

    def __repr__(self):
        id_str = [str(sketch_id)[-4:] for sketch_id in self.sketch_ids]
        return f"{self.__class__.__name__}({self.interpretation}, sk_id=...{id_str})"
    

class NoOpCex(Cex):
    """Sentinel counterexample that rejects a candidate without learning."""

    def __init__(self):
        super().__init__(Interpretation({}), [], tuple())

    def interpretations(self):
        return []

    def __repr__(self):
        return "NoOpCex()"


class ContractCex(Cex):
    
    def __init__(
            self, 
            interpretation : Interpretation,
            forms : list[str],
            sketch_ids : tuple[int,...],
            hole_name : sx.Symbol,
            hole_expr : Expression):
        super().__init__(interpretation, forms, sketch_ids)
        self.hole_name = hole_name
        if len(forms) == 3:
            if not isinstance(hole_expr, list):
                raise ValueError(
                    f"Do not fill hole {dumps(hole_name)} with constant/variable"
                    f" {dumps(hole_expr)}. Doing so is a trivial function"
                    " contract violation and there is no good reason for it.")
            args = [sx.Symbol(f"X{i}") for i in range(len(hole_expr)-1)]
            bad_call = [hole_expr[0]] + args
            bad_call = dumps(bad_call)
            head = hole_expr[0]
            raise ValueError(
                "Found 3 Forms in ContractCex. This indicates a function"
                " contract violation. This indicates a malformed sketch."
                " Suppose N is a non-terminal of the input that generates"
                " expression e of type t. If N is a start non-terminal of"
                " hole h with return type t', then it should always be the"
                " case that t is a subtype of t'. Check hole"
                f" {dumps(hole_name)}, which was filled with"
                f" {dumps(hole_expr)} in order to generate this ContractCex."
                " If you genuinely need to be able to generate e of the form"
                f" {bad_call},"
                f" where the Xi are the non-terminals generating the problem"
                " arguments,"
                " consider defining a user function that wraps"
                f" {head} and adds a guard to prevent the erroneous case here."
                " This"
                " guard will then cause a body contract violation (of the"
                " wrapper function's guard) rather than a function contract"
                " violation of the hole. For instance, cdr vs. head. (cdr nil)"
                " evaluates to nil, (head nil) is a guard violation.")

    def __repr__(self):
        id_str = [str(sketch_id)[-4:] for sketch_id in self.sketch_ids]
        return (f"{self.__class__.__name__}("
                f"{self.interpretation}, sk_id=...{id_str}, "
                f"hole={self.hole_name})")

    def __eq__(self, other):
        if not isinstance(other, ContractCex):
            return False
        return (self.interpretation == other.interpretation and
                self.hole_name == other.hole_name and
                self.sketch_ids == other.sketch_ids)
            
class TerminationCex(Cex):

    def __init__(
            self, 
            interpretation : Interpretation,
            forms : list[str],
            sketch_ids : tuple[int,...],
            hole_names : list[sx.Symbol]):
        super().__init__(interpretation, forms, sketch_ids)
        self.hole_names = hole_names

    def __repr__(self):
        id_str = [str(sketch_id)[-4:] for sketch_id in self.sketch_ids]
        return (f"{self.__class__.__name__}("
                f"{self.interpretation}, sk_id=...{id_str}, "
                f"holes={self.hole_names})")

    def __eq__(self, other):
        if not isinstance(other, TerminationCex):
            return False
        return (self.interpretation == other.interpretation and
                self.hole_names == other.hole_names and
                self.sketch_ids == other.sketch_ids)

class PropertyCex(Cex):
    def __init__(
            self, 
            interpretation : Interpretation,
            forms : list[str],
            sketch_ids : tuple[int,...],
            trace : Trace|None,
            interpretations : list[Interpretation]):
        super().__init__(interpretation, forms, sketch_ids)
        self.trace = trace
        self._interpretations = interpretations

    def relevant_holes(self, hnames : list[sx.Symbol]) -> None|list[sx.Symbol]:
        """Return the holes that are relevant to this property counterexample.

        The use of strings here is a bit hacky.
        """
        if self.trace is None:
            return None
        return [h for h in hnames if dumps(h) in self.trace.raw]

    def interpretations(self):
        return self._interpretations

class Session:

    def __init__(self):
        self.child = pexpect.spawn('acl2s', encoding='utf-8', timeout=None)
        self.child.expect(ACL2S)
        self.banner = self.child.before
        self.command_log = []

    def send(self, cmd : str) -> str:
        assert isinstance(cmd, str), "Session command must be a string."
        print(cmd)
        cmd += f'"{CMD_END}"'
        self.command_log.append(cmd)
        if any(len(line) > 4095 for line in cmd.splitlines()):
            raise ValueError(
                "ACL2s expects each line to be < 4095 characters."
            )
        self.child.sendline(cmd)
        self.child.expect(f'{ACL2S}"{CMD_END}"')
        res = self.child.before
        self.child.expect(ACL2S)
        if res is None:
            raise ValueError("No response from ACL2s")
        res = res[len(cmd)+1:].replace("\r", "")
        return res


