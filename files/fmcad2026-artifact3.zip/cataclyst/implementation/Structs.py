from itertools import chain
from pprint import pprint
import sexpdata as sx

Expression = int | str | bool | sx.Symbol | sx.Quoted | list["Expression"]

def sx_filter(expr : Expression, pred):
    '''Recursively find subexpressions in expr that match pred.
    Matches ARE explored further.
    '''
    matches = []
    if pred(expr):
        matches.append(expr)
    if isinstance(expr, list):
        for x in expr:
            matches += sx_filter(x, pred)
    return matches


def sx_sub_symbol(
        expr : Expression,
        old_symbol : sx.Symbol,
        new_expr : Expression) -> Expression:
    """Substitutes all occurrences of `old_symbol` in `expr` with `new_expr`.
    """
    if isinstance(expr, sx.Symbol):
        if expr == old_symbol:
            return new_expr
        else:
            return expr
    elif isinstance(expr, list):
        return [sx_sub_symbol(x, old_symbol, new_expr) for x in expr]
    else:
        return expr


def sx_substitute_applications(
        expr : Expression,
        substitutions : list[tuple[sx.Symbol,sx.Symbol]]) -> Expression:
    if not isinstance(expr, list):
        return expr
    if len(expr) == 0:
        return expr
    for fn, replacement in substitutions:
        if expr[0] == fn:
            return [replacement] + [sx_substitute_applications(x, substitutions) for x in expr[1:]]
    return [sx_substitute_applications(x, substitutions) for x in expr]

def sx_substitute_applications2(
        expr : Expression,
        substitutions) -> Expression:
    if not isinstance(expr, list):
        return expr
    if len(expr) == 0:
        return expr
    for fn, replacement in substitutions:
        if expr[0] != fn:
            continue
        tail = [sx_substitute_applications2(x, substitutions) for x in expr[1:]]
        return replacement(tail)
    return [sx_substitute_applications2(x, substitutions) for x in expr]



def dumps(sexpr : Expression, pretty_print=None) -> str:
    """For pretty-printing to acl2s.
    """
    pretty_print = pretty_print if pretty_print is not None else True
    s = sx.dumps(sexpr).replace("\\?", "?")
    return s

class Trace:
    def __init__(self, raw : str, extended : list):
        self.raw = raw
        self.extended = extended

    def __repr__(self):
        return f"Trace({self.raw})"

class UserFunction:
    def __init__(
            self,
            name : sx.Symbol,
            args : list[sx.Symbol],
            arg_types : list[sx.Symbol],
            return_type : sx.Symbol,
            ic : Expression,
            body : Expression):
        self.name = name
        self.args = args
        self.arg_types = arg_types
        self.return_type = return_type
        self.ic = ic
        self.body = body
        assert len(args) == len(arg_types)

    def guard(self) -> Expression:
        """Returns the guard of the user function.
        """
        clauses : Expression = []
        for arg, arg_type in zip(self.args, self.arg_types):
            raw_type = dumps(arg_type)
            if not raw_type.startswith(":"):
                raise ValueError(f"Expected argument type to start with ':', got {raw_type}")
            predicate_name = f"{raw_type[1:]}p"
            clauses.append([sx.Symbol(predicate_name), arg])
        clauses.append(self.ic)
        return [sx.Symbol("and")] + clauses

    def __repr__(self):
        args = list(chain(*zip(self.args, self.arg_types)))
        expr = [
            sx.Symbol("definec"), self.name, args, self.return_type,
            sx.Symbol(":ic"), self.ic, 
            self.body]
        return dumps(expr)

class UserSpace:

    def __init__(self, user_functions: list[UserFunction]):
        self.user_functions = user_functions
        self._user_function_map = {uf.name: uf for uf in user_functions}
        self.stack = []

        self._trace = set()
        self._extended_trace : list[Expression] = []

    def get(self, name: sx.Symbol) -> UserFunction:
        if name not in self._user_function_map: 
            raise ValueError(f"User function {name} not found in user space.")
        return self._user_function_map[name]

    def member(self, name: sx.Symbol) -> bool:
        """Check if a user function is in the user space.
        """
        return name in self._user_function_map

    def push(self, ufs: list[UserFunction]):
        """Temporarily add a list of user functions to the user space.
        """
        if len(self.stack) != 0:
            raise ValueError("Cannot push user function while stack is not empty.")
        assert isinstance(ufs, list)
        for uf in ufs:
            if uf.name in self._user_function_map:
                raise ValueError(f"User function {uf.name} already exists in user space.")
            self._user_function_map[uf.name] = uf
            self.user_functions.append(uf)
        self.stack.append(ufs)

    def pop(self):
        """Remove the last pushed user function from the user space.
        """
        if len(self.stack) == 0:
            raise ValueError("Cannot pop user function from empty stack.")
        ufs = self.stack.pop()
        for uf in ufs:
            self.user_functions.remove(uf)
            del self._user_function_map[uf.name]
        self._trace = set()
        self._extended_trace = []

    def trace(self, fn_name : sx.Symbol):
        self._trace.add(fn_name)

    def extended_trace_note_user_call(
            self,
            fn_name : sx.Symbol,
            actuals : list[Expression],
    ) -> None:
        """Append one user-function call with evaluated actuals to the log.

        Inputs: ``fn_name`` is the callee; ``actuals`` matches callee formals
        in order. Output: appends ``[fn_name] + actuals`` to ``_extended_trace``.
        """
        self._extended_trace.append([fn_name] + actuals)


class Interpretation:

    def __init__(self, assoc : dict[sx.Symbol, Expression]):
        self.assoc = assoc
        self.frozen = tuple(sorted([
            (dumps(k), dumps(v)) for k, v in assoc.items()]))

    def __eq__(self, other):
        if isinstance(other, Interpretation):
            return self.frozen == other.frozen
        return False
    def __hash__(self):
        return hash(self.frozen)
    def __repr__(self):
        return str({dumps(k): dumps(v) for k, v in self.assoc.items()})
    def __str__(self):
        return self.__repr__()

class Tree:
    def __init__(self):
        self._expr = None

    def to_expr(self) -> Expression:
        if self._expr is None:
            self._expr = tree_to_expr(self)
        return self._expr

class Terminal(Tree):
    def __init__(self, value):
        super().__init__()
        self.value = value
    def __repr__(self):
        return f"'{self.value}'"
    def __str__(self):
        return self.__repr__()
    def __eq__(self, other):
        if isinstance(other, Terminal):
            if type(self.value) != type(other.value):
                return False
            return self.value == other.value
        return False

class NonTerminal(Tree):
    def __init__(self, value):
        super().__init__()
        self.value = value
    def __repr__(self):
        return f"<{self.value}>"
    def __str__(self):
        return self.__repr__()
    def __eq__(self, other):
        if isinstance(other, NonTerminal):
            return self.value == other.value
        return False
    def __hash__(self):
        return hash(self.value)

class Branch(Tree):
    def __init__(self, value, children : list[Tree]):
        super().__init__()
        self.value = value
        self.children = children
    def __repr__(self):
        return f"({self.value} {' '.join(map(str, self.children))})"
    def __str__(self):
        return self.__repr__()
    def __eq__(self, other):
        if isinstance(other, Branch):
            return (self.value == other.value and 
                    len(self.children) == len(other.children) and
                    all(c1 == c2 for c1, c2 in zip(self.children, other.children)))
        return False

class Hole:
    def __init__(
            self, 
            name: sx.Symbol, 
            return_type: sx.Symbol, 
            nts : list[NonTerminal],
            args : list[sx.Symbol],
            arg_types: list[sx.Symbol],
            tgt_function : sx.Symbol|None,
            additional_term_hyp : list[Expression]|None = None):
        self.name = name
        self.return_type = return_type
        self.nts = nts
        self.args = args
        self.arg_types = arg_types
        self.tgt_function = tgt_function
        self.additional_term_hyp = additional_term_hyp

class Rule:

    def __init__(self, nt : NonTerminal, tree : Tree, hints : list[sx.Symbol]):
        assert isinstance(nt, NonTerminal)
        self.nt = nt
        self.tree = tree
        self.hints = hints
    def __repr__(self):
        return f"Rule({self.nt}, {self.tree}, {self.hints})"
    def __str__(self):
        return self.__repr__()

def tree_size(tree : Tree) -> int:
    if isinstance(tree, Terminal):
        return 1
    elif isinstance(tree, NonTerminal):
        return 1
    elif isinstance(tree, Branch):
        return 1 + sum(tree_size(child) for child in tree.children)
    else:
        raise ValueError("Unknown tree type")

def expr_size(expr: Expression) -> int:
    if isinstance(expr, list):
        if len(expr) == 0:
            return 1 
        assert isinstance(expr[0], sx.Symbol), "Expected list to application"
        return 1 + sum(expr_size(child) for child in expr[1:])
    else:
        return 1

def tree_to_expr(tree: Tree) -> Expression:
    if isinstance(tree, Terminal):
        return tree.value
    elif isinstance(tree, NonTerminal):
        return tree.value
    elif isinstance(tree, Branch):
        return [tree.value] + [tree_to_expr(child) for child in tree.children]
    else:
        raise ValueError("Unknown tree type")

class Property:

    def __init__(
            self,
            cmd : Expression,
            eval_inner : Expression | None = None):
        """Hold ACL2s `test?` form plus optional eval-only inner body.

        `cmd` is ``(test? <acl2s-inner>)`` for session discharge. When a
        property uses ``:extra-hyp`` in the instance file, ``<acl2s-inner>``
        includes that hypothesis; ``eval_inner`` omits it for ``local_eval``
        replay. If ``eval_inner`` is None, ``cmd[1]`` is used for eval and for
        ``filter_fn_names`` (which must not depend on ACL2-only fragments).
        """
        self.cmd = cmd
        assert isinstance(cmd, list)
        assert len(cmd) >= 2
        assert cmd[0] == sx.Symbol("test?")
        self.eval_inner = cmd[1] if eval_inner is None else eval_inner
        self.cmd_str = dumps(cmd)
        self.fn_names = None

    def filter_fn_names(self, fn_names : list[sx.Symbol]) -> list[sx.Symbol]:
        """Return sketch function names referenced by the eval property body.

        Uses ``eval_inner`` (not the full ACL2s ``cmd``) so ACL2s-only pieces
        such as ``:extra-hyp`` do not affect ``PropertyCache`` admit keys.
        """
        if self.fn_names is not None:
            return self.fn_names
        res = set()
        for fn in sx_filter(
                self.eval_inner,
                lambda x: isinstance(x, sx.Symbol) and x in fn_names):
            res.add(fn)
        self.fn_names = list(res)
        return self.fn_names

    def mk_thm(self, name):
        assert isinstance(name, str)
        assert isinstance(self.cmd, list)
        assert len(self.cmd) == 2
        return [
            sx.Symbol("defthm"), sx.Symbol(name), self.cmd[1],
            sx.Symbol(":rule-classes"), False]
    
    def mk_cmd_str(self, sub : dict[sx.Symbol,sx.Symbol]) -> str:
        cmd = sx_substitute_applications(
            self.cmd, [(k,v) for k, v in sub.items()])
        cmd_str = dumps(cmd)
        return cmd_str

class TerminationProperty(Property):

    def __init__(
            self, 
            cmd : Expression, 
            hole_names : list[sx.Symbol], 
            tgt_function : sx.Symbol|None):
        super().__init__(cmd)
        self.hole_names = hole_names
        self.tgt_function = tgt_function


