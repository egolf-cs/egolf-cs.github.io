from itertools import chain, product
import time
from pprint import pprint
import sexpdata as sx
from Sketch import Sketch
from Structs import dumps
from Structs import Terminal, NonTerminal, Branch, Rule, Tree, Hole
from Structs import Property, Expression
from Structs import UserSpace, UserFunction
from Structs import Interpretation
from Structs import sx_substitute_applications2
from Structs import sx_sub_symbol
from declare_datatype.parse import parse_declare_datatype, parse_declare_datatypes
from declare_datatype.pprint_acl2s import ddtg_to_acl2s
from SketchHandler import SketchHandler
from ExistHandler import ExistHandler

ITE_FN = sx.Symbol("ite")
ITE_COND_TYPE = sx.Symbol(":bool")
IF_SYM = sx.Symbol("if")


def _validate_ite_definec(
        raw: Expression,
        name: sx.Symbol,
        args: list[sx.Symbol],
        arg_types: list[sx.Symbol],
        return_type: sx.Symbol,
        body: Expression,
) -> None:
    """Ensure user ``definec ite`` matches the required lazy-if shape.

    When the name is ``ite``, the body must be exactly ``(if`` followed by
    the three formals in parameter order, the first formal has type ``:bool``,
    and the second and third formals share the declared result type (so both
    branches match the ``definec`` return type).
    """
    if name != ITE_FN:
        return
    if not isinstance(raw, list) or len(raw) < 5:
        raise ValueError(
            f"definec ite must be (definec ite (<args>) <rtype> <body>); "
            f"got {dumps(raw) if isinstance(raw, list) else raw!r}.",
        )
    decl_ret = raw[3]
    if not isinstance(decl_ret, sx.Symbol):
        raise ValueError(
            f"definec ite: expected return type symbol at index 3, got "
            f"{decl_ret!r} in {dumps(raw)}.",
        )
    if decl_ret != return_type:
        raise ValueError(
            f"definec ite: return type slice mismatch (internal parse); "
            f"expected {dumps(decl_ret)} at end-minus-one position, got "
            f"{dumps(return_type)}. If you used :ic on ite, remove it or "
            f"extend the parser.",
        )
    if len(args) != 3 or len(arg_types) != 3:
        raise ValueError(
            f"definec ite requires exactly three formals (bool, T, T); got "
            f"{len(args)} args in {dumps(raw)}.",
        )
    if arg_types[0] != ITE_COND_TYPE:
        raise ValueError(
            f"definec ite: first formal must be :bool, got "
            f"{dumps(arg_types[0])} in {dumps(raw)}.",
        )
    if arg_types[1] != decl_ret or arg_types[2] != decl_ret:
        raise ValueError(
            f"definec ite: second and third formal types must match return "
            f"type {dumps(decl_ret)}; got {dumps(arg_types[1])} and "
            f"{dumps(arg_types[2])} in {dumps(raw)}.",
        )
    expected_body: Expression = [IF_SYM, args[0], args[1], args[2]]
    if body != expected_body:
        raise ValueError(
            f"definec ite body must be (if <1st-formal> <2nd-formal> "
            f"<3rd-formal>), i.e. {dumps(expected_body)}; got "
            f"{dumps(body) if isinstance(body, list) else body!r} in "
            f"{dumps(raw)}.",
        )


def _append_definec_to_user_space(
        aux_user_space: list[UserFunction], uf: UserFunction) -> None:
    """Maybe append a parsed definec to the list used to build ``UserSpace``.

    Appends ``uf`` to ``aux_user_space`` except when ``uf.name`` is ``ite``,
    which stays out so ``local_eval`` keeps its built-in lazy ``ite``.

    Inputs: ``aux_user_space`` (mutated); ``uf`` from ``parse_definec``.
    Output: zero or one append to ``aux_user_space``.

    Example: ``ite`` is skipped; any other name is appended.
    """
    if uf.name == ITE_FN:
        return
    aux_user_space.append(uf)


def _parse_lisp_bool(val: Expression) -> bool:
    """Coerce Lisp `t` / `nil` (and empty list) to Python bool.

    Used for top-level directives such as `(set-validate nil)`.
    """
    if isinstance(val, list) and len(val) == 0:
        return False
    if val is False:
        return False
    if val is True:
        return True
    if val == sx.Symbol("nil"):
        return False
    if val == sx.Symbol("t"):
        return True
    raise ValueError(
        f"Expected Lisp t or nil, got {val!r}.")


class Grammar:

    def __init__(self, rules: list[Rule]):
        self.rules = rules

    def generates(self, nt : NonTerminal, expr : Expression) -> bool:
        """Checks if nt generates the expression expr.
        """
        assert isinstance(nt, NonTerminal)
        assert not isinstance(expr, Tree)
        for rule in self.rules:
            if rule.nt != nt:
                continue
            if isinstance(rule.tree, Terminal):
                val = rule.tree.value
                if sx.dumps(val) == sx.dumps(expr):
                    return True
            elif isinstance(rule.tree, Branch):
                if not isinstance(expr, list):
                    continue
                if len(expr) == 0:
                    continue
                if rule.tree.value != expr[0]:
                    continue
                if len(rule.tree.children) != len(expr) - 1:
                    continue
                bs = []
                for child, sub_expr in zip(rule.tree.children, expr[1:]):
                    assert isinstance(child, NonTerminal)
                    bs.append(self.generates(child, sub_expr))
                    if bs[-1] is False:
                        break
                if all(bs):
                    return True
            else:
                raise ValueError(
                    f"Expected grammar to be in normal form, found {rule.tree}")
        return False

    def __repr__(self):
        return "\n".join(str(rule) for rule in self.rules)

class Preamble:

    def __init__(self, cmds : list[str]):
        self.cmds = cmds

class Instance:

    def __init__(
            self,
            sketches: dict[sx.Symbol,list[Sketch]],
            grammar : Grammar,
            holes : list[Hole],
            preamble : Preamble,
            properties : list[Property],
            smt_properties : list[str],
            user_space : UserSpace,
            subexpr_bound : int,
            base_interps : list[Interpretation],
            primitives : None|list[sx.Symbol],
            validate_targets : bool = True,
    ) -> None:
        """Assemble a synthesis instance; see `(set-validate ...)` in `parse`."""
        assert isinstance(sketches, dict)
        self.sketches = sketches
        self.grammar = grammar
        self.holes = holes
        self._preamble = preamble
        self._properties = properties
        self._smt_properties = smt_properties
        self.user_space = user_space
        self.subexpr_bound = subexpr_bound
        self.base_interps = base_interps
        self.primitives = primitives
        self.validate_targets = validate_targets

    def prod_sketches(self) -> list[list[Sketch]]:
        ps = product(*self.sketches.values())
        ps = [list(sketches) for sketches in ps]
        val = set()
        for p in ps:
            v = tuple(sk.name for sk in p)
            val.add(v)
        assert len(val) == 1
        return ps

    def preamble(self) -> list[str]:
        """Return the preamble commands for this instance."""
        base_cmds = [
            "(acl2s-defaults :set num-counterexamples 1)"
            "(acl2s-defaults :set num-witnesses 0)"
            "(acl2s-defaults :set num-trials 10000)"
            "(table defunc-defaults-table :skip-tests t)"
        ]
        return base_cmds + self._preamble.cmds

    def properties(self) -> list[Property]:
        """Return the property commands for this instance."""
        return self._properties

    def smt_properties(self) -> list[str]:
        """Return SMT property directives for this instance."""
        return self._smt_properties

    def nts(self, hname : sx.Symbol) -> list[NonTerminal]:
        for hole in self.holes:
            if hole.name == hname:
                return hole.nts
        raise ValueError(f"Hole {hname} not found in instance.")

    def start_ntss(self) -> list[list[list[NonTerminal]]]:
        res = []
        for sketches in self.prod_sketches():
            hnames = []
            for sketch in sketches:
                hnames += sketch.hole_names()
            start_nts = [self.nts(hn) for hn in hnames]
            res.append(start_nts)
        return res

    def branch_rules(self) -> list[Rule]:
        """Return rules of the form NT -> [f NT1, NT2, ..., NTk],
        where f is a function symbol and NT1, NT2, ..., NTk are non-terminal 
        symbols.
        """
        res = []
        for rule in self.grammar.rules:
            if isinstance(rule.tree, Branch):
                res.append(rule)
        return res
        
    def terminal_rules(self) -> list[Rule]:
        """Return rules of the form NT -> T, where T is a terminal symbol.
        """
        res = []
        for rule in self.grammar.rules:
            if isinstance(rule.tree, Terminal):
                res.append(rule)
        return res

def parse_rule_body_rec(rule_body, nts) -> Tree:
    if not isinstance(rule_body, list):
        if rule_body in nts:
            return NonTerminal(rule_body)
        else:
            return Terminal(rule_body)
    if len(rule_body) == 0:
        return Terminal(False)
    head = rule_body[0]
    tail = [parse_rule_body_rec(x, nts) for x in rule_body[1:]]
    return Branch(head, tail)

def parse_rule_body(rule_body, nts) -> tuple[Tree, list[sx.Symbol]]:
    if not isinstance(rule_body, list):
        return parse_rule_body_rec(rule_body, nts), []
    hints = [
        x for x in rule_body 
        if isinstance(x, sx.Symbol) and dumps(x).startswith(":")]
    rule_body = [
        x for x in rule_body
        if not (isinstance(x, sx.Symbol) and dumps(x).startswith(":"))]
    return parse_rule_body_rec(rule_body, nts), hints 

def parse_deflocal(x : Expression) -> UserFunction:
    name = x[1] # type:ignore
    args_raw = x[2]# type:ignore
    args = args_raw[::2]# type:ignore
    arg_types = args_raw[1::2]# type:ignore
    return_type = x[-2]# type:ignore
    body = x[-1]# type:ignore
    assert isinstance(name, sx.Symbol)
    assert isinstance(return_type, sx.Symbol)
    uf = UserFunction(name, args, arg_types, return_type, True, body)# type:ignore
    return uf

def parse_definec(x : Expression) -> UserFunction:
    name = x[1]# type:ignore
    args_raw = x[2]# type:ignore
    ic = True
    for idx, raw in enumerate(x):# type:ignore
        if isinstance(raw, sx.Symbol) and dumps(raw) == ":ic":
            ic = x[idx + 1]# type:ignore
            break
    args = args_raw[::2]# type:ignore
    arg_types = args_raw[1::2]# type:ignore
    return_type = x[-2]# type:ignore
    body = x[-1]# type:ignore
    _validate_ite_definec(x, name, args, arg_types, return_type, body)
    uf = UserFunction(name, args, arg_types, return_type, ic, body)# type:ignore
    return uf


def _property_acl2_antecedent(
        type_hyp : Expression,
        extra_hyp : Expression | None) -> Expression:
    """Combine typing hypothesis with optional ACL2s-only ``:extra-hyp``."""
    if extra_hyp is None:
        return type_hyp
    if type_hyp == sx.Symbol("t"):
        return extra_hyp
    return [sx.Symbol("and"), type_hyp, extra_hyp]


def _subst_property_item(
        item : Expression | tuple,
        sub : list) -> Expression | tuple:
    """Apply substitution to a property cmd or ``(cmd, eval_inner)`` pair."""
    if isinstance(item, tuple):
        cmd, ev = item
        return (
            sx_substitute_applications2(cmd, sub),
            sx_substitute_applications2(ev, sub),
        )
    return sx_substitute_applications2(item, sub)


def parse(lisp_str : str):
    sexpr = sx.parse(lisp_str)

    prenex_props = [
        x for x in sexpr if (
            isinstance(x, list) 
            and len(x) > 0 
            and x[0] == sx.Symbol("prenex"))]
    ex_props = [
        x for x in sexpr if (
            isinstance(x, list) 
            and len(x) > 0 
            and x[0] == sx.Symbol("ex-property"))]
    smt_props = [
        x for x in sexpr if (
            isinstance(x, list)
            and len(x) > 0
            and x[0] == sx.Symbol("smt"))]
    if len(smt_props) > 0 and (len(prenex_props) > 0 or len(ex_props) > 0):
        raise ValueError(
            "Input cannot mix smt directives with prenex/ex-property directives.",
        )
    exhand = ExistHandler(ex_props, prenex_props)
    sexpr += exhand.properties()

    sigss = [
        x for x in sexpr if (
            isinstance(x, list) 
            and len(x) > 0 
            and x[0] in [sx.Symbol("defsig"), sx.Symbol("defsigs")])]
    sigss.extend(exhand.sigs())
    skhand = SketchHandler(sigss)


    measure_definecs = []
    aux_rules = {} 
    aux_preamble_tys = []
    aux_preamble_fns = []
    aux_properties = []
    aux_smt_properties = []
    aux_user_space = []
    subexpr_bound = None
    primitives = None
    base_interps = []
    validate_targets = True
    seen_set_validate = False
    for x in sexpr:
        if not (isinstance(x, list) and len(x) > 0):
            continue
        ##############################
        elif x[0] == sx.Symbol("defsig"):
            # this is now handled above
            # skhand.add_sig(x)
            pass
        elif x[0] == sx.Symbol("defsigs"):
            # this is now handled above
            # skhand.add_sigs(x)
            pass
        elif x[0] == sx.Symbol("defsketch"):
            skhand.add_sketch(x)
        elif x[0] == sx.Symbol("defsketch-tgt"):
            skhand.add_tgt_sketch(x)
        elif x[0] == sx.Symbol("deftgt"):
            skhand.add_tgt(x)
        ##############################
        elif x[0] == sx.Symbol("defmeasure"):
            assert len(x) in [5,6]
            skhand.add_measure(x)
            if len(x) == 6:
                # The last argument associates the measure with
                # the functions under synthesis. Handled by
                # skhand above. Drop the last argument here.
                x = x[:-1]
            args = x[2][::2]
            measure_definec = [
                sx.Symbol("definec"), *x[1:-1], 
                sx.Symbol(":skip-admissibilityp"), True, 
                x[-1]]
            measure_definecs.append(measure_definec)
            name = x[1]
            args_raw = x[2]
            args = args_raw[::2]
            arg_types = args_raw[1::2]
            return_type = x[-2]
            body = x[-1]
            uf = UserFunction(name, args, arg_types, return_type, True, body)
            aux_user_space.append(uf)
        elif x[0] == sx.Symbol("defnt"):
            assert len(x) == 3
            name = x[1]
            rule_body = x[2]
            aux_rules[name] = rule_body
        elif x[0] == sx.Symbol("defhole"):
            assert len(x) in [4, 5]
            name = x[1]
            return_type = x[2]
            nts = [NonTerminal(nt) for nt in x[3]]
            fn = None
            if len(x) == 5:
                fn = x[4]
            skhand.add_prec_hole(name, return_type, nts, fn)
        elif x[0] == sx.Symbol("defdata"):
            aux_preamble_tys.append(x)
        elif x[0] == sx.Symbol("deflocal"):
            # define functions for local_eval.py without submitting
            # them to acl2s. Necessary for automatically generated
            # function definitions, e.g., as in the case of def data
            # This is a little ad hoc; it would be better to rip
            # these out of the defdata event submitted to acl2s.
            # Treated exactly like definec, except not added to the
            # preamble. Only added to userspace.
            uf = parse_deflocal(x)
            aux_user_space.append(uf)
        elif x[0] == sx.Symbol("definec"):
            aux_preamble_fns.append(x)
            uf = parse_definec(x)
            _append_definec_to_user_space(aux_user_space, uf)
        elif x[0] == sx.Symbol("test?"):
            # if x[1][0] != sx.Symbol("=>"):
            #     raise ValueError(
            #         f"Expected test? to have an implication as first argument, "
            #         f"found {x[1][0]}.")
            # aux_properties.append(x)
            raise ValueError(
                "DEPRECATED: test? is no longer supported."
                " Use io, fn-property, or property instead.")
        elif x[0] == sx.Symbol("ex-property"):
            # handled above by exhand
            pass
        elif x[0] == sx.Symbol("prenex"):
            # handled above by exhand
            pass
        elif x[0] == sx.Symbol("property"):
            if len(x) < 3:
                raise ValueError(
                    "Expected (property (<typed-binders>) <conj> "
                    "[:extra-hyp <expr> ...]), "
                    f"got {x}.",
                )
            args, conj = x[1], x[2]
            assert isinstance(args, list)
            assert len(args) % 2 == 0
            extra_hyp : Expression | None = None
            kw_idx = 3
            while kw_idx < len(x):
                if kw_idx + 1 >= len(x):
                    raise ValueError(
                        f"property: missing value after keyword near {x}.",
                    )
                kw = x[kw_idx]
                if not isinstance(kw, sx.Symbol):
                    raise ValueError(
                        f"property: expected keyword symbol, got {kw}.",
                    )
                if not dumps(kw).startswith(":"):
                    raise ValueError(
                        f"property: expected :keyword, got {kw}.",
                    )
                val = x[kw_idx + 1]
                if kw == sx.Symbol(":extra-hyp"):
                    extra_hyp = val
                else:
                    raise ValueError(
                        f"property: unknown keyword {kw}.",
                    )
                kw_idx += 2
            type_hyp = []
            for arg, arg_type in zip(args[::2], args[1::2]):
                assert isinstance(arg, sx.Symbol)
                assert isinstance(arg_type, sx.Symbol)
                assert dumps(arg_type).startswith(":")
                pfn = sx.Symbol(f"{dumps(arg_type)[1:]}p")
                type_hyp.append([pfn, arg])
            if len(type_hyp) == 0:
                type_hyp = sx.Symbol("t")
            elif len(type_hyp) == 1:
                type_hyp = type_hyp[0]
            else:
                type_hyp = [sx.Symbol("and")] + type_hyp
            eval_inner = [sx.Symbol("=>"), type_hyp, conj]
            acl2_ant = _property_acl2_antecedent(type_hyp, extra_hyp)
            acl2_inner = [sx.Symbol("=>"), acl2_ant, conj]
            prop_cmd = [sx.Symbol("test?"), acl2_inner]
            if extra_hyp is None:
                aux_properties.append(prop_cmd)
            else:
                aux_properties.append((prop_cmd, eval_inner))
        elif x[0] == sx.Symbol("fn-property"):
            assert len(x) == 5
            fn, args, out, prop = x[1:]
            assert isinstance(fn, sx.Symbol)
            assert isinstance(args, list)
            assert len(args) % 2 == 0
            assert isinstance(out, sx.Symbol)

            args, arg_types = args[::2], args[1::2]
            apply : Expression = [fn] + args #type:ignore

            type_hyp = []
            for arg, arg_type in zip(args, arg_types):
                assert isinstance(arg, sx.Symbol)
                assert isinstance(arg_type, sx.Symbol)
                assert dumps(arg_type).startswith(":")
                pfn = sx.Symbol(f"{dumps(arg_type)[1:]}p")
                type_hyp.append([pfn, arg])
            if len(type_hyp) == 0:
                type_hyp = sx.Symbol("t")
            elif len(type_hyp) == 1:
                type_hyp = type_hyp[0]
            else:
                type_hyp = [sx.Symbol("and")] + type_hyp

            pred = sx_sub_symbol(prop, out, apply)

            impl = [sx.Symbol("=>"), type_hyp, pred] 
            prop = [sx.Symbol("test?"), impl]
            aux_properties.append(prop)
        elif x[0] == sx.Symbol("io"):
            print("TODO: handle io differently than full blown properties.")
            assert len(x) == 4
            fn, args, out = x[1:]
            assert isinstance(fn, sx.Symbol) 
            assert isinstance(args, list)
            apply = [fn] + args #type:ignore
            if isinstance(out, bool) and out:
                aux = apply
            elif isinstance(out, bool) and not out:
                aux = [sx.Symbol("not"), apply]
            elif isinstance(out, list) and len(out) == 0:
                aux = [sx.Symbol("not"), apply]
            else:
                aux = [sx.Symbol("equal"), apply, out]
            prop = [sx.Symbol("test?"), aux]
            aux_properties.append(prop)
        elif x[0] == sx.Symbol("smt"):
            if len(x) != 2:
                raise ValueError(
                    f"Expected smt directive of the form (smt <path>), got {x}.",
                )
            smt_path = dumps(x[1])
            aux_smt_properties.append(smt_path)
        elif x[0] == sx.Symbol("declare-datatype"):
            ddt_graph = parse_declare_datatype(x)
            ddts = ddtg_to_acl2s(ddt_graph)
            for ddt in ddts:
                cmd = ddt.compile_defdatas()
                aux_preamble_tys.append(cmd)
                for cmd in ddt.compile_destructors():
                    _append_definec_to_user_space(
                        aux_user_space, parse_definec(cmd))
                    aux_preamble_fns.append(cmd)
                for cmd in ddt.compile_constructors():
                    _append_definec_to_user_space(
                        aux_user_space, parse_definec(cmd))
                    aux_preamble_fns.append(cmd)
                for cmd in ddt.compile_predicates():
                    aux_user_space.append(parse_deflocal(cmd))
        elif x[0] == sx.Symbol("declare-datatypes"):
            ddt_graph = parse_declare_datatypes(x)
            ddts = ddtg_to_acl2s(ddt_graph)
            for ddt in ddts:
                cmd = ddt.compile_defdatas()
                aux_preamble_tys.append(cmd)
                for cmd in ddt.compile_destructors():
                    _append_definec_to_user_space(
                        aux_user_space, parse_definec(cmd))
                    aux_preamble_fns.append(cmd)
                for cmd in ddt.compile_constructors():
                    _append_definec_to_user_space(
                        aux_user_space, parse_definec(cmd))
                    aux_preamble_fns.append(cmd)
                for cmd in ddt.compile_predicates():
                    aux_user_space.append(parse_deflocal(cmd))
        elif x[0] == sx.Symbol("declare-primitives"):
            primitives = x[1:]
        elif x[0] == sx.Symbol("set-contata-bench"):
            pass
        elif x[0] == sx.Symbol("set-subexpr-bound"):
            assert len(x) == 2
            assert subexpr_bound is None
            subexpr_bound = x[1]
        elif x[0] == sx.Symbol("set-validate"):
            if len(x) != 2:
                raise ValueError(
                    f"Expected (set-validate t|nil), got {x}.",
                )
            if seen_set_validate:
                raise ValueError(
                    "(set-validate ...) may appear at most once in the input.",
                )
            seen_set_validate = True
            validate_targets = _parse_lisp_bool(x[1])
        else:
            raise ValueError(f"Unknown definition {x[0]} in input.")

    sketches = skhand.sketches()
    tgt_sketch_ids = skhand.tgt_sketch_ids()
    tgts = skhand.fn_tgts()
    sub = skhand.sub()
    holes = skhand.all_holes()
    defdatas = skhand.defdatas() + exhand.defdatas()
    definecs = skhand.definecs()
    deflocals = skhand.deflocals() + exhand.deflocals()
    new_primitives = skhand.new_primitives()

    assert primitives is not None
    primitives += new_primitives
    aux_preamble_tys.extend(defdatas)

    aux_preamble_fns.extend(definecs)
    for dfn in definecs:
        _append_definec_to_user_space(aux_user_space, parse_definec(dfn))

    ufs = [parse_deflocal(x) for x in deflocals]
    aux_user_space.extend(ufs)

    if len(measure_definecs) == 0:
        raise ValueError(
            "No measure definition found in input.")
    aux_preamble_fns.extend(measure_definecs)

    rules = []
    for name, rule_bodies in aux_rules.items():
        nt = NonTerminal(name)
        for rule_body in rule_bodies:
            parsed_rule_body, hints = parse_rule_body(rule_body, aux_rules)
            rules.append(Rule(nt, parsed_rule_body, hints))
    grammar = Grammar(rules)

    aux_preamble = aux_preamble_tys + aux_preamble_fns
    preamble = Preamble([dumps(cmd) for cmd in aux_preamble])
    aux_properties = [_subst_property_item(cmd, sub) for cmd in aux_properties]
    properties = []
    for item in aux_properties:
        if isinstance(item, tuple):
            cmd, eval_inner = item
            properties.append(Property(cmd, eval_inner))
        else:
            properties.append(Property(item))
    user_space = UserSpace(aux_user_space)

    if subexpr_bound is None:
        subexpr_bound = 4

    assert holes is not None
    inst = Instance(
        sketches, grammar, holes, preamble, properties, aux_smt_properties,
        user_space,
        subexpr_bound, base_interps, primitives, validate_targets,
    )

    print("Instance created.")
    return tgt_sketch_ids, tgts, inst


