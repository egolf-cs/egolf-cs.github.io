from pprint import pprint
import sexpdata as sx
from itertools import product

from Structs import Hole
from Sketch import Sketch, dumps
from Structs import sx_substitute_applications2

ARG = sx.Symbol("args")

def mk_constructor(fn):
    return sx.Symbol(f"{fn}-args")

def apply_constructor(fn, args):
    cons = mk_constructor(fn)
    return [sx.Symbol(cons)] + args 

class MutRecEncoding:

    def __init__(
            self, block, tgt_sketches, alt_sketches,
            tgt,
            sig_info, 
            measure, measure_arity,
            holes):
        self.block = block
        self._tgt_sketches = tgt_sketches
        self._alt_sketches = alt_sketches
        self.sig_info = sig_info
        self.measure = measure
        self.measure_arity = measure_arity
        self._tgt = tgt
        self.holes = holes
        
        # Name of function
        self._names = [dumps(fn) for fn in self.block]
        self._prename = "-".join(self._names)
        self.fn = sx.Symbol(f"{self._prename}-wrapper")

        # Single argument to function, wrapped as list
        self._arg = ARG
        self.fn_args = [self._arg]

        # Type of the argument, wrapped as list
        self._pre_unrune_arg_type = f"{self._prename}-args"
        self._unrune_arg_type = sx.Symbol(self._pre_unrune_arg_type)
        self.fn_arg_types = [sx.Symbol(f":{self._pre_unrune_arg_type}")]

        # Return type of the function
        self._pre_rtype = f"{self._prename}-ret"
        self.fn_rtype = sx.Symbol(f":{self._pre_rtype}")

        self.__definecs = None
        self.__new_primitives = None

    def all_sketches(self, fn):
        if fn not in self._alt_sketches:
            assert fn in self._tgt_sketches
            return [self._tgt_sketches[fn]]
        elif fn not in self._tgt_sketches:
            assert fn in self._alt_sketches
            return self._alt_sketches[fn]
        else:
            assert fn in self._alt_sketches
            assert fn in self._tgt_sketches
            return self._alt_sketches[fn] + [self._tgt_sketches[fn]]

    def alt_sketches(self):
        bodies = []
        sigs = [self.sig_info[fn] for fn in self.block]
        for prod in product(*[self.all_sketches(fn) for fn in self.block]):
            body, _ = self.mk_match(sigs, prod, self._arg, self.fn)
            bodies.append(body)
        return bodies

    def tgt(self):
        sigs = []
        body = []
        for fn in self.block:
            sig = self.sig_info[fn]
            assert len(sig) == 3
            sigs.append(sig)
            if fn in self._tgt:
                body.append(self._tgt[fn])
            else:
                assert len(self._tgt_sketches) == 0
                assert len(self._tgt) == 0
                return None
        body, _ = self.mk_match(sigs, body, self._arg, self.fn)
        tgt_args = self.fn_args + self.fn_arg_types
        return [
            sx.Symbol("definec"), self.fn, tgt_args,
            self.fn_rtype, body]

    def tgt_sketch(self):
        sigs = []
        sketch = []
        for fn in self.block:
            sig = self.sig_info[fn]
            assert len(sig) == 3
            sigs.append(sig)
            if fn in self._tgt_sketches:
                sketch.append(self._tgt_sketches[fn])
            else:
                assert len(self._tgt_sketches) == 0
                assert len(self._tgt) == 0
                return None
        body, _ = self.mk_match(sigs, sketch, self._arg, self.fn)
        return Sketch(
            self.fn, self.fn_args, self.fn_arg_types, self.fn_rtype,
            body, self.measure[1], self.measure_arity,
            self.holes)

    def sub(self):
        sigs = []
        bodies = []
        for fn in self.block:
            sig = self.sig_info[fn]
            assert len(sig) == 3
            sigs.append(sig)
            if fn in self._tgt_sketches:
                bodies.append(self._tgt_sketches[fn])
            else:
                assert len(self._tgt_sketches) == 0
                assert len(self._tgt) == 0
                assert fn in self._alt_sketches
                assert len(self._alt_sketches[fn]) > 0
                body = self._alt_sketches[fn][0]
                bodies.append(body)
        _, sub = self.mk_match(sigs, bodies, self._arg, self.fn)
        return sub

    def mk_replacement(self, name, constructor):
        def replacement(x):
            return [name, [constructor] + x]
        return replacement

    def mk_match(self, tgt_sigs, tgt_bodies, arg, name):
        names = []
        sub = []
        match_body = []
        tgt = zip(tgt_sigs, tgt_bodies)
        for (n, args, _), body in tgt: 
            names.append(n)
            constructor = mk_constructor(dumps(n))
            qconstructor = sx.Quoted(constructor)
            pattern = [qconstructor] + args[::2]
            match_term = [pattern, body]
            match_body.append(match_term)
            replacement = self.mk_replacement(name, constructor)
            sub.append((n, replacement))

        match_body = sx_substitute_applications2(match_body, sub)
        assert isinstance(match_body, list)
        return [sx.Symbol("match"), arg] + match_body, sub

    def defdatas(self):
        defdatas = []
        arg_sum_types = []
        ret_types_init = set()

        for fn in self.block:
            sig = self.sig_info[fn]   # [fn, [a1 :T1 a2 :T2 ...], :R]
            args_raw = sig[1]
            arg_types = args_raw[1::2]  # strip names, keep types
            rtype = sig[2]

            # e.g., f-args
            fn_args_sym = sx.Symbol(f"{dumps(fn)}-args")
            arg_sum_types.append(fn_args_sym)

            # e.g., (list 'f-args T1 ... Tn) with colons removed from types
            unrune_arg_types = [sx.Symbol(dumps(t)[1:]) for t in arg_types]
            defdatas.append([
                sx.Symbol("defdata"),
                fn_args_sym,
                [sx.Symbol("list"), sx.Quoted(fn_args_sym)] + unrune_arg_types
            ])

            # collect return type, unrune
            ret_types_init.add(sx.Symbol(dumps(rtype)[1:]))

        # top-level arg sum type
        if len(arg_sum_types) == 1:
            top_arg_pattern = arg_sum_types[0]
        else:
            top_arg_pattern = [sx.Symbol("oneof")] + arg_sum_types
        defdatas.append([
            sx.Symbol("defdata"),
            self._unrune_arg_type,
            top_arg_pattern
        ])
        
        ret_types = list(ret_types_init)
        # top-level return sum type
        if len(ret_types) == 1:
            top_ret_pattern = ret_types[0]
        else:
            top_ret_pattern = [sx.Symbol("oneof")] + ret_types
        defdatas.append([
            sx.Symbol("defdata"),
            sx.Symbol(self._pre_rtype),
            top_ret_pattern
        ])

        return defdatas

    def _definecs_prims(self):
        definecs = []
        new_primitives = []

        for fn in self.block:
            sig = self.sig_info[fn]         # [fn, [a1 :T1 a2 :T2 ...], :R]
            fn_sym = sig[0]
            argspec = sig[1]                # flat list: [a1, :T1, a2, :T2, ...]
            args = argspec[::2]             # [a1, a2, ...]
            # arg_types = argspec[1::2]     # not needed to build definec body

            fn_args_pre = f"{dumps(fn_sym)}-args"
            fn_args = sx.Symbol(fn_args_pre)
            qfn_args = sx.Quoted(fn_args)
            rune_rtype = sx.Symbol(f":{fn_args_pre}")

            # (list 'fn-args a1 a2 ...)
            defcbody = [sx.Symbol("list"), qfn_args] + args

            # (definec fn-args (a1 :T1 a2 :T2 ...) :fn-args (list 'fn-args a1 a2 ...))
            definec = [sx.Symbol("definec"), fn_args, argspec, rune_rtype, defcbody]

            new_primitives.append(fn_args)
            definecs.append(definec)

        return definecs, new_primitives

    def definecs(self):
        if self.__definecs is None:
            self.__definecs, self.__new_primitives = self._definecs_prims()
        return self.__definecs

    def new_primitives(self):
        if self.__new_primitives is None:
            self.__definecs, self.__new_primitives = self._definecs_prims()
        return self.__new_primitives
    
    def deflocals(self):
        deflocals = []
        sub_preds = []

        for fn in self.block:
            fn_name = dumps(fn)
            fn_args_pre = f"{fn_name}-args"
            fn_args = sx.Symbol(fn_args_pre)
            qfn_args = sx.Quoted(fn_args)

            pname = sx.Symbol(f"{fn_args_pre}p")
            parg = sx.Symbol("x")
            pbody = [
                sx.Symbol("and"), [sx.Symbol("consp"), parg],
                [sx.Symbol("equal"), [sx.Symbol("car"), parg], qfn_args]
            ]
            deflocal = [
                sx.Symbol("deflocal"), pname, [parg, sx.Symbol(":all")], sx.Symbol(":bool"),
                pbody
            ]
            deflocals.append(deflocal)
            sub_preds.append(pname)

        # Top predicate: (<pre>-argsp x) = OR of all sub preds
        top_pred = sx.Symbol(f"{dumps(self._unrune_arg_type)}p")
        top_parg = sx.Symbol("x")
        top_pbody = [sx.Symbol("or")] + [[p, top_parg] for p in sub_preds]
        top_deflocal = [
            sx.Symbol("deflocal"), top_pred, [top_parg, sx.Symbol(":all")], sx.Symbol(":bool"),
            top_pbody
        ]
        deflocals.append(top_deflocal)

        return deflocals

class SketchHandler:

    def __init__(self, sigss):
        self.sigss = []
        self.sig_info = dict()
        self._add_sigss(sigss)
        assert len(self.sig_info) > 0

        self.tgts = dict()
        self.tgt_sketches = dict()
        self.alt_sketches = dict()

        self.measures = []
        self.measure_arities = dict()
        self.prec_holes = []
        self.holes_to_fn = dict()

        self.__sketches = None
        self.__tgt_sketch_ids = dict() 
        self.__holes = dict()
        self.__mut_rec_enc = None

    def singleton(self):
        if self.is_single():
            return self.fns()[0]
        return None

    def is_single(self):
        return len(self.sig_info) == 1

    def mut_rec_enc(self):
        """Assumes there is just one block and that there are multiple functions.
        I.e., there is a single group of mutually recursive functions.
        """
        if self.__mut_rec_enc is None:
            assert not self.is_single()
            assert len(self.fn_blocks()) == 1, "TODO: mutual recursion + dependencies"
            assert len(self.measures) == 1, "TODO: multiple measures for mutual recursion"
            block = self.fn_blocks()[0]
            block_idx = 0
            measure = self.measures[0]
            measure_arity = self.measure_arities[measure[1]]

            mut_rec_enc = MutRecEncoding(
                block, self.tgt_sketches, self.alt_sketches,
                self.tgts,
                self.sig_info, 
                measure, measure_arity,
                self.holes(block_idx))

            self.__mut_rec_enc = mut_rec_enc
        return self.__mut_rec_enc

    def fns(self):
        res = []
        for block in self.fn_blocks():
            # print("block:", block)
            res.extend(block)
        return res

    def fn_blocks(self):
        res = []
        for sigs in self.sigss:
            block = []
            for sig in sigs:
                block.append(sig[0])
            res.append(block)
        return res

    ############################################################
    ### Fn accessors ###

    def fn_rtype(self, fn):
        """Return return type for the given function name.
        """
        assert fn in self.fns()
        return self.sig_info[fn][2]

    def fn_args(self, fn):
        """Return names of arguments for the given function name.
        """
        assert fn in self.fns()
        return self.sig_info[fn][1][::2]

    def fn_arg_types(self, fn):
        """Return types of arguments for the given function name.
        """
        assert fn in self.fns()
        return self.sig_info[fn][1][1::2]

    def fn_tgt(self, fn):
        """Return body of reference implementation for the given function name.
        Returns None if no target is defined.
        """
        assert fn in self.fns()

        if len(self.tgts.keys()) == 0:
            return None

        return self.tgts[fn]

    def fn_tgt_sketch(self, fn):
        """Return target sketch for the given function name.
        Returns None if no target sketch is defined.
        """
        assert fn in self.fns()

        if len(self.tgt_sketches.keys()) == 0:
            return None
        return self.tgt_sketches[fn]

    def fn_alt_sketches(self, fn):
        """Return alternative sketches for the given function name.
        """
        assert fn in self.fns()
        if fn in self.alt_sketches:
            return self.alt_sketches[fn]
        else:
            return []

    def get_measure(self, fn):
        if len(self.measures) == 0:
            raise ValueError("No measure defined")
        if len(self.measures) == 1:
            measure = self.measures[0]
            measure_arity = self.measure_arities[measure[1]]
            return measure, measure_arity
        res = None
        for measure in self.measures:
            if len(measure) != 6:
                pprint(measure)
                raise ValueError(
                    "If multiple measures, must specify fns per measure"
                    f" (got {measure}, length {len(measure)}")
            if fn in measure[5]:
                if res is not None:
                    raise NotImplementedError(
                        f"Multiple measures defined for function {fn}")
                measure_arity = self.measure_arities[measure[1]]
                res = (measure, measure_arity)
        if res is None:
            raise ValueError(f"No measure defined for function {fn}")
        return res


    ############################################################
    ### Compiled contents ###


    def _sketches_block(self, block_idx):
        block = self.fn_blocks()[block_idx]
        assert len(block) > 0
        if len(block) == 1:
            fn = block[0]
            return fn, self._sketches_fn(block_idx)


        assert len(self.fn_blocks()) == 1, "TODO: mutual recursion + dependencies"
        assert len(self.measures) > 0, "Need measure"
        assert len(self.measures) == 1, "TODO: multiple measures for mutual recursion"
        measure = self.measures[0]
        measure_arity = self.measure_arities[measure[1]]

        mut_rec_enc = self.mut_rec_enc()
        fn = mut_rec_enc.fn
        args = mut_rec_enc.fn_args
        arg_types = mut_rec_enc.fn_arg_types
        rtype = mut_rec_enc.fn_rtype
        bodies = mut_rec_enc.alt_sketches()

        sketches = []
        for sketch_body in bodies:
            sketch = Sketch(
                fn, args, arg_types, rtype,
                sketch_body, 
                measure[1], measure_arity,
                self.holes(block_idx))
            sketches.append(sketch) 
        if mut_rec_enc.tgt_sketch() is not None:
            tgt_sketch = mut_rec_enc.tgt_sketch()
            sketches.append(tgt_sketch)
            self.__tgt_sketch_ids[fn] = id(tgt_sketch)

        return fn, sketches


    def _sketches_fn(self, block_idx):
        sketches = []
        block = self.fn_blocks()[block_idx]
        assert len(block) == 1
        fn = block[0]
        measure, measure_arity = self.get_measure(fn)

        for sketch_body in self.fn_alt_sketches(fn):
            sketch = Sketch(
                fn, self.fn_args(fn), self.fn_arg_types(fn), self.fn_rtype(fn),
                sketch_body, 
                measure[1], measure_arity,
                self.holes(block_idx))
            sketches.append(sketch)
        if self.fn_tgt_sketch(fn) is not None:
            tgt_sketch = Sketch(
                fn, self.fn_args(fn), self.fn_arg_types(fn), self.fn_rtype(fn),
                self.fn_tgt_sketch(fn), # type:ignore
                measure[1], measure_arity,
                self.holes(block_idx))
            sketches.append(tgt_sketch)
            self.__tgt_sketch_ids[fn] = id(tgt_sketch)
        return sketches


    def sketches(self):
        if self.__sketches is None:
            self.__sketches = dict()
            for idx, block in enumerate(self.fn_blocks()):
                fn, sketches = self._sketches_block(idx)
                self.__sketches[fn] = sketches
        return self.__sketches

    def tgt_sketch_ids(self):
        self.sketches() # ensure sketches are compiled
        return self.__tgt_sketch_ids

    def fn_tgts(self):
        res = dict()
        for idx, block in enumerate(self.fn_blocks()):
            if len(block) == 1:
                fn = block[0]
                res[fn] = self.tgt_single(fn)
            else:
                mut_rec_enc = self.mut_rec_enc()
                fn = mut_rec_enc.fn
                res[fn] = mut_rec_enc.tgt()
        return res

        

    def tgt_single(self, fn):
        args = []
        for i in range(len(self.fn_args(fn))):
            args.append(self.fn_args(fn)[i])
            args.append(self.fn_arg_types(fn)[i])
        return [
            sx.Symbol("definec"), fn, args, self.fn_rtype(fn), self.fn_tgt(fn)]


    def holes_single(self, block_idx):
        block = self.fn_blocks()[block_idx]
        assert len(block) == 1
        in_fn = block[0]

        res = []
        for name, rtype, nts in self.prec_holes:
            fn = self.holes_to_fn[name]
            if fn is None:
                fn = self.singleton()
            assert fn is not None
            if fn != in_fn:
                continue

            args = self.fn_args(fn)
            arg_types = self.fn_arg_types(fn)
            res.append(Hole(name, rtype, nts, args, arg_types, fn))

        self.__holes[block_idx] = res

    def holes_multiple(self, block_idx):
        block = self.fn_blocks()[block_idx]
        assert len(block) > 1

        res = []
        for name, rtype, nts in self.prec_holes:
            fn = self.holes_to_fn[name]
            if fn not in block:
                continue
            args = self.fn_args(fn)
            arg_types = self.fn_arg_types(fn)
            hyp = [sx.Symbol("equal"), ARG, apply_constructor(fn, args)]
            hole = Hole(name, rtype, nts, args, arg_types, fn, additional_term_hyp=hyp)
            res.append(hole)
        self.__holes[block_idx] = res

    def holes(self, block_idx):
        if block_idx not in self.__holes:
            block = self.fn_blocks()[block_idx]
            assert len(block) > 0
            if len(block) == 1:
                self.holes_single(block_idx)
            else:
                self.holes_multiple(block_idx)
        return self.__holes[block_idx]

    def all_holes(self):
        res = []
        for idx in range(len(self.fn_blocks())):
            res.extend(self.holes(idx))
        return res

    def sub(self):
        if all(len(block) == 1 for block in self.fn_blocks()):
            return []
        return self.mut_rec_enc().sub()

    def defdatas(self):
        if all(len(block) == 1 for block in self.fn_blocks()):
            return []
        return self.mut_rec_enc().defdatas()

    def definecs(self):
        if all(len(block) == 1 for block in self.fn_blocks()):
            return []
        return self.mut_rec_enc().definecs()

    def deflocals(self):
        if all(len(block) == 1 for block in self.fn_blocks()):
            return []
        return self.mut_rec_enc().deflocals()

    def new_primitives(self):
        if all(len(block) == 1 for block in self.fn_blocks()):
            return []
        return self.mut_rec_enc().new_primitives()



    ############################################################
    ### Add information ###

    def add_measure(self, measure):
        self.measures.append(measure)
        assert len(measure[2]) % 2 == 0
        self.measure_arities[measure[1]] = len(measure[2]) // 2

    def add_prec_hole(self, name, rtype, nts, fn):
        if fn not in self.fns() and fn is not None:
            raise ValueError(f"Function {fn} not in {self.fns()}")

        self.prec_holes.append((name, rtype, nts))
        self.holes_to_fn[name] = fn



    def add_sketch(self, sketch):
        fn = self.singleton() 
        if fn is None:
            assert len(sketch) == 3
            fn = sketch[-1]
        else:
            assert len(sketch) == 2

        assert fn in self.fns()
        if fn not in self.alt_sketches:
            self.alt_sketches[fn] = []
        self.alt_sketches[fn].append(sketch[1])

    def add_tgt_sketch(self, tgt_sketch):
        fn = self.singleton()
        if fn is None:
            assert len(tgt_sketch) == 3 
            fn = tgt_sketch[-1]
        else:
            assert len(tgt_sketch) == 2

        assert fn in self.fns()
        assert fn not in self.tgt_sketches
        self.tgt_sketches[fn] = tgt_sketch[1]

    def add_tgt(self, tgt):
        assert len(tgt) == 5

        fn = tgt[1]
        assert fn in self.fns()

        assert fn not in self.tgts
        if tgt[2][::2] != self.fn_args(fn):
            exp = self.fn_args(fn)
            got = tgt[2][::2]
            raise ValueError(f"Expected args {exp} for {fn}, got {got}")
        assert tgt[2][1::2] == self.fn_arg_types(fn)
        assert tgt[3] == self.fn_rtype(fn), "Type mismatch. Check that all tgts have sigs and that the sig return type matches the tgt return type."
        self.tgts[fn] = tgt[-1]

    def _add_sig(self, sig):
        assert len(sig) == 4
        name = sig[1]
        self.sig_info[name] = sig[1:]
        self.sigss.append([sig[1:]])

    def _add_sigs(self, sigs):
        assert len(sigs) == 2
        for sig in sigs[1]:
            name = sig[0]
            self.sig_info[name] = sig
        self.sigss.append(sigs[1])

    def _add_sigss(self, sigss):
        for s in sigss:
            if s[0] == sx.Symbol("defsig"):
                self._add_sig(s)
            elif s[0] == sx.Symbol("defsigs"):
                self._add_sigs(s)
            else:
                raise ValueError(f"Unknown declaration: {s[0]}")


