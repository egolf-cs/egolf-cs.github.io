from Structs import UserSpace, Interpretation, Expression
from VerifierAux import Cex, ContractCex
from Candidate import Candidate
import sexpdata as sx

from .ExprAdmit import ExprAdmit
from local_eval import local_eval, ContractViolation


class ContractCache:
    """Cache for contract checking at the expression (hole) level.

    This cache mirrors the interpretation-based contract cache in Verifier.
    It stores interpretations witnessing contract violations for this sketch
    and replays them against new hole expressions using local_eval.
    """

    def __init__(self, user_space : UserSpace):
        self.user_space = user_space
        self.interp_cache : dict[sx.Symbol | None, list[Interpretation]] = {}
        self.interp_cache_fast : dict[sx.Symbol | None, set[Interpretation]] = {}

    def add_interpretation(
            self,
            hole_fn : sx.Symbol | None,
            interp : Interpretation) -> None:
        """Add an interpretation that witnesses a contract violation.

        Interpretations are stored per hole function, mirroring Verifier.
        """
        if hole_fn is None:
            return
        if hole_fn not in self.interp_cache:
            self.interp_cache[hole_fn] = []
            self.interp_cache_fast[hole_fn] = set()
        if interp in self.interp_cache_fast[hole_fn]:
            return
        self.interp_cache_fast[hole_fn].add(interp)
        self.interp_cache[hole_fn].append(interp)

    def check_interps(
            self,
            candidate : Candidate,
            hole_name) -> ContractCex | None:
        """Check cached interpretations for a contract violation of expr.

        hole_name is the hole being admitted, expr is its body, and
        expr_admits contains prior admits for holes this hole depends on.
        Returns a ContractCex if any cached interpretation still witnesses
        a violation for expr; otherwise returns None.
        """
        if len(self.interp_cache) == 0:
            return None

        hole_fn = candidate.hole_function(hole_name)
        if hole_fn is None:
            return None
        if hole_fn not in self.interp_cache:
            return None

        ic, _ = candidate.no_hole_ic(hole_name)
        expr_current = candidate.hole_expression(hole_name)

        sketch_ids = candidate.sketch_ids()
        for interp in self.interp_cache[hole_fn]:
            assoc : Expression = [[k, v] for k, v in interp.assoc.items()]
            cmd = [sx.Symbol("if"), ic, expr_current, True]
            cmd = [sx.Symbol("let"), assoc, cmd]
            out = local_eval(cmd, user_space=self.user_space)
            if isinstance(out, ContractViolation):
                return ContractCex(
                    interp, [], sketch_ids, hole_name, expr_current)

        return None
