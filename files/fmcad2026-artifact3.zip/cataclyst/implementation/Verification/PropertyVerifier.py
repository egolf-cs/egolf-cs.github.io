import sexpdata as sx
from VerifierAux import Cex, Session, PropertyCex, parse_output, CEX_FOUND
from Structs import (
    Property,
    Trace,
    Expression,
    Interpretation,
    UserSpace,
    sx_filter,
)
from Candidate import Candidate
import local_eval as leval
from local_eval import local_eval

from .PropertyCache import PropertyCache
from .FnAdmits import FnAdmits
from Sketch import Sketch


class PropertyVerifier:
    """Checks one property against admitted functions; uses cache then session.
    Candidate is passed only for trace and interpretation building.
    """

    def __init__(self,
            property : Property,
            session : Session,
            cache : PropertyCache,
            user_space : UserSpace):
        self.property = property
        self.session = session
        self.cache = cache
        self.user_space = user_space

    def cache_test(self, candidate : Candidate) -> None|Cex:
        out = self.cache.check_interps(candidate)
        if out is not None:
            print("PROPERTY INTERP CACHE HIT")
            return out
        return None

    def verify(self, admits : FnAdmits, candidate : Candidate) -> None | Cex:
        if self.cache.is_valid(admits):
            return None
        out = self.cache.check_neg(admits)
        if out is not None:
            return out

        query = self.construct_query(admits)
        output = self.session.send(query)
        sketch_ids = candidate.sketch_ids()
        if CEX_FOUND in output:
            interp, forms = parse_output(output)
            trace, _ = self.mk_trace(candidate, interp)

            witness = interp
            interpretations = self.mk_prop_interpretations(candidate, witness)
            cex = PropertyCex(
                witness, forms, sketch_ids, trace, interpretations)
            self.cache.add_interp(witness, measure=None)
            self.cache.add_neg(admits, cex)
            return cex

        self.cache.add_valid(admits)
        return None

    def minimize_cex(
            self,
            candidate : Candidate,
            trace : Trace,
            interp : Interpretation) -> tuple[
                list[tuple[Interpretation, int]],
                Interpretation,
                int | None,
            ]:
        """If the property has one sketch and one call, pair alts with measures.

        Output: sorted ``(interp, measure)`` list, chosen minimal witness
        ``interp``, and its measure (or ``None`` when minimization is skipped).
        """
        sketches = candidate.sketches
        if len(sketches) != 1:
            return [], interp, None
        sk = sketches[0]
        calls = self.top_calls(sk)
        if len(calls) != 1:
            return [], interp, None
        call = calls[0]
        arg_exprs = call[1:]
        for a in arg_exprs:
            if not isinstance(a, sx.Symbol):
                return [], interp, None
        if set(str(a) for a in arg_exprs) != set(
                str(k) for k in interp.assoc.keys()):
            return [], interp, None
        if set(str(a) for a in arg_exprs) != set(
                str(t) for t in sk.top_args):
            return [], interp, None
        trace_calls = [
            x for x in trace.extended
            if isinstance(x, list) and len(x) > 0 and x[0] == sk.name]
        alt_interps : list[Interpretation] = []
        alt_interps_fast : set[tuple] = set()
        for c in trace_calls:
            if len(c) != len(arg_exprs) + 1:
                raise ValueError(
                    f"trace call arity mismatch: {c!r} vs formals {arg_exprs!r}")
            assoc : dict[sx.Symbol, Expression] = {}
            for formal, val in zip(arg_exprs, c[1:]):
                if isinstance(val, list):
                    val = sx.Quoted(val)
                assoc[formal] = val
            key_t = tuple(str(assoc[f]) for f in arg_exprs)
            if key_t in alt_interps_fast:
                continue
            alt_interps_fast.add(key_t)
            alt_interps.append(Interpretation(assoc))
        if len(alt_interps) == 0:
            return [], interp, None
        measures = [ 
            (k,self.apply_measure(sk, candidate, k)) for k in alt_interps]
        measures = [x for x in measures if x[1] is not None]
        measures = sorted(measures, key=lambda x: x[1]) # type:ignore
        min_interp = interp
        min_measure = self.apply_measure(sk, candidate, interp)
        for alt in measures:
            alt_interp = alt[0]
            prop_assoc : Expression = [
                [k, v] for k, v in alt_interp.assoc.items()]
            pe = self.property.eval_inner
            assert isinstance(pe, list)
            prop_cmd : Expression = [sx.Symbol("let"), prop_assoc, pe]
            self.user_space.push(candidate.user_functions())
            try:
                prop_out = local_eval(
                    prop_cmd, user_space=self.user_space)
            finally:
                self.user_space.pop()
            if isinstance(prop_out, leval.ContractViolation):
                continue
            if not leval.is_nil(prop_out):
                continue
            if alt[1] < min_measure:
                min_interp = alt_interp
                min_measure = alt[1]
                break
        return measures, min_interp, min_measure

    def apply_measure(
            self,
            sketch : Sketch,
            candidate : Candidate,
            interp : Interpretation) -> int | None:
        """Evaluate the sketch's ``defmeasure`` under ``interp`` for ordering.

        Inputs: ``sketch`` supplies ``measure`` and ``top_args``; ``interp``
        binds those formals; ``candidate`` supplies bodies for ``user_space``.
        Output: the measure as an ``int`` (smaller is better for ``min()``).
        """
        if len(sketch.top_args) != sketch.measure_arity:
            raise ValueError(
                f"Sketch {sketch.name}: top_args vs measure_arity mismatch.",
            )
        assoc : Expression = [
            [k, interp.assoc[k]]
            for k in sketch.top_args
        ]
        body : Expression = [sketch.measure] + list(sketch.top_args)
        cmd : Expression = [sx.Symbol("let"), assoc, body]
        self.user_space.push(candidate.user_functions())
        try:
            out = local_eval(cmd, user_space=self.user_space)
        finally:
            self.user_space.pop()
        if isinstance(out, leval.ContractViolation):
            return None
        if not isinstance(out, int):
            return None
        return out

    def mk_trace(
            self,
            candidate : Candidate,
            interp : Interpretation) -> tuple[Trace, object]:
        """Build trace by evaluating the property under interp with candidate's
        definitions pushed. Uses same push/pop logic as Verifier.mk_trace.
        """
        assoc : Expression = [[k, v] for k, v in interp.assoc.items()]
        sexpr = self.property.eval_inner
        assert isinstance(sexpr, list)
        cmd = [sx.Symbol("let"), assoc, sexpr]
        out = RecursionError()
        self.user_space.push(candidate.user_functions())
        try:
            out = local_eval(cmd, user_space=self.user_space)
        except RecursionError:
            print(
                "WARNING: RecursionError during property trace creation.")
        extended_trace = [x for x in self.user_space._extended_trace]
        trace = Trace("\n".join(sorted(self.user_space._trace)), extended_trace)
        self.user_space.pop()
        if isinstance(out, RecursionError):
            return Trace("", []), None
        return trace, out

    def top_calls(self, sk) -> list:
        """Calls in the property cmd whose head is the given sketch's name.
        """
        return sx_filter(
            self.property.eval_inner,
            lambda x: (
                isinstance(x, list)
                and len(x) > 0
                and x[0] == sk.name))

    def mk_prop_interpretations(
            self,
            candidate : Candidate,
            interp : Interpretation) -> list[Interpretation]:
        """Build per-sketch interpretations from the top-level interp and trace.
        Uses same push/pop logic as Verifier.mk_prop_interpretations.
        """
        top_calls = []
        for sk in candidate.sketches:
            calls = self.top_calls(sk)
            top_calls.extend([(sk, call) for call in calls])
        if len(top_calls) == 0:
            return []
        interps = []
        og_assoc = [[k, v] for k, v in interp.assoc.items()]
        self.user_space.push(candidate.user_functions())
        for sk, call in top_calls:
            vals = call[1:]
            vals = [[sx.Symbol("let"), og_assoc, x] for x in vals]
            vals = [local_eval(x, user_space=self.user_space) for x in vals]
            assoc = dict()
            if len(vals) != len(sk.top_args):
                self.user_space.pop()
                raise ValueError(
                    f"top_calls arity mismatch for {sk.name}: "
                    f"vals len {len(vals)} vs top_args len {len(sk.top_args)}")
            for k, v in zip(sk.top_args, vals):
                if isinstance(v, list):
                    v = sx.Quoted(v)
                if isinstance(v, leval.ContractViolation):
                    self.user_space.pop()
                    raise ValueError(
                        "Contract violation in property interpretation.")
                assoc[k] = v
            interps.append(Interpretation(assoc))
        self.user_space.pop()
        return interps

    def construct_query(self, admits : FnAdmits) -> str:
        """Build the property test command with top-level names replaced by aliases.
        """
        sub = {admit.top_name : admit.top_alias_name for admit in admits._admits}
        return self.property.mk_cmd_str(sub)
