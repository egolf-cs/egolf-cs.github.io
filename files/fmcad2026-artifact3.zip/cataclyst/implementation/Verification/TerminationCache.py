from Sketch import Sketch, sx_substitute_holes
from Structs import UserSpace, Interpretation, Expression
from VerifierAux import Cex, TerminationCex
from Candidate import Candidate
import sexpdata as sx

from .FnAdmits import FnAdmit
from local_eval import local_eval, is_nil


class TerminationCache:

    def __init__(self, user_space : UserSpace):
        self.user_space = user_space

        self.interp_cache : dict[sx.Symbol, list[Interpretation]] = {}
        self.interp_cache_fast : dict[sx.Symbol, set[Interpretation]] = {}

    def add_interpretation(
            self,
            tgt_function : sx.Symbol | None,
            interp : Interpretation) -> None:
        """Remember an interpretation that witnesses a termination violation.

        Interpretations are recorded per target function, mirroring Verifier.
        """
        if tgt_function is None:
            return
        if tgt_function not in self.interp_cache:
            self.interp_cache[tgt_function] = []
            self.interp_cache_fast[tgt_function] = set()
        if interp in self.interp_cache_fast[tgt_function]:
            return
        self.interp_cache_fast[tgt_function].add(interp)
        self.interp_cache[tgt_function].append(interp)

    def check_interps(self, candidate : Candidate) -> None|Cex:
        """Replay cached interpretations against this admitted function.

        For each cached interpretation and each termination property on this
        sketch, evaluate the property under the interpretation using local_eval.
        If any property evaluates to nil, return a TerminationCex; otherwise
        return None.
        """
        if len(self.interp_cache) == 0:
            return None

        sub = candidate.mk_sub()
        sketch_ids = candidate.sketch_ids()

        for prop in candidate.termination_properties():
            sexpr : Expression = prop.cmd
            assert isinstance(sexpr, list)
            assert len(sexpr) > 0
            assert sexpr[0] == sx.Symbol("test?")
            sexpr = sexpr[1]
            assert isinstance(sexpr, list)
            assert len(sexpr) > 0
            assert sexpr[0] == sx.Symbol("implies")
            guard = sexpr[1]
            body = sexpr[2]

            fn = prop.tgt_function
            if fn is None:
                continue
            if fn not in self.interp_cache:
                continue
            for interp in self.interp_cache[fn]:
                assoc : Expression = [[k, v] for k, v in interp.assoc.items()]
                cmd = [sx.Symbol("if"), guard, body, True]
                cmd = [sx.Symbol("let"), assoc, cmd]
                cmd = sx_substitute_holes(cmd, sub)
                out = local_eval(cmd, user_space=self.user_space)
                if is_nil(out):
                    return TerminationCex(
                        interp, [], sketch_ids, prop.hole_names)

        return None
