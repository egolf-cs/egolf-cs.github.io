import sexpdata as sx
from Sketch import Sketch
from Structs import dumps, sx_substitute_applications
from VerifierAux import (
    Cex,
    Session,
    ACL2Error,
    TerminationCex,
    parse_output,
    CEX_FOUND,
    ACL2_ERROR,
    TIME_LIMIT_ERROR,
)
from Candidate import Candidate

from .FnAdmits import FnAdmit, FnAdmits
from .ExprAdmitter import ExprAdmitter
from .TerminationCache import TerminationCache
from .ExprAdmit import ExprAdmit


class FnAdmitter:
    """Admits one top-level function (sketch): hole contracts, then termination,
    then top-level definec.
    """

    def __init__(
            self,
            sketch : Sketch,
            expr_admitters : list[ExprAdmitter],
            termination_cache : TerminationCache,
            session : Session):
        # Note: the order of expr_admitters is critical, since some holes
        # depend on prior holes for input contract information
        self.sketch = sketch
        self.expr_admitters = expr_admitters
        self.termination_cache = termination_cache
        self.session = session
        self.admitted : set[FnAdmit] = set()
        self.rejected : dict[FnAdmit, Cex] = dict()
        self._top_label_ctr = 0

    def cache_test(self, candidate : Candidate) -> None|Cex:
        for admitter in self.expr_admitters:
            out = admitter.cache_test(candidate)
            if isinstance(out, Cex):
                return out
        out = self.termination_cache.check_interps(candidate)
        if out is not None:
            print("TERMINATION CACHE HIT")
            return out
        return None

    def admit(self, candidate : Candidate, admits : FnAdmits) -> FnAdmit | Cex:
        print("Admitting function", self.sketch.name)
        expr_admits = []
        for admitter in self.expr_admitters:
            hname = admitter.hole_name
            expr = candidate.hole_expression(hname)
            out = admitter.admit(candidate, expr, tuple(expr_admits))
            if isinstance(out, Cex):
                return out
            expr_admits.append(out)
        admit = self.make_admit(expr_admits)
        if admit in self.admitted:
            return admit
        return self.admit_top(admit, candidate, admits)

    def admit_top(
            self,
            admit : FnAdmit,
            candidate : Candidate,
            admits : FnAdmits) -> FnAdmit | Cex:

        term_queries = self.construct_termination_query(admit, admits)
        sketch_ids = candidate.sketch_ids()
        for i, cmd in enumerate(term_queries):
            output = self.session.send(cmd)
            if CEX_FOUND in output:
                interp, forms = parse_output(output)
                prop = self.sketch.termination_properties[i]
                self.termination_cache.add_interpretation(prop.tgt_function, interp)
                res = TerminationCex(
                    interp, forms, sketch_ids, prop.hole_names)
                self.rejected[admit] = res
                return res

        admission_query = self.construct_admission_query(admit, admits)
        out = self.session.send(admission_query)
        if ACL2_ERROR in out and TIME_LIMIT_ERROR not in out:
            print(out)
            print("===== FULL ERROR ABOVE =====\n\n\n\n\n")
            raise ValueError(
                "ACL2S error during top-level definec. This _may_ indicate a"
                " function contract violation. E.g., calling (tail (f x))"
                " without checking that (f x) is non-empty.")
        if CEX_FOUND in out:
            raise ACL2Error(
                "Contract violation found during top-level definec."
                " This suggests a malformed user input.")

        self.admitted.add(admit)

        return admit

    def make_admit(self, expr_admits : list[ExprAdmit]) -> FnAdmit:
        """Build FnAdmit with a fresh top-level alias for this sketch.
        """
        self._top_label_ctr += 1
        top_alias = sx.Symbol(
            f"{dumps(self.sketch.name)}_{self._top_label_ctr}_{id(self.sketch)}")
        return FnAdmit(
            id(self.sketch), self.sketch.name, top_alias, tuple(expr_admits))

    def construct_termination_query(
            self,
            admit : FnAdmit,
            admits : FnAdmits) -> list[str]:
        """One command string per termination property for this sketch.
        """
        sub = {self.sketch.name : admit.top_alias_name}
        for ea in admit.expr_admits:
            sub[ea.hole_name] = ea.alias_name
        for other in admits._admits:
            sub[other.top_name] = other.top_alias_name
        return [
            prop.mk_cmd_str(sub)
            for prop in self.sketch.termination_properties]

    def construct_admission_query(
            self,
            admit : FnAdmit,
            admits : FnAdmits) -> str:
        """Single definec string for the top-level function under its alias.
        """
        sub = {self.sketch.name : admit.top_alias_name}
        for ea in admit.expr_admits:
            sub[ea.hole_name] = ea.alias_name
        for other in admits._admits:
            sub[other.top_name] = other.top_alias_name
        definec = self.sketch.definec()
        sub_lst = list(sub.items())
        definec = sx_substitute_applications(definec, sub_lst)
        definec = [definec[0], admit.top_alias_name] + definec[2:]
        return dumps(definec)
        
