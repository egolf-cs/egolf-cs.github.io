


import sexpdata as sx


class ExprAdmit:

    def __init__(
            self,
            sketch_id: int,
            hole_name: sx.Symbol,
            alias_name: sx.Symbol):
        self.sketch_id = sketch_id
        self.hole_name = hole_name
        self.alias_name = alias_name
