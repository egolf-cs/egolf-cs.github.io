from pprint import pprint
import sexpdata as sx

from Candidate import Candidate
from Sketch import sx_substitute_holes
from Structs import Expression
from VerifierAux import Cex

from .FnAdmits import FnAdmits
from .FnAdmitter import FnAdmitter
from .PropertyVerifier import PropertyVerifier
from .SmtPropertyVerifier import SmtPropertyVerifier


class ProgramVerifier:

    def __init__(
            self,
            fn_admitters : dict[int, FnAdmitter],
            property_verifiers : list[PropertyVerifier],
            smt_property_verifiers : list[SmtPropertyVerifier]):
        self.fn_admitters = fn_admitters
        self.property_verifiers = property_verifiers
        self.smt_property_verifiers = smt_property_verifiers

    def verify(self, candidate : Candidate) -> None|Cex:
        out = self.cache_test(candidate)
        if isinstance(out, Cex):
            return out
        out = self.admit(candidate)
        if isinstance(out, Cex):
            return out
        assert isinstance(out, FnAdmits)
        out = self.verify_properties(out, candidate)
        if out is not None:
            return out
        out = self.verify_smt_properties(candidate)
        if out is not None:
            return out
        return None

    def cache_test(self, candidate : Candidate) -> None|Cex:
        for admitter in self.get_admitters(candidate):
            out = admitter.cache_test(candidate)
            if isinstance(out, Cex):
                return out
        for pver in self.property_verifiers:
            out = pver.cache_test(candidate)
            if isinstance(out, Cex):
                return out
        for pver in self.smt_property_verifiers:
            out = pver.cache_test(candidate)
            if isinstance(out, Cex):
                return out
        return None

    def admit(self, candidate : Candidate) -> FnAdmits|Cex:
        admits = FnAdmits()
        admitters = self.get_admitters(candidate)
        for admitter in admitters:
            out = admitter.admit(candidate, admits)
            if isinstance(out, Cex):
                return out
            admits.add(out)
        return admits

    def verify_properties(self, admits : FnAdmits, candidate : Candidate) -> None | Cex:
        for pver in self.property_verifiers:
            out = pver.verify(admits, candidate)
            if out is not None:
                return out
        return None

    def get_admitters(self, candidate : Candidate) -> list[FnAdmitter]:
        return [self.fn_admitters[sid] for sid in candidate.sketch_ids()]

    def verify_smt_properties(self, candidate : Candidate) -> None | Cex:
        fn_bodies = self._mk_fn_bodies(candidate)
        for pver in self.smt_property_verifiers:
            out = pver.verify(fn_bodies, candidate)
            if out is not None:
                return out
        return None

    def _mk_fn_bodies(
            self,
            candidate : Candidate) -> dict[sx.Symbol, Expression]:

        # Note: this makes the assumption that whenever [] or False appears in 
        # the completion of a hole of type int-list, it should be replaced in
        # the body by nil-list.
        sub = candidate.mk_sub_nil_list()
        fn_bodies : dict[sx.Symbol, Expression] = {}
        for sketch in candidate.sketches:
            body = sx_substitute_holes(sketch._body(), sub)
            fn_bodies[sketch.name] = body
        return fn_bodies
