import sexpdata as sx
from Structs import dumps

from .ExprAdmit import ExprAdmit


class FnAdmit:
    """Identifies one admitted top-level function (sketch) and its hole aliases.
    """

    def __init__(
            self,
            sketch_id : int,
            top_name : sx.Symbol,
            top_alias_name : sx.Symbol,
            expr_admits : tuple[ExprAdmit, ...]):
        self.sketch_id = sketch_id
        self.top_name = top_name
        self.top_alias_name = top_alias_name
        self.expr_admits = expr_admits

    def _key(self) -> tuple:
        return (
            self.sketch_id,
            dumps(self.top_name),
            dumps(self.top_alias_name),
            tuple(
                (ea.sketch_id, dumps(ea.hole_name), dumps(ea.alias_name))
                for ea in self.expr_admits))

    def __eq__(self, other) -> bool:
        if not isinstance(other, FnAdmit):
            return False
        return self._key() == other._key()

    def __hash__(self) -> int:
        return hash(self._key())


class FnAdmits:
    """Collection of FnAdmit, one per admitted sketch in a candidate.
    """

    def __init__(self):
        self._admits : list[FnAdmit] = []

    def add(self, admit : FnAdmit) -> None:
        self._admits.append(admit)

    def key(self, fn_names=None) -> tuple:
        """Canonical key for this set of admits.

        If fn_names is provided, only includes admits whose top_name is in
        fn_names; otherwise includes all admits.
        """
        if fn_names is None:
            return tuple(admit._key() for admit in self._admits)
        fn_name_set = set(fn_names)
        return tuple(
            admit._key()
            for admit in self._admits
            if admit.top_name in fn_name_set)
