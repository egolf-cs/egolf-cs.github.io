from itertools import chain

import sexpdata as sx
from Sketch import Sketch, DEFINEC, sx_substitute_holes
from Structs import dumps
from VerifierAux import (
    Cex,
    Session,
    ContractCex,
    parse_output,
    force_tests,
    CEX_FOUND,
    ACL2_ERROR,
    TIME_LIMIT_ERROR,
)
from .ExprAdmit import ExprAdmit
from .ContractCache import ContractCache


class ExprAdmitter:
    """Admits one hole's expression to the session; uses cache then ACL2.
    """

    def __init__(
            self,
            hole_name : sx.Symbol,
            sketch : Sketch,
            session : Session,
            contract_cache : ContractCache):
        self.hole_name = hole_name
        self.sketch = sketch
        self.session = session
        self.contract_cache = contract_cache
        self.admitted : dict[tuple, ExprAdmit] = dict()
        self.rejected : dict[tuple, Cex] = dict()
        self._label_ctr = 0

    def _admit_key(self, expr, expr_admits : tuple[ExprAdmit]) -> tuple:
        """Hashable key for memo: same expr and same prior admits -> same key.
        """
        deps = set(self.sketch.input_contract_deps(self.hole_name))
        return (
            dumps(expr),
            tuple(
                (ea.sketch_id, dumps(ea.hole_name), dumps(ea.alias_name))
                for ea in expr_admits
                if ea.hole_name in deps))

    def cache_test(
            self,
            candidate) -> Cex | None:
        """Check cache for this admit; return ExprAdmit or Cex if found, else None.
        """
        out = self.contract_cache.check_interps(
            candidate,
            self.hole_name,
        )
        if out is not None:
            print("CONTRACT CACHE HIT")
            return out
        return None

    def admit(
            self,
            candidate,
            expr,
            expr_admits : tuple[ExprAdmit]) -> ExprAdmit | Cex:
        """Admit expr for this hole; return ExprAdmit on success, Cex on failure.
        """
        key = self._admit_key(expr, expr_admits)
        if key in self.admitted:
            return self.admitted[key]
        if key in self.rejected:
            return self.rejected[key]

        definec, alias_name = self.make_definec(expr, expr_admits)
        cmd = dumps(definec)
        output = self.session.send(cmd)
        if ACL2_ERROR in output and TIME_LIMIT_ERROR not in output:
            definec = force_tests(definec)
            cmd = dumps(definec)
            output = self.session.send(cmd)

        if ACL2_ERROR in output and TIME_LIMIT_ERROR not in output:
            print("ADMIT OUTPUT:", output)
            raise RuntimeError("ACL2 error during admit")

        sketch_ids = candidate.sketch_ids()
        if CEX_FOUND in output:
            interp, forms = parse_output(output)
            res = ContractCex(
                interp, forms, sketch_ids, self.hole_name, expr)
            hole_fn = self.sketch.hole_function(self.hole_name)
            self.contract_cache.add_interpretation(hole_fn, interp)
            self.rejected[key] = res
            return res

        admit = ExprAdmit(id(self.sketch), self.hole_name, alias_name)
        self.admitted[key] = admit

        return admit

    def make_definec(self, expr, expr_admits : tuple[ExprAdmit]):

        hlabels = {ea.hole_name : ea.alias_name for ea in expr_admits}
        self._label_ctr += 1
        alias_name = sx.Symbol(
            f"{dumps(self.hole_name)}_{self._label_ctr}_{id(self.sketch)}")
        hlabels[self.hole_name] = alias_name

        args = self.sketch.hole_args(self.hole_name)
        ic = self.sketch.input_contract(self.hole_name)
        ic = sx_substitute_holes(
            ic, [(k, [v, *args]) for k, v in hlabels.items()])
        argtypes = self.sketch.hole_arg_types(self.hole_name)
        argzs = list(chain(*zip(args, argtypes)))
        ignorable = [
            sx.Symbol("declare"), [sx.Symbol("ignorable"), *args]]
        htype = self.sketch.hole_type(self.hole_name)
        definec = [
            DEFINEC, alias_name, argzs, htype,
            ignorable, sx.Symbol(":ic"), ic,
            expr]

        return definec, alias_name
