import bisect

from VerifierAux import Cex, PropertyCex
from Structs import Interpretation, UserSpace
from Structs import Property, Expression, Trace
from Structs import sx_filter
from Candidate import Candidate
import sexpdata as sx
import local_eval as leval
from local_eval import local_eval, is_nil

from .FnAdmits import FnAdmits

class PropertyCache:

    def __init__(
            self,
            property : Property,
            user_space : UserSpace,
            fn_names):
        # pos_cache contains FnAdmits that are known to be correct
        # "Modulo out" the input admit wrt the functions in the property
        # Check if modded out admit is in pos_cache, if so, return None

        # Likewise for neg_cache, but has bad admits and corresponding
        # counterexamples

        # Finally, interp_cache lists interpretations that have caused
        # counterexamples, sorted by increasing measure when add_interp was
        # given a measure (unmeasured appends are after all measured ones).
        # Substitute admits into the property and replay each interp to see if
        # the property is still violated.

        self.pos_cache : set[tuple] = set()
        self.neg_cache : dict[tuple, Cex] = dict()
        self.interp_cache : list[Interpretation] = []
        self._interp_measures : list[int | None] = []
        self.interp_cache_fast : set[Interpretation] = set()
        self.property = property
        self.user_space = user_space
        self.fn_names = property.filter_fn_names(fn_names)

    def is_valid(self, admits : FnAdmits) -> bool:
        key = admits.key(self.fn_names)
        return key in self.pos_cache

    def add_valid(self, admits : FnAdmits) -> None:
        """Record a set of admits as known to satisfy this property."""
        if self.is_valid(admits):
            return
        key = admits.key(self.fn_names)
        self.pos_cache.add(key)

    def check_neg(self, admits : FnAdmits) -> None|Cex:
        """Return cached counterexample if this admits set is known to fail."""
        key = admits.key(self.fn_names)
        if key in self.neg_cache:
            return self.neg_cache[key]
        return None

    def add_neg(self, admits : FnAdmits, cex : Cex) -> None:
        """Record that this admits set violates the property with cex."""
        key = admits.key(self.fn_names)
        if key in self.neg_cache:
            return
        self.neg_cache[key] = cex

    def add_interp(self, interp : Interpretation, measure : int | None = None) -> None:
        """Remember an interpretation that witnessed a property violation.

        ``interp_cache`` stays sorted by increasing ``measure`` when ``measure``
        is provided; entries added with ``measure`` omitted are appended after
        all measured entries (and keep insertion order among themselves).
        """
        if interp in self.interp_cache_fast:
            return
        self.interp_cache_fast.add(interp)
        self.interp_cache.append(interp)
        

    def check_interps(
            self,
            candidate : Candidate) -> None|Cex:
        """Replay cached interpretations to try to refute the property.

        Mirrors Verifier.verify_properties_cache: evaluates the property under
        each cached interpretation and the candidate's definitions using
        local_eval. Returns a PropertyCex on cache hit, or None otherwise.
        """
        if len(self.interp_cache) == 0:
            return None

        sketch_ids = candidate.sketch_ids()
        for interp in self.interp_cache:
            trace, out = self._mk_trace(candidate, interp)
            if out is None:
                return None

            if isinstance(out, leval.ContractViolation):
                print(
                    "WARNING: Contract violation during property cache"
                    " check. Expect a contract violation soon.")
                return None

            if is_nil(out):
                interpretations = self._mk_prop_interpretations(
                    candidate, interp)
                return PropertyCex(
                    interp, [],
                    sketch_ids,
                    trace,
                    interpretations,
                )

        return None

    def _mk_trace(
            self,
            candidate : Candidate,
            interp : Interpretation) -> tuple[Trace, object]:
        """Evaluate the property under interp and build a call trace."""
        assoc : Expression = [[k, v] for k, v in interp.assoc.items()]
        sexpr = self.property.eval_inner
        assert isinstance(sexpr, list)
        cmd = [sx.Symbol("let"), assoc, sexpr]
        out = RecursionError()
        self.user_space.push(candidate.user_functions())
        try:
            out = local_eval(cmd, user_space=self.user_space)
        except RecursionError:
            print(
                "WARNING: RecursionError during property cache check"
                " or trace creation.")
        trace = Trace("\n".join(sorted(self.user_space._trace)), self.user_space._extended_trace)
        self.user_space.pop()
        if isinstance(out, RecursionError):
            return Trace("", []), None
        return trace, out

    def _top_calls(self, sk) -> list:
        """Calls in the property cmd whose head is the given sketch's name."""
        return sx_filter(
            self.property.eval_inner,
            lambda x: (
                isinstance(x, list)
                and len(x) > 0
                and x[0] == sk.name))

    def _mk_prop_interpretations(
            self,
            candidate : Candidate,
            interp : Interpretation) -> list[Interpretation]:
        """Build per-sketch interpretations from the top-level interp."""
        top_calls = []
        for sk in candidate.sketches:
            calls = self._top_calls(sk)
            top_calls.extend([(sk, call) for call in calls])
        if len(top_calls) == 0:
            return []
        interps = []
        og_assoc = [[k, v] for k, v in interp.assoc.items()]
        self.user_space.push(candidate.user_functions())
        for sk, call in top_calls:
            vals = call[1:]
            vals = [[sx.Symbol("let"), og_assoc, x] for x in vals]
            vals = [local_eval(x, user_space=self.user_space) for x in vals]
            assoc = dict()
            if len(vals) != len(sk.top_args):
                self.user_space.pop()
                raise ValueError(
                    f"top_calls arity mismatch for {sk.name}: "
                    f"vals len {len(vals)} vs top_args len {len(sk.top_args)}")
            for k, v in zip(sk.top_args, vals):
                if isinstance(v, list):
                    v = sx.Quoted(v)
                if isinstance(v, leval.ContractViolation):
                    self.user_space.pop()
                    raise ValueError(
                        "Contract violation in property interpretation.")
                assoc[k] = v
            interps.append(Interpretation(assoc))
        self.user_space.pop()
        return interps

