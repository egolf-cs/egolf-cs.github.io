"""Boilerplate SMT property verifier placeholder.

This module defines the public surface for SMT-backed property checking.
Implementation is intentionally deferred.

Note: rendering to smtlib is currently very brittle. A particular concern
is that acl2s uses nil for both the empty list and false, but smtlib will
treat these as distinct.
"""

from pprint import pprint
import sexpdata as sx
import z3

from Candidate import Candidate
from Structs import Expression, UserSpace, Interpretation, Trace, dumps
from VerifierAux import Cex, NoOpCex, PropertyCex
import local_eval as leval
from local_eval import local_eval

class SmtPropertyVerifier:
    """Placeholder verifier for one SMT property directive."""

    def __init__(self, smt_path : str, user_space : UserSpace):
        """Initialize from an SMT script path and user-space environment.

        The implementation is intentionally deferred.
        """
        self.smt_path = smt_path
        self.user_space = user_space
        self.preamble : str | None = None
        self.postamble : str | None = None
        self.stubs : dict[sx.Symbol, list] | None = None
        self.asserts : list[list] | None = None
        self.declare_consts : list[sx.Symbol] | None = None
        self.is_simple : bool | None = None
        self._cex_cache : dict[tuple[Interpretation, str], PropertyCex] = {}
        self._cached_interps : list[Interpretation] = []
        self._cached_interps_fast : set[Interpretation] = set()
        self._parse()

    def _parse(self):
        """Parse SMT file into script slices and analysis metadata.

        `preamble` is all top-level forms before the first `defstub`.
        `postamble` is all top-level forms after the last `defstub`.
        `stubs` maps each stub function symbol to its full `defstub`
        s-expression.
        `asserts` stores all top-level assert forms.
        `declare_consts` stores symbols from top-level declare-const forms.
        `is_simple` is True when every defstub call in every assert uses only
        declared-const symbols as arguments.
        """
        with open(self.smt_path, "r", encoding="utf-8") as f:
            raw = f.read()
        sexpr = sx.parse(raw)
        if not isinstance(sexpr, list):
            raise ValueError("Expected SMT script to parse to a list of forms.")
        stub_idxs = self._stub_indices(sexpr)
        if len(stub_idxs) == 0:
            raise ValueError(
                "Expected at least one defstub in SMT property script.",
            )

        first_stub = stub_idxs[0]
        last_stub = stub_idxs[-1]
        self._assert_contiguous_stub_block(sexpr, first_stub, last_stub)
        self.preamble = self._render_forms(sexpr[:first_stub])
        self.postamble = self._render_forms(sexpr[last_stub + 1 :])
        self.stubs = self._collect_stubs(sexpr, first_stub, last_stub)
        self.asserts = self._collect_asserts(sexpr)
        self.declare_consts = self._collect_declare_consts(sexpr)
        self.is_simple = self._compute_is_simple(
            self.asserts,
            list(self.stubs.keys()),
            self.declare_consts,
        )

    def _stub_indices(self, sexpr : list) -> list[int]:
        """Return indices of all top-level defstub forms."""
        stub_idxs : list[int] = []
        for idx, form in enumerate(sexpr):
            if self._is_stub(form):
                stub_idxs.append(idx)
        return stub_idxs

    def _assert_contiguous_stub_block(
            self,
            sexpr : list,
            first_stub : int,
            last_stub : int) -> None:
        """Fail if any non-stub appears between first and last defstub."""
        for idx in range(first_stub, last_stub + 1):
            if self._is_stub(sexpr[idx]):
                continue
            raise ValueError(
                "Found non-stub form between defstub directives.",
            )

    def _collect_stubs(
            self,
            sexpr : list,
            first_stub : int,
            last_stub : int) -> dict[sx.Symbol, list]:
        """Build mapping from stub function symbol to its defstub form."""
        stubs : dict[sx.Symbol, list] = {}
        for idx in range(first_stub, last_stub + 1):
            stub = sexpr[idx]
            assert isinstance(stub, list)
            if len(stub) < 2:
                raise ValueError(f"Malformed defstub: {stub}")
            fn_name = stub[1]
            if not isinstance(fn_name, sx.Symbol):
                raise ValueError(f"Expected symbolic defstub name, got {fn_name}")
            stubs[fn_name] = stub
        return stubs

    def _is_stub(self, form) -> bool:
        """Return True iff form is a top-level defstub expression."""
        if not isinstance(form, list):
            return False
        if len(form) == 0:
            return False
        return form[0] == sx.Symbol("defstub")

    def _collect_asserts(self, sexpr : list) -> list[list]:
        """Return all top-level assert forms from the script."""
        asserts : list[list] = []
        for form in sexpr:
            if self._is_assert(form):
                assert isinstance(form, list)
                asserts.append(form)
        return asserts

    def _collect_declare_consts(self, sexpr : list) -> list[sx.Symbol]:
        """Return symbols from all top-level declare-const directives."""
        declare_consts : list[sx.Symbol] = []
        for form in sexpr:
            if not self._is_declare_const(form):
                continue
            assert isinstance(form, list)
            if len(form) < 2:
                raise ValueError(f"Malformed declare-const: {form}")
            sym = form[1]
            if not isinstance(sym, sx.Symbol):
                raise ValueError(
                    f"Expected symbolic declare-const name, got {sym}",
                )
            declare_consts.append(sym)
        return declare_consts

    def _compute_is_simple(
            self,
            assert_forms : list[list],
            stub_names : list[sx.Symbol],
            declare_consts : list[sx.Symbol]) -> bool:
        """Check that assert calls to stubs use only declared constants.

        Returns True iff for every call `(fn arg1 ... argn)` in every assert
        where `fn` is a defstub symbol, each argument is a symbol that appears
        in a top-level `(declare-const ...)` directive.
        """
        declared_set = set(declare_consts)
        for assert_form in assert_forms:
            for _, args in self._iter_stub_calls(assert_form, stub_names):
                for arg in args:
                    if not isinstance(arg, sx.Symbol):
                        return False
                    if arg not in declared_set:
                        return False
        return True

    def _iter_stub_calls(
            self,
            sexpr,
            stub_names : list[sx.Symbol]) -> list[tuple[sx.Symbol, list]]:
        """Collect all `(stub arg1 ... argn)` call nodes in one expression."""
        stub_name_set = set(stub_names)
        calls : list[tuple[sx.Symbol, list]] = []
        self._collect_stub_calls(sexpr, stub_name_set, calls)
        return calls

    def _collect_stub_calls(
            self,
            sexpr,
            stub_name_set : set[sx.Symbol],
            out_calls : list[tuple[sx.Symbol, list]]) -> None:
        """Append every nested call whose head is in stub_name_set."""
        if not isinstance(sexpr, list):
            return
        if len(sexpr) == 0:
            return

        head = sexpr[0]
        if isinstance(head, sx.Symbol) and head in stub_name_set:
            out_calls.append((head, sexpr[1:]))

        for child in sexpr:
            self._collect_stub_calls(child, stub_name_set, out_calls)

    def _is_assert(self, form) -> bool:
        """Return True iff form is a top-level assert expression."""
        if not isinstance(form, list):
            return False
        if len(form) == 0:
            return False
        return form[0] == sx.Symbol("assert")

    def _is_declare_const(self, form) -> bool:
        """Return True iff form is a top-level declare-const expression."""
        if not isinstance(form, list):
            return False
        if len(form) == 0:
            return False
        return form[0] == sx.Symbol("declare-const")

    def _render_forms(self, forms : list) -> str:
        """Serialize a list of top-level s-expressions to a script fragment."""
        return "\n".join([self._render_top_form(form) for form in forms])

    def _render_top_form(self, form) -> str:
        """Render one top-level form with define-fun arg-list handling."""
        if not isinstance(form, list):
            return self._dumps_nil(form)
        if len(form) == 0:
            return self._dumps_nil(form)
        head = form[0]
        if head != sx.Symbol("define-fun"):
            return self._dumps_nil(form)
        if len(form) < 3:
            return self._dumps_nil(form)
        rendered = []
        for idx, item in enumerate(form):
            if idx == 2:
                rendered.append(sx.dumps(item).replace("\\?", "?"))
            else:
                rendered.append(self._dumps_nil(item))
        return f"({' '.join(rendered)})"

    def _dumps_nil(self, sexpr) -> str:
        """Serialize one s-expression while rendering [] as nil.

        Candidate bodies may use ``sx.Quoted(x)`` for ACL2-style quoted
        terminals; for SMT output we render the inner ``x`` only.
        """
        if isinstance(sexpr, sx.Quoted):
            return self._dumps_nil(sexpr.x)
        if sexpr == []:
            return "nil"
        if isinstance(sexpr, bool) and sexpr is False:
            return "nil"
        if isinstance(sexpr, list):
            inner = [self._dumps_nil(item) for item in sexpr]
            res = f"({' '.join(inner)})"
            return res

        res = sx.dumps(sexpr).replace("\\?", "?")
        return res

    def _render_functions(self, fn_bodies : dict[sx.Symbol, Expression]) -> str:
        """Render `(define-fun-rec ...)` replacements for parsed stubs.

        Each defstub from the SMT file is replaced by a corresponding
        `define-fun-rec` using the body map entry for the same function name.
        """
        if self.stubs is None:
            raise ValueError("SMT stubs are not initialized.")

        rendered = []
        for fn_name, stub in self.stubs.items():
            if fn_name not in fn_bodies:
                raise ValueError(
                    f"No function body found for stub function {fn_name}.",
                )
            if not isinstance(stub, list) or len(stub) != 4:
                raise ValueError(f"Malformed defstub for {fn_name}: {stub}")

            args = stub[2]
            ret_type = stub[3]
            body = fn_bodies[fn_name]
            fn_def = [
                sx.Symbol("define-fun-rec"),
                fn_name,
                args,
                ret_type,
                body,
            ]
            rendered.append(self._render_top_form(fn_def))
        return "\n".join(rendered)
     
    def _mk_model(self, model : z3.ModelRef) -> Interpretation:
        """Build a map from declared SMT symbols to converted model values.

        Assumes `self.declare_consts` is initialized by `_parse`. Returns a
        mapping `M` such that each declared const symbol `x` is in `M` iff Z3
        produced a model entry for `x`. Each mapped value is converted from Z3
        syntax into the project's `Expression` representation.
        """
        if self.declare_consts is None:
            raise ValueError("Expected declare_consts to be initialized.")

        declared_names = {sym.value() for sym in self.declare_consts}
        result : dict[sx.Symbol, Expression] = {}
        for decl in model:
            name = decl.name()
            if name in declared_names:
                value = model.eval(decl(), model_completion=True)
                result[sx.Symbol(name)] = self._z3_to_expr(value)
        return Interpretation(result)

    def _z3_to_expr(self, value : z3.ExprRef) -> Expression:
        """Convert one Z3 expression into this project's s-expression format.

        Returns an `Expression` that preserves the structure of `value` by
        mapping Z3 applications to list applications, symbols to `sx.Symbol`,
        and numerals/booleans to Python primitives.
        """
        if z3.is_int_value(value):
            return value.as_long()

        if z3.is_rational_value(value):
            raise ValueError(f"rationals not supported")

        if z3.is_true(value):
            return True
        if z3.is_false(value):
            return False

        if not z3.is_app(value):
            raise ValueError(f"Unsupported Z3 value form: {value}")

        head = sx.Symbol(value.decl().name())
        arity = value.num_args()
        if arity == 0:
            if head == sx.Symbol("nil-list"):
                return False
            return sx.Quoted(head)

        args = [self._z3_to_expr(value.arg(i)) for i in range(arity)]
        return [head] + args

    def cache_test(self, candidate : Candidate) -> None | Cex:
        """Replay cached SMT cex keys against the current candidate.

        A cache key is `(interp, out)` where `interp` is a stored
        interpretation and `out` is the serialized value of one defstub call
        under that interpretation. Returns the cached `PropertyCex` on hit.
        """
        for interp in self._cached_interps:
            keys = self._mk_interp_output_keys(candidate, interp)
            if keys is None:
                continue
            for key in keys:
                if key in self._cex_cache:
                    print("SMT INTERP-OUTPUT CACHE HIT")
                    cached_cex = self._cex_cache[key]
                    interp = cached_cex.interpretation
                    trace = self._mk_trace(candidate, interp)
                    return PropertyCex(
                        interp,
                        [],
                        candidate.sketch_ids(),
                        trace,
                        [],
                    )
        return None

    def _add_cache(self, candidate : Candidate, cex : PropertyCex) -> None:
        """Store `(interp, defstub-call-output)` keys for one SMT cex."""
        interp = cex.interpretation
        keys = self._mk_interp_output_keys(candidate, interp)
        if keys is None:
            raise ValueError(
                "Contract violation while building SMT cache key.",
            )
        for key in keys:
            if key in self._cex_cache:
                continue
            self._cex_cache[key] = cex
        if interp in self._cached_interps_fast:
            return
        self._cached_interps_fast.add(interp)
        self._cached_interps.append(interp)

    def _mk_interp_output_keys(
            self,
            candidate : Candidate,
            interp : Interpretation) -> None | list[tuple[Interpretation, str]]:
        """Build cache keys for each assert's unique defstub call output."""
        if self.asserts is None:
            raise ValueError("Expected asserts to be initialized.")
        if self.stubs is None:
            raise ValueError("Expected stubs to be initialized.")

        assoc : Expression = [[k, v] for k, v in interp.assoc.items()]
        keys : list[tuple[Interpretation, str]] = []
        stub_names = list(self.stubs.keys())
        self.user_space.push(candidate.user_functions())
        for assert_form in self.asserts:
            if len(assert_form) != 2:
                continue
            body = assert_form[1]
            calls = self._iter_stub_calls(body, stub_names)
            if len(calls) != 1:
                self.user_space.pop()
                raise ValueError(
                    "Expected exactly one stub application per assert.",
                )
            fn_name, args = calls[0]
            call_expr : Expression = [fn_name] + args
            cmd = [sx.Symbol("let"), assoc, call_expr]
            try:
                out = local_eval(cmd, user_space=self.user_space)
            except RecursionError:
                self.user_space.pop()
                return None
            if isinstance(out, leval.ContractViolation):
                self.user_space.pop()
                return None
            out_key = dumps(out)
            keys.append((interp, out_key))
        self.user_space.pop()
        return keys

    def _mk_trace(
            self,
            candidate : Candidate,
            interp : Interpretation) -> Trace:
        """Build a trace by evaluating SMT asserts under one interpretation.

        Uses the same user-space push/eval/pop flow as PropertyVerifier trace
        construction. Returns an empty trace if no asserts are present.
        """
        if self.asserts is None:
            raise ValueError("Expected asserts to be initialized.")

        if self.stubs is None:
            raise ValueError("Expected stubs to be initialized.")

        assoc : Expression = [[k, v] for k, v in interp.assoc.items()]
        stub_names = list(self.stubs.keys())
        self.user_space.push(candidate.user_functions())
        try:
            for assert_form in self.asserts:
                if len(assert_form) != 2:
                    continue
                body = assert_form[1]
                calls = self._iter_stub_calls(body, stub_names)
                if len(calls) != 1:
                    raise ValueError(
                        "Expected exactly one stub application per assert.",
                    )
                fn_name, args = calls[0]
                call_expr : Expression = [fn_name] + args
                cmd = [sx.Symbol("let"), assoc, call_expr]
                local_eval(cmd, user_space=self.user_space)
        except RecursionError:
            print(
                "WARNING: RecursionError during SMT property trace creation.",
            )
        trace = Trace("\n".join(sorted(self.user_space._trace)), self.user_space._extended_trace)
        self.user_space.pop()
        return trace

    def verify(
            self,
            fn_bodies : dict[sx.Symbol, Expression],
            candidate : Candidate) -> None | Cex:
        """Check one SMT property script against supplied function bodies.

        Returns None when the query is unsat or unknown. Returns a property
        counterexample for simple scripts and NoOpCex otherwise.
        """
        if self.preamble is None:
            raise ValueError("Expected preamble to be initialized.")
        if self.postamble is None:
            raise ValueError("Expected postamble to be initialized.")
        fn_defs = self._render_functions(fn_bodies)
        parts = [self.preamble, fn_defs, self.postamble]
        query = "\n".join([part for part in parts if part != ""])
        solver = z3.Solver()
        try:
            solver.from_string(query)
            res = solver.check()
        except z3.Z3Exception as err:
            print("===== FAILED SMT INPUT SCRIPT =====")
            print(query)
            print("===== END FAILED SMT INPUT SCRIPT =====")
            raise ValueError(
                f"Z3 failed while parsing/checking SMT script: {err}",
            )
        if res == z3.sat:
            model = solver.model()
            interp = self._mk_model(model)
            print("Z3 MODEL")
            pprint(interp.assoc)
            if self.is_simple:
                # in this case, we can return a typical PropertyCex, since the
                # implementation of all stubs is only called on outermost
                # universally quantified variables.
                trace = self._mk_trace(candidate, interp)
                cex = PropertyCex(
                    interp,
                    [],
                    candidate.sketch_ids(),
                    trace,
                    [],
                )
                self._add_cache(candidate, cex)
                return cex
            # But in the general case, we can't just do that.
            return NoOpCex()
        return None
