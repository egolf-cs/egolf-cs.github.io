"""Factory for building ProgramVerifier and its dependencies from an Instance.
The session is created, sent the instance preamble, then passed to all
components.
"""

from VerifierAux import Session
from Instance import Instance
from Structs import UserSpace

from .ContractCache import ContractCache
from .TerminationCache import TerminationCache
from .PropertyCache import PropertyCache
from .ExprAdmitter import ExprAdmitter
from .FnAdmitter import FnAdmitter
from .PropertyVerifier import PropertyVerifier
from .SmtPropertyVerifier import SmtPropertyVerifier
from .ProgramVerifier import ProgramVerifier


def mk_program_verifier(instance : Instance) -> tuple[ProgramVerifier, Session]:
    """Build a ProgramVerifier and all inner objects. The session is created,
    initialized with the instance preamble, then passed to each inner
    component. Returns (verifier, session) so the session can be used
    elsewhere (e.g. generalizer) without ProgramVerifier holding it.
    """
    session = Session()
    preamble_cmd = " ".join(instance.preamble())
    session.send(preamble_cmd)

    user_space = instance.user_space
    fn_admitters : dict[int, FnAdmitter] = {}
    fn_names_set = set()
    contract_caches : dict[object, ContractCache] = {}
    termination_caches : dict[object, TerminationCache] = {}

    for sketches in instance.prod_sketches():
        for sketch in sketches:
            fn_names_set.add(sketch.name)
            if id(sketch) in fn_admitters:
                continue
            expr_admitters = []
            for hname in sketch.hole_names():
                hole_fn = sketch.hole_function(hname)
                if hole_fn not in contract_caches:
                    contract_caches[hole_fn] = ContractCache(user_space)
                contract_cache = contract_caches[hole_fn]
                expr_admitters.append(
                    ExprAdmitter(hname, sketch, session, contract_cache))
            top_fn = sketch.name
            if top_fn not in termination_caches:
                termination_caches[top_fn] = TerminationCache(user_space)
            termination_cache = termination_caches[top_fn]
            fn_admitter = FnAdmitter(
                sketch, expr_admitters, termination_cache, session)
            fn_admitters[id(sketch)] = fn_admitter

    fn_names = list(fn_names_set)

    property_verifiers = []
    for prop in instance.properties():
        cache = PropertyCache(prop, user_space, fn_names)
        property_verifiers.append(
            PropertyVerifier(prop, session, cache, user_space))

    smt_property_verifiers = []
    for smt_prop in instance.smt_properties():
        smt_property_verifiers.append(
            SmtPropertyVerifier(smt_prop, user_space),
        )

    return ProgramVerifier(
        fn_admitters,
        property_verifiers,
        smt_property_verifiers,
    ), session
