from Candidate import Candidate
from EnumerationInterface import CandidateSpace
from Structs import Interpretation
from Generalizer import PruningConstraint

class DefaultCandidateSpace(CandidateSpace):

    def next(self) -> Candidate | None:
        while True:
            for idx, ics in enumerate(self.inner_spaces):
                candidate = ics.next()
                if candidate is not None:
                    return candidate
            concept = self.concept_space.next()
            if concept is None:
                return None
            for ics in self.inner_spaces:
                ics.add_concept(concept)
