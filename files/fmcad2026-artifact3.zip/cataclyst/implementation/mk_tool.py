from pprint import pprint

from Instance import Instance, parse
from Candidate import Concept
from Structs import UserSpace

from Tool import Tool

from EnumerationInterface import CandidateSpace, InnerCandidateSpace
from EnumerationInterface import RuleEnumerator

from CandidateSpace import DefaultCandidateSpace
from EmergentSpace import DefaultEmergentSpace
from ConceptSpace import DefaultConceptSpace
from RuleEnumerator import DefaultRuleEnumerator


from EmergentSpace import ConstrainedEmergentSpace
from EmergentSpace import ReducedEmergentSpace

from Verification.mk_program_verifier import mk_program_verifier

from Generalizer import Generalizer
from Generalizer import DefaultGeneralizer
# from Generalizer import TrivialContractCexGeneralizer
# from Generalizer import ConstantGuardGeneralizer
# from Generalizer import ConstTermGeneralizer
from Generalizer import ConstTermPropGeneralizer

def mk_default_candidatespace(
        instance : Instance, ESpace) -> CandidateSpace:
    em_spaces = [ESpace(ntss) for ntss in instance.start_ntss()]
    zs = [(em, sk) for em, sk in zip(em_spaces, instance.prod_sketches())]
    # print(instance.branch_rules())
    # print(instance.terminal_rules())
    # assert False
    inner_spaces = [
        InnerCandidateSpace(em, sk) for em, sk in zs]
    rule_enumerators : list[RuleEnumerator] = [
        DefaultRuleEnumerator(rule) for rule in instance.branch_rules()]
    base_concepts = [
        Concept(rule.nt, rule.tree) for rule in instance.terminal_rules()]
    concept_space = DefaultConceptSpace(
        rule_enumerators, instance.subexpr_bound, base_concepts)
    cand_space = DefaultCandidateSpace(concept_space, inner_spaces)
    return cand_space

def mk_naive_tool(instance : Instance) -> Tool:
    verifier, _ = mk_program_verifier(instance)
    generalizer = DefaultGeneralizer()
    candidate_space = mk_default_candidatespace(
        instance, DefaultEmergentSpace)
    return Tool(
        candidate_space, verifier, generalizer, instance.primitives,
        instance)


def mk_retro_tool(instance : Instance) -> Tool:
    verifier, session = mk_program_verifier(instance)
    generalizer = ConstTermPropGeneralizer(session)
    candidate_space = mk_default_candidatespace(
        instance, ConstrainedEmergentSpace)
    return Tool(
        candidate_space, verifier, generalizer, instance.primitives,
        instance)


def mk_proph_tool(instance : Instance) -> Tool:
    verifier, session = mk_program_verifier(instance)
    generalizer = ConstTermPropGeneralizer(session)
    candidate_space = mk_default_candidatespace(
        instance, ReducedEmergentSpace)
    return Tool(
        candidate_space, verifier, generalizer, instance.primitives,
        instance)

