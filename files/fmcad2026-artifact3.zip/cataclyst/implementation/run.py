import time
from datetime import datetime
import os
import sys
import multiprocessing
from pprint import pprint
from jinja2 import Environment, FileSystemLoader
import sexpdata as sx

import builtins
import functools
from pathlib import Path

builtins.print = functools.partial(builtins.print, flush=True)

from Tool import Tool

from Instance import parse
from mk_tool import (
    mk_naive_tool, 
    mk_retro_tool,
    mk_proph_tool,
)
from Sketch import get_functions, dumps

from FNAMES import FNAMES

# `inputs/` and `output/` are siblings of `implementation/` under `cataclyst/`.
# Per-tool runs read benchmarks from `INPUTS_DIR` and write results to
# `OUTPUT_DIR / f"output-{tool_id}" / fname` (mirrors `FROZEN_OUTPUT/`).
_CATACLYST_DIR = Path(__file__).resolve().parent.parent
INPUTS_DIR = _CATACLYST_DIR / "inputs"
OUTPUT_DIR = _CATACLYST_DIR / "output"


def list_functions_all():
    for fname in FNAMES:
        list_functions(fname)

def list_functions(fname):
    tgt_sketch_id, tgt, instance, parse_time = local_parse(fname)
    assert tgt is not None
    print("\nFunctions in", fname, ":", flush=True)
    fs = get_functions(tgt[-1]) #type:ignore
    fs = [f for f in fs if f not in [sx.Symbol("if"), tgt[1]]] #type:ignore
    fs = [sx.Symbol("declare-primitives")] + fs
    fs = sx.dumps(fs)
    print(fs)

def validate_parsing_all():
    for fname in FNAMES:
        print(f"Validating parsing for {fname}...", flush=True)
        validate_parsing(fname)
        print(f"Parsing for {fname} validated successfully.", flush=True)
    print("\n\nAll parsing validations completed successfully.", flush=True)

def validate_target_all(tool_id):
    for fname in FNAMES:
        print(60*">", flush=True)
        print(f"Validating target for {fname}...", flush=True)
        parse_and_validate(fname, tool_id)
        print(f"Target for {fname} validated successfully.", flush=True)
        print(60*"<", flush=True)
    print("\n\nAll target validations completed successfully.", flush=True)

def validate_parsing(fname):
    local_parse(fname)

def run(fname, tool_id, outname, batchtime):
    start_time = time.time()
    tool, parse_time, init_tool_time = _run(fname, tool_id, outname)
    end_time = time.time()
    exec_time = end_time - start_time
    Path(outname).parent.mkdir(parents=True, exist_ok=True)
    tool.write_data(
        outname, exec_time, parse_time, init_tool_time, tool_id, batchtime)


def preprocess(fname, dir):
    with open(f"{dir}/{fname}", "r") as f:
        content = f.read()
    lisp = sx.parse(content)
    out : list[str] = []
    for x in lisp:
        if isinstance(x, list) and len(x) > 0 and x[0] == sx.Symbol("ld"):
            inner_fname = dumps(x[1])
            inner_content = preprocess(inner_fname, dir)
            out.append(inner_content)
        elif isinstance(x, list) and len(x) > 0 and x[0] == sx.Symbol("smt"):
            if len(x) != 2:
                raise ValueError(
                    f"Expected smt directive of form (smt <path>), got {x}.",
                )
            smt_rel_path = dumps(x[1])
            smt_full_path = f"{dir}/{smt_rel_path}"
            out.append(sx.dumps([sx.Symbol("smt"), sx.Symbol(smt_full_path)]))
        else:
            out.append(dumps(x))
    return "\n".join(out)

def local_parse(fname):
    start_time = time.time()
    print("Reading input from", fname, flush=True)
    lisp_str = preprocess(fname, str(INPUTS_DIR))
    print("Parsing input...", flush=True)
    tgt_sketch_ids, tgts, instance = parse(lisp_str)
    parse_time = time.time() - start_time
    return tgt_sketch_ids, tgts, instance, parse_time

def init_tool(instance, tool_id):
    start_time = time.time()
    if tool_id == "proph":
        tool = mk_proph_tool(instance)
    elif tool_id == "retro":
        tool = mk_retro_tool(instance)
    elif tool_id == "brute":
        tool = mk_naive_tool(instance)
    else:
        raise ValueError(
            f"Unknown tool ID {tool_id}.")
    init_time = time.time() - start_time
    return tool, init_time

def parse_and_validate(fname, tool_id):
    print("Running", fname, "with tool", tool_id, flush=True)
    tgt_sketch_ids, tgts, instance, parse_time = local_parse(fname)
    print("Parsing complete.", flush=True)

    print("Initializing tool...", flush=True)
    tool, init_tool_time = init_tool(instance, tool_id)
    print("Tool initialized.", flush=True)

    assert isinstance(tgts, dict)
    assert isinstance(tgt_sketch_ids, dict)
    if instance.validate_targets:
        if set(tgt_sketch_ids.keys()) != set(tgts.keys()):
            print("tgt_sketch_ids")
            pprint(tgt_sketch_ids)
            print("tgts")
            pprint(tgts)
            assert False
        tool.validate_sol(
            tgts,
            tgt_sketch_ids,
            instance.grammar,
            instance.subexpr_bound,
        )  # type: ignore
    else:
        print(
            "Skipping ground-truth target validation (set-validate nil).",
            flush=True,
        )
    return tool, parse_time, init_tool_time

def _run(fname, tool_id, outname) -> tuple[Tool, float, float]:
    tool, parse_time, init_tool_time = parse_and_validate(fname, tool_id)

    print("Starting search for a solution...", flush=True)

    solution = tool.solve(timeout=60*15)
    # solution = tool.solve()
    assert tool.is_done is not None
    assert tool.is_timeout is not None
    if tool.is_timeout:
        print("TIMEOUT, killing solver", flush=True)
        return tool, parse_time, init_tool_time
    
    print("\n\nSearch complete.", flush=True)
    print("Concepts generated during search:", flush=True)
    for concept in tool.concepts():
        print(concept)
    if solution is None:
        if tool.instance.validate_targets:
            print("\n\n\nNO SOLUTION FOUND.", flush=True)
            raise ValueError(
                "User supplied ground truth solution was not found.",
            )
        print(
            "No solution found (set-validate nil; exiting without error).",
            flush=True,
        )
    else:
        print("\n\n\nSOLUTION FOUND:", flush=True)
        print(solution)
    return tool, parse_time, init_tool_time

def main(tool_id, fname=None):

    assert fname is not None

    outname = str(OUTPUT_DIR / f"output-{tool_id}" / fname)
    # outname = str(OUTPUT_DIR / "output-testing" / fname)
    run(fname, tool_id, outname, None)

def run_all_all():
    batchtime = datetime.now()
    batchtime = batchtime.strftime("%Y-%m-%d_%H:%M:%S")
    for fname in FNAMES:
        # for tool_id in ["brute", "retro", "proph"]:
        # for tool_id in ["retro", "proph"]:
        for tool_id in ["brute", "retro"]:
            outname = str(OUTPUT_DIR / f"output-{tool_id}" / fname)
            run(fname, tool_id, outname, batchtime)


def run_all(tool_id):
    batchtime = datetime.now()
    batchtime = batchtime.strftime("%Y-%m-%d_%H:%M:%S")

    for fname in FNAMES:
        outname = str(OUTPUT_DIR / f"output-{tool_id}" / fname)
        run(fname, tool_id, outname, batchtime)

if __name__ == "__main__":
    print(f"!kill -9 {os.getpid()}", flush=True)

    if len(sys.argv) != 2:
        print("Usage: python run.py <tool-id>", flush=True)
        print("Where <tool-id> is one of: naive, retro, proph", flush=True)
        sys.exit(1)
    
    tool_id = sys.argv[1]

    
    bench = "unreal-tree-k-path-smt"
    # main(tool_id, f"{bench}.lisp")
    # validate_parsing(f"{bench}.lisp")
    # main(tool_id)
    # run_all(tool_id)
    run_all_all()
    # validate_parsing_all()
    # validate_target_all(tool_id)
    # list_functions_all()
