; Synthesized functions:
(
  (
    definec
    has-k-path
    (tr :bintree k :nat)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      (zp k)
      (
        if
        (zp k)
        ()
        (
          or
          (
            has-k-path
            (bt-left tr)
            (pred k)
          )
          (
            has-k-path
            (bt-right tr)
            (pred k)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/tree-k-path-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:47:40)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 268.23)
  (tgt-validation-time 6.55)
  (total-solve-time 261.69)
    (parse-time 0.01)
    (init-tool-time 3.55)
    (solver-time 258.13)