; Synthesized functions:
(
  (
    definec
    suffixb
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (equal ys xs)
      t
      (
        if
        (endp ys)
        ()
        (
          suffixb
          xs
          (tail ys)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/suffixb-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_19:04:06)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 27.66)
  (tgt-validation-time 3.00)
  (total-solve-time 24.66)
    (parse-time 0.03)
    (init-tool-time 0.55)
    (solver-time 24.08)