; Synthesized functions:
(
  (
    definec
    ones
    (xs :bit-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (
          szerop
          (head xs)
        )
        ()
        (
          ones
          (tail xs)
        )
      )
    )
  )
  (
    definec
    monotonic
    (xs :bit-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (
          szerop
          (head xs)
        )
        (
          monotonic
          (tail xs)
        )
        (ones xs)
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/monotonic-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:57:45)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 223.26)
  (tgt-validation-time 4.65)
  (total-solve-time 218.61)
    (parse-time 0.00)
    (init-tool-time 1.29)
    (solver-time 217.31)