; Synthesized functions:
(
  (
    definec
    contata-insert-sort
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (cons x xs)
      (
        if
        (
          <=
          x
          (head xs)
        )
        (cons x xs)
        (
          cons
          (head xs)
          (
            contata-insert-sort
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-list-sort.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:02:08)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 34.40)
  (tgt-validation-time 5.12)
  (total-solve-time 29.29)
    (parse-time 0.00)
    (init-tool-time 2.04)
    (solver-time 27.24)