; Synthesized functions:
(
  (
    definec
    udiv
    (x1 :unary x2 :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x1)
      x1
      (
        ite
        (
          equal
          x1
          (
            unary-mul
            x2
            (
              usucc
              (
                udiv
                (tail x1)
                x2
              )
            )
          )
        )
        (
          usucc
          (
            udiv
            (tail x1)
            x2
          )
        )
        (
          udiv
          (tail x1)
          x2
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/vampire-division.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:36:33)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 107.08)
  (tgt-validation-time 5.73)
  (total-solve-time 101.34)
    (parse-time 0.00)
    (init-tool-time 3.05)
    (solver-time 98.29)