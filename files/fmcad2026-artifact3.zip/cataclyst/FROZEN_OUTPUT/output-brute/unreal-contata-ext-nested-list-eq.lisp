; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/unreal-contata-ext-nested-list-eq.acl2s)

(toolname brute)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_05:25:16)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.22)
  (tgt-validation-time 0.00)
  (total-solve-time 16.22)
    (parse-time 0.00)
    (init-tool-time 1.16)
    (solver-time 15.06)