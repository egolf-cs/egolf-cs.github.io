; Synthesized functions:
(
  (
    definec
    split-on-zero
    (xs :int-list)
    :int-list-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          0
        )
        (
          cons
          ()
          (
            cons
            (list 0)
            (
              split-on-zero
              (tail xs)
            )
          )
        )
        (
          carcons
          (head xs)
          (
            split-on-zero
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-split-on.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:23:46)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 28.24)
  (tgt-validation-time 3.02)
  (total-solve-time 25.21)
    (parse-time 0.00)
    (init-tool-time 1.47)
    (solver-time 23.74)