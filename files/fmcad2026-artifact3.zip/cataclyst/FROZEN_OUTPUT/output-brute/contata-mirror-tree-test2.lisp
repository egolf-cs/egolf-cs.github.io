; Synthesized functions:
(
  (
    definec
    mirror
    (x :bintree)
    :bintree
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      'leaf
      (
        list
        (
          mirror
          (bt-right x)
        )
        (bt-value x)
        (
          mirror
          (bt-left x)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-mirror-tree-test2.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:58:59)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 34.50)
  (tgt-validation-time 3.15)
  (total-solve-time 31.35)
    (parse-time 0.00)
    (init-tool-time 1.10)
    (solver-time 30.25)