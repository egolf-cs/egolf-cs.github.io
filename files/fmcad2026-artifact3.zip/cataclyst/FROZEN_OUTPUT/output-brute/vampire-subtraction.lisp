; Synthesized functions:
(
  (
    definec
    sub
    (x1 :unary x2 :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x2)
      x1
      (
        if
        (endp x1)
        x1
        (
          sub
          x2
          (tail x1)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/vampire-subtraction.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:45:33)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 15.82)
  (tgt-validation-time 3.73)
  (total-solve-time 12.09)
    (parse-time 0.00)
    (init-tool-time 1.95)
    (solver-time 10.13)