; Synthesized functions:
(
  (
    definec
    btmax
    (tr :vtree)
    :int
    :skip-admissibilityp
    t
    (
      if
      (intp tr)
      (vt-leaf-val tr)
      (
        ite
        (
          <=
          (vt-node-val tr)
          (
            btmax
            (vt-left tr)
          )
        )
        (
          ite
          (
            <=
            (
              btmax
              (vt-left tr)
            )
            (
              btmax
              (vt-right tr)
            )
          )
          (
            btmax
            (vt-right tr)
          )
          (
            btmax
            (vt-left tr)
          )
        )
        (
          ite
          (
            <=
            (vt-node-val tr)
            (
              btmax
              (vt-right tr)
            )
          )
          (
            btmax
            (vt-right tr)
          )
          (vt-node-val tr)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/vampire-tree-max.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:59:08)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 801.31)
  (tgt-validation-time 11.58)
  (total-solve-time 789.73)
    (parse-time 0.00)
    (init-tool-time 8.27)
    (solver-time 781.46)