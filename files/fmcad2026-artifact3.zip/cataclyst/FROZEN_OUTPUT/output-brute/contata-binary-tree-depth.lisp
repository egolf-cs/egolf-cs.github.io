; Synthesized functions:
(
  (
    definec
    bt-depth
    (x :bintree)
    :int
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      0
      (
        1+
        (
          max
          (
            bt-depth
            (bt-right x)
          )
          (
            bt-depth
            (bt-left x)
          )
        )
      )
    )
  )
  (
    definec
    bt-cmp
    (x :bintree x1 :bintree)
    :compare
    :skip-admissibilityp
    t
    (
      int-cmp
      (bt-depth x)
      (bt-depth x1)
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-binary-tree-depth.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:31:57)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 34.15)
  (tgt-validation-time 4.91)
  (total-solve-time 29.24)
    (parse-time 0.01)
    (init-tool-time 1.51)
    (solver-time 27.72)