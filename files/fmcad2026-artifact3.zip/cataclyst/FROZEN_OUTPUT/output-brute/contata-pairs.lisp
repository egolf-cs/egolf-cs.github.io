; Synthesized functions:
(
  (
    definec
    pairs
    (xs :int-list)
    :int-pair-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          endp
          (tail xs)
        )
        ()
        (
          cons
          (
            list
            (head xs)
            (
              head
              (tail xs)
            )
          )
          (
            pairs
            (
              tail
              (tail xs)
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-pairs.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:07:24)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 48.42)
  (tgt-validation-time 3.05)
  (total-solve-time 45.37)
    (parse-time 0.00)
    (init-tool-time 1.51)
    (solver-time 43.85)