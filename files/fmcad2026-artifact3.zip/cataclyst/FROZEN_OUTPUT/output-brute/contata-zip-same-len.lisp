; Synthesized functions:
(
  (
    definec
    my-zip
    (xs :int-list ys :int-list)
    :int-pair-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (endp ys)
        ()
        (
          cons
          (
            list
            (head xs)
            (head ys)
          )
          (
            my-zip
            (tail xs)
            (tail ys)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-zip-same-len.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:09:38)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 117.26)
  (tgt-validation-time 2.96)
  (total-solve-time 114.31)
    (parse-time 0.01)
    (init-tool-time 0.94)
    (solver-time 113.35)