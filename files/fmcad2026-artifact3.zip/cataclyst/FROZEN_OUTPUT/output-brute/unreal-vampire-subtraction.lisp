; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/unreal-vampire-subtraction.acl2s)

(toolname brute)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_14:14:37)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 12.39)
  (tgt-validation-time 0.00)
  (total-solve-time 12.39)
    (parse-time 0.00)
    (init-tool-time 1.87)
    (solver-time 10.51)