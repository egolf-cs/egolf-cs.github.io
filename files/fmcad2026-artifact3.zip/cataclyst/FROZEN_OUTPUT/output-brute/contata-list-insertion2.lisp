; Synthesized functions:
(
  (
    definec
    contata-list-insertion
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (cons 0 ())
      (
        cons
        (head xs)
        (
          contata-list-insertion
          0
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-list-insertion2.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:00:40)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 10.67)
  (tgt-validation-time 2.35)
  (total-solve-time 8.32)
    (parse-time 0.00)
    (init-tool-time 0.43)
    (solver-time 7.88)