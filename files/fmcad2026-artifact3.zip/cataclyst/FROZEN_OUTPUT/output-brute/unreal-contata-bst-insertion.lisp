; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/unreal-contata-bst-insertion.acl2s)

(toolname brute)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-10_23:18:10)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 913.62)
  (tgt-validation-time 0.00)
  (total-solve-time 913.62)
    (parse-time 0.00)
    (init-tool-time 13.61)
    (solver-time 900.00)