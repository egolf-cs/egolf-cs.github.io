; Synthesized functions:
(
  (
    definec
    threshold-pairs
    (d :nat x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        and
        (
          threshold-pair
          d
          (head xs)
          x
        )
        (
          threshold-pairs
          d
          x
          (tail xs)
        )
      )
    )
  )
  (
    definec
    threshold-list
    (d :nat xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        and
        (
          threshold-pairs
          d
          (head xs)
          (tail xs)
        )
        (
          threshold-list
          d
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/threshold-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:49:05)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 35.75)
  (tgt-validation-time 5.85)
  (total-solve-time 29.90)
    (parse-time 0.00)
    (init-tool-time 1.58)
    (solver-time 28.32)