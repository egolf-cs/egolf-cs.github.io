; Synthesized functions:
(
  (
    definec
    reassoc
    (x :unary y :unary z :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp y)
      z
      (
        usucc
        (
          reassoc
          x
          z
          (tail y)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/vampire-assoc-add.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:34:15)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 31.44)
  (tgt-validation-time 3.49)
  (total-solve-time 27.95)
    (parse-time 0.00)
    (init-tool-time 1.40)
    (solver-time 26.55)