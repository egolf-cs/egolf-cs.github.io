; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/monotonic-full.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_20:18:02)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 910.26)
  (tgt-validation-time 8.24)
  (total-solve-time 902.01)
    (parse-time 0.04)
    (init-tool-time 1.96)
    (solver-time 900.01)