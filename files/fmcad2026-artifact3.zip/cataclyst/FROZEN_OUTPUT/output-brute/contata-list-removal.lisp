; Synthesized functions:
(
  (
    definec
    contata-remove
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        (
          contata-remove
          x
          (tail xs)
        )
        (
          cons
          (head xs)
          (contata-remove x ())
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-list-removal.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:01:13)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 22.09)
  (tgt-validation-time 2.24)
  (total-solve-time 19.84)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 19.40)