; Synthesized functions:
(
  (
    definec
    tree-size-forest-size-wrapper
    (args :tree-size-forest-size-args)
    :tree-size-forest-size-ret
    :skip-admissibilityp
    t
    (
      match
      args
      (
        ('tree-size-args x)
        (
          if
          (itemptyp x)
          0
          (
            1+
            (
              tree-size-forest-size-wrapper
              (
                forest-size-args
                (itchildren x)
              )
            )
          )
        )
      )
      (
        ('forest-size-args x1)
        (
          if
          (ifnilp x1)
          0
          (
            +
            (
              tree-size-forest-size-wrapper
              (
                tree-size-args
                (ifhead x1)
              )
            )
            (
              tree-size-forest-size-wrapper
              (
                forest-size-args
                (iftail x1)
              )
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-tree-forest-size.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:22:16)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 104.45)
  (tgt-validation-time 10.28)
  (total-solve-time 94.16)
    (parse-time 0.01)
    (init-tool-time 3.54)
    (solver-time 90.61)