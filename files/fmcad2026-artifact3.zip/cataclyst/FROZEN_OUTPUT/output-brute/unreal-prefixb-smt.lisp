; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/unreal-prefixb-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_09:21:07)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 212.74)
  (tgt-validation-time 0.00)
  (total-solve-time 212.74)
    (parse-time 0.00)
    (init-tool-time 0.52)
    (solver-time 212.22)