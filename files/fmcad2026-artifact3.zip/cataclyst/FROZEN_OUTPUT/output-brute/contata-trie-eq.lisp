; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-trie-eq.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:43:14)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 905.41)
  (tgt-validation-time 4.20)
  (total-solve-time 901.21)
    (parse-time 0.03)
    (init-tool-time 1.17)
    (solver-time 900.01)