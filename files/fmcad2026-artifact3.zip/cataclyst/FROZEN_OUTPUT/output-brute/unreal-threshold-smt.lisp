; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/unreal-threshold-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_08:24:21)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 128.48)
  (tgt-validation-time 0.00)
  (total-solve-time 128.48)
    (parse-time 0.01)
    (init-tool-time 1.70)
    (solver-time 126.78)