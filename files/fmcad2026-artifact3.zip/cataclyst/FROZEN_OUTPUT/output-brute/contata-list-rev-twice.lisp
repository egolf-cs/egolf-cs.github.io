; Synthesized functions:
(
  (
    definec
    my-rev
    (xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        append
        (
          my-rev
          (tail xs)
        )
        (
          cons
          (head xs)
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-list-rev-twice.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:06:23)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.56)
  (tgt-validation-time 1.91)
  (total-solve-time 14.65)
    (parse-time 0.04)
    (init-tool-time 0.37)
    (solver-time 14.24)