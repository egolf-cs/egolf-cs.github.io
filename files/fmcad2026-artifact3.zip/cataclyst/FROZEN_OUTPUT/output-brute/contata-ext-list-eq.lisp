; Synthesized functions:
(
  (
    definec
    list-eq
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (endp xs)
      (
        if
        (endp ys)
        ()
        (
          if
          (
            equal
            (head ys)
            (head xs)
          )
          (
            list-eq
            (tail xs)
            (tail ys)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-ext-list-eq.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:14:39)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 100.35)
  (tgt-validation-time 3.51)
  (total-solve-time 96.84)
    (parse-time 0.04)
    (init-tool-time 0.43)
    (solver-time 96.38)