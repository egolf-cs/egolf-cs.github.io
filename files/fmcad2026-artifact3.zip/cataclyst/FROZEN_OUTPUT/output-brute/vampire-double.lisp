; Synthesized functions:
(
  (
    definec
    double
    (x :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x)
      x
      (
        usucc
        (
          usucc
          (
            double
            (tail x)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/vampire-double.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:37:26)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 7.95)
  (tgt-validation-time 3.10)
  (total-solve-time 4.85)
    (parse-time 0.00)
    (init-tool-time 1.60)
    (solver-time 3.25)