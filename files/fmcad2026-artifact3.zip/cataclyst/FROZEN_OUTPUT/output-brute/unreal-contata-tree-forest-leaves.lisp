; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/unreal-contata-tree-forest-leaves.acl2s)

(toolname brute)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_01:08:22)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 903.90)
  (tgt-validation-time 0.00)
  (total-solve-time 903.90)
    (parse-time 0.01)
    (init-tool-time 3.88)
    (solver-time 900.00)