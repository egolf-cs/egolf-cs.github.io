; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-ext-list-cmp.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:30:21)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 912.03)
  (tgt-validation-time 11.52)
  (total-solve-time 900.52)
    (parse-time 0.01)
    (init-tool-time 0.51)
    (solver-time 900.01)