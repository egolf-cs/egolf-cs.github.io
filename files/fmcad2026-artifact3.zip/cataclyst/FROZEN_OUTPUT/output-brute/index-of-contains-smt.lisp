; Synthesized functions:
(
  (
    definec
    contains
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        t
        (
          contains
          x
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/index-of-contains-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:58:45)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 27.80)
  (tgt-validation-time 3.09)
  (total-solve-time 24.71)
    (parse-time 0.00)
    (init-tool-time 0.54)
    (solver-time 24.17)