; Synthesized functions:
(
  (
    definec
    contata-remove
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        (
          contata-remove
          x
          (tail xs)
        )
        (
          cons
          (head xs)
          (
            contata-remove
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-list-removal2.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:03:23)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 23.95)
  (tgt-validation-time 2.49)
  (total-solve-time 21.46)
    (parse-time 0.00)
    (init-tool-time 0.45)
    (solver-time 21.01)