; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/suffixb-full.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:18:36)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 908.29)
  (tgt-validation-time 7.34)
  (total-solve-time 900.96)
    (parse-time 0.00)
    (init-tool-time 0.95)
    (solver-time 900.01)