; Synthesized functions:
(
  (
    definec
    nested-list-eq
    (xss :int-list-list yss :int-list-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xss)
      (endp xss)
      (
        if
        (endp yss)
        ()
        (
          if
          (
            list-eq
            (head yss)
            (head xss)
          )
          (
            nested-list-eq
            (tail xss)
            (tail xss)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/contata-nested-list-eq.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:05:45)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 111.37)
  (tgt-validation-time 3.67)
  (total-solve-time 107.70)
    (parse-time 0.00)
    (init-tool-time 1.04)
    (solver-time 106.66)