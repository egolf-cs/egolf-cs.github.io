; Synthesized functions:
(
  (
    definec
    prefix-min
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (endp xs)
        t
        (
          if
          (
            <
            x
            (head xs)
          )
          (
            prefix-min
            x
            (tail xs)
          )
          (
            equal
            (head xs)
            x
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/prefixmin-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_19:05:48)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 79.79)
  (tgt-validation-time 3.59)
  (total-solve-time 76.20)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 75.76)