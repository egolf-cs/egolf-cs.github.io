; Synthesized functions:
(
  (
    definec
    lst-last
    (l :int-list)
    :int
    :skip-admissibilityp
    t
    (
      if
      (endp l)
      0
      (
        if
        (
          endp
          (tail l)
        )
        (head l)
        (
          lst-last
          (tail l)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/vampire-last-element-smt.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:37:44)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 9.57)
  (tgt-validation-time 1.74)
  (total-solve-time 7.83)
    (parse-time 0.00)
    (init-tool-time 0.37)
    (solver-time 7.46)