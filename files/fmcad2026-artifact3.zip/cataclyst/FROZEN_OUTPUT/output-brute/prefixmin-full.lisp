; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/prefixmin-full.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_19:21:27)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 912.76)
  (tgt-validation-time 12.13)
  (total-solve-time 900.63)
    (parse-time 0.01)
    (init-tool-time 0.61)
    (solver-time 900.00)