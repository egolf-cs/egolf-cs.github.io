; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/unreal-contata-parenthesis.acl2s)

(toolname brute)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_01:45:24)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 19.67)
  (tgt-validation-time 0.00)
  (total-solve-time 19.67)
    (parse-time 0.00)
    (init-tool-time 2.97)
    (solver-time 16.69)