; Synthesized functions:
(
  (
    definec
    mk-prefix
    (xs :int-list suffix :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (equal suffix xs)
      ()
      (
        if
        (endp xs)
        ()
        (
          cons
          (head xs)
          (
            mk-prefix
            (tail xs)
            suffix
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-brute/vampire-prefix-given-suffix.acl2s)

(toolname brute)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:43:24)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 201.44)
  (tgt-validation-time 2.98)
  (total-solve-time 198.45)
    (parse-time 0.00)
    (init-tool-time 1.21)
    (solver-time 197.24)