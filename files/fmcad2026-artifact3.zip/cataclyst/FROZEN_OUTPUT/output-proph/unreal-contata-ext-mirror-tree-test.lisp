; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-contata-ext-mirror-tree-test.acl2s)

(toolname proph)
(batchtime 2026-05-10_11:15:52)
(datetime 2026-05-10_12:31:11)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.96)
  (tgt-validation-time 0.00)
  (total-solve-time 16.96)
    (parse-time 0.00)
    (init-tool-time 1.67)
    (solver-time 15.28)