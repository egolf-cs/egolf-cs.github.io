; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-suffixb-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_15:00:40)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 901.00)
  (tgt-validation-time 0.00)
  (total-solve-time 901.00)
    (parse-time 0.02)
    (init-tool-time 0.96)
    (solver-time 900.02)