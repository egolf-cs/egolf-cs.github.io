; Synthesized functions:
(
  (
    definec
    is-open-is-close-wrapper
    (args :is-open-is-close-args)
    :is-open-is-close-ret
    :skip-admissibilityp
    t
    (
      match
      args
      (
        ('is-open-args x)
        (
          if
          (endp x)
          t
          (
            is-open-is-close-wrapper
            (
              is-close-args
              (tail x)
            )
          )
        )
      )
      (
        ('is-close-args x)
        (
          if
          (endp x)
          ()
          (
            is-open-is-close-wrapper
            (
              is-open-args
              (tail x)
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-parenthesis.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:46:47)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 18.09)
  (tgt-validation-time 4.93)
  (total-solve-time 13.15)
    (parse-time 0.00)
    (init-tool-time 2.61)
    (solver-time 10.54)