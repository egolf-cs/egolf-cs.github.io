; Synthesized functions:
(
  (
    definec
    mirror
    (tr :ttree)
    :ttree
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      'leaf
      (
        list
        (tt-right tr)
        (tt-value tr)
        (
          mirror
          (tt-middle tr)
        )
        (tt-left tr)
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-mirror-ternary-test2.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:51:02)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 31.07)
  (tgt-validation-time 3.59)
  (total-solve-time 27.48)
    (parse-time 0.00)
    (init-tool-time 1.43)
    (solver-time 26.05)