; Synthesized functions:
(
  (
    definec
    suffixb
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (equal ys xs)
      t
      (
        if
        (endp ys)
        ()
        (
          suffixb
          xs
          (tail ys)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/suffixb-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:59:33)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 21.15)
  (tgt-validation-time 2.95)
  (total-solve-time 18.20)
    (parse-time 0.00)
    (init-tool-time 0.61)
    (solver-time 17.58)