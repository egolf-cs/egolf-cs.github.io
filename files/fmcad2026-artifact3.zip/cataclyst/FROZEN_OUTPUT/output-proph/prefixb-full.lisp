; Synthesized functions:
(
  (
    definec
    prefixb
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (endp ys)
        ()
        (
          if
          (
            equal
            (head ys)
            (head xs)
          )
          (
            prefixb
            (tail xs)
            (tail ys)
          )
          ()
        )
      )
    )
  )
  (
    definec
    suffix
    (xs :int-list ys :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ys
      (
        if
        (endp ys)
        ()
        (
          suffix
          (tail xs)
          (tail ys)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/prefixb-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:07:19)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 74.44)
  (tgt-validation-time 5.91)
  (total-solve-time 68.53)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 68.09)