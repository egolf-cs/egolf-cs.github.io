; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-prefixb-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_14:41:19)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 21.96)
  (tgt-validation-time 0.00)
  (total-solve-time 21.96)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 21.51)