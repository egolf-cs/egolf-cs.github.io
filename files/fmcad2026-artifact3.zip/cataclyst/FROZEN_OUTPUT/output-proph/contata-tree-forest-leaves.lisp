; Synthesized functions:
(
  (
    definec
    count-leaves-tree-count-leaves-forest-wrapper
    (args :count-leaves-tree-count-leaves-forest-args)
    :count-leaves-tree-count-leaves-forest-ret
    :skip-admissibilityp
    t
    (
      match
      args
      (
        ('count-leaves-tree-args tr)
        (
          if
          (itemptyp tr)
          0
          (
            +
            (
              count-leaves-tree-count-leaves-forest-wrapper
              (count-leaves-tree-args 'itempty)
            )
            (
              count-leaves-tree-count-leaves-forest-wrapper
              (
                count-leaves-forest-args
                (itchildren tr)
              )
            )
          )
        )
      )
      (
        ('count-leaves-forest-args fr)
        (
          if
          (ifnilp fr)
          1
          (
            +
            (
              count-leaves-tree-count-leaves-forest-wrapper
              (
                count-leaves-tree-args
                (ifhead fr)
              )
            )
            (
              count-leaves-tree-count-leaves-forest-wrapper
              (
                count-leaves-forest-args
                (iftail fr)
              )
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-tree-forest-leaves.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:44:59)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 55.27)
  (tgt-validation-time 10.35)
  (total-solve-time 44.92)
    (parse-time 0.01)
    (init-tool-time 3.50)
    (solver-time 41.41)