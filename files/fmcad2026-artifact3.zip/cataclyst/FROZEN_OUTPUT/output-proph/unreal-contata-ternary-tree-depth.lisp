; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-contata-ternary-tree-depth.acl2s)

(toolname proph)
(batchtime 2026-05-10_11:15:52)
(datetime 2026-05-10_12:22:36)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 902.27)
  (tgt-validation-time 0.00)
  (total-solve-time 902.27)
    (parse-time 0.00)
    (init-tool-time 2.26)
    (solver-time 900.01)