; Synthesized functions:
(
  (
    definec
    usqrt
    (x :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x)
      x
      (
        ite
        (
          unary-lt
          x
          (
            unary-mul
            (
              usucc
              (
                usqrt
                (tail x)
              )
            )
            (
              usucc
              (
                usqrt
                (tail x)
              )
            )
          )
        )
        (
          usqrt
          (tail x)
        )
        (
          usucc
          (
            usqrt
            (tail x)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/vampire-square-root.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:12:26)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 21.26)
  (tgt-validation-time 5.01)
  (total-solve-time 16.25)
    (parse-time 0.00)
    (init-tool-time 2.80)
    (solver-time 13.44)