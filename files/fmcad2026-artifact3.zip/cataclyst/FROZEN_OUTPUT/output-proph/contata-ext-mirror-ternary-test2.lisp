; Synthesized functions:
(
  (
    definec
    mirror
    (tr :ttree)
    :ttree
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      'leaf
      (
        list
        (
          mirror
          (tt-right tr)
        )
        (tt-value tr)
        (
          mirror
          (tt-middle tr)
        )
        (
          mirror
          (tt-left tr)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-ext-mirror-ternary-test2.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:57:46)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 50.23)
  (tgt-validation-time 5.34)
  (total-solve-time 44.89)
    (parse-time 0.00)
    (init-tool-time 2.22)
    (solver-time 42.66)