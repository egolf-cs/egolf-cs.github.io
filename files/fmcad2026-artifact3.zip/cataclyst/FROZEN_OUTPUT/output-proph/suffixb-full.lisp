; Synthesized functions:
(
  (
    definec
    suffixb
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (equal ys xs)
      t
      (
        if
        (endp ys)
        ()
        (
          suffixb
          xs
          (tail ys)
        )
      )
    )
  )
  (
    definec
    prefix
    (xs :int-list ys :int-list)
    :int-list-option
    :skip-admissibilityp
    t
    (
      if
      (equal ys xs)
      ()
      (
        if
        (endp ys)
        ()
        (
          cons-opt
          (head ys)
          (
            prefix
            xs
            (tail ys)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/suffixb-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:08:51)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 91.14)
  (tgt-validation-time 7.12)
  (total-solve-time 84.02)
    (parse-time 0.00)
    (init-tool-time 0.96)
    (solver-time 83.06)