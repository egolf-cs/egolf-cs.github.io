; Synthesized functions:
(
  (
    definec
    my-rev
    (xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        append
        (
          my-rev
          (tail xs)
        )
        (
          cons
          (head xs)
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-list-rev-twice.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:51:35)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 12.20)
  (tgt-validation-time 1.95)
  (total-solve-time 10.25)
    (parse-time 0.00)
    (init-tool-time 0.36)
    (solver-time 9.88)