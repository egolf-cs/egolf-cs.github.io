; Synthesized functions:
(
  (
    definec
    has-path-sum
    (tr :bintree n :int)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      (equal n 0)
      (
        or
        (
          has-path-sum
          (bt-left tr)
          (
            -
            n
            (bt-value tr)
          )
        )
        (
          has-path-sum
          (bt-right tr)
          (
            -
            n
            (bt-value tr)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/tree-sum-path-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:02:26)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 63.86)
  (tgt-validation-time 7.72)
  (total-solve-time 56.14)
    (parse-time 0.05)
    (init-tool-time 3.37)
    (solver-time 52.72)