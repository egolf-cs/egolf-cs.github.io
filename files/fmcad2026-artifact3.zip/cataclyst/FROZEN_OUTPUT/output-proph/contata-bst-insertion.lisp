; Synthesized functions:
(
  (
    definec
    contata-insert
    (x :int tr :bintree)
    :bintree
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      (list 'leaf x 'leaf)
      (
        if
        (
          <
          x
          (bt-value tr)
        )
        (
          list
          (
            contata-insert
            x
            (bt-left tr)
          )
          (bt-value tr)
          (bt-right tr)
        )
        (
          list
          (bt-left tr)
          (bt-value tr)
          (
            contata-insert
            x
            (bt-right tr)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-bst-insertion.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:26:05)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 77.08)
  (tgt-validation-time 27.20)
  (total-solve-time 49.89)
    (parse-time 0.01)
    (init-tool-time 12.95)
    (solver-time 36.93)