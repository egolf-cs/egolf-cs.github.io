; Synthesized functions:
(
  (
    definec
    ones
    (xs :bit-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (
          szerop
          (head xs)
        )
        ()
        (
          ones
          (tail xs)
        )
      )
    )
  )
  (
    definec
    monotonic
    (xs :bit-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (
          szerop
          (head xs)
        )
        (
          monotonic
          (tail xs)
        )
        (ones xs)
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/monotonic-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:58:16)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 28.65)
  (tgt-validation-time 4.64)
  (total-solve-time 24.01)
    (parse-time 0.00)
    (init-tool-time 0.98)
    (solver-time 23.02)