; Synthesized functions:
(
  (
    definec
    pairs
    (xs :int-list)
    :int-pair-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          endp
          (tail xs)
        )
        ()
        (
          cons
          (
            list
            (head xs)
            (
              head
              (tail xs)
            )
          )
          (
            pairs
            (
              tail
              (tail xs)
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-pairs.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:51:49)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 14.23)
  (tgt-validation-time 3.09)
  (total-solve-time 11.14)
    (parse-time 0.00)
    (init-tool-time 1.48)
    (solver-time 9.67)