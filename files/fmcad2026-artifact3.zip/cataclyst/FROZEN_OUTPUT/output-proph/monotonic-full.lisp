; Synthesized functions:
(
  (
    definec
    ones
    (xs :bit-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (
          szerop
          (head xs)
        )
        ()
        (
          ones
          (tail xs)
        )
      )
    )
  )
  (
    definec
    monotonic
    (xs :bit-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (
          szerop
          (head xs)
        )
        (
          monotonic
          (tail xs)
        )
        (ones xs)
      )
    )
  )
  (
    definec
    pre-n
    (xs :bit-list)
    :nat
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      0
      (
        if
        (
          szerop
          (head xs)
        )
        (
          1+
          (
            pre-n
            (tail xs)
          )
        )
        (
          pre-n
          (tail xs)
        )
      )
    )
  )
  (
    definec
    suf-n
    (xs :bit-list pre-n :nat)
    :nat
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      0
      (
        if
        (
          szerop
          (head xs)
        )
        (
          suf-n
          (tail xs)
          pre-n
        )
        (
          1+
          (
            suf-n
            (tail xs)
            pre-n
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/monotonic-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:06:05)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 89.71)
  (tgt-validation-time 7.04)
  (total-solve-time 82.68)
    (parse-time 0.00)
    (init-tool-time 1.27)
    (solver-time 81.40)