; Synthesized functions:
(
  (
    definec
    tree-size-forest-size-wrapper
    (args :tree-size-forest-size-args)
    :tree-size-forest-size-ret
    :skip-admissibilityp
    t
    (
      match
      args
      (
        ('tree-size-args x)
        (
          if
          (itemptyp x)
          0
          (
            1+
            (
              tree-size-forest-size-wrapper
              (
                forest-size-args
                (itchildren x)
              )
            )
          )
        )
      )
      (
        ('forest-size-args x1)
        (
          if
          (ifnilp x1)
          0
          (
            +
            (
              tree-size-forest-size-wrapper
              (
                tree-size-args
                (ifhead x1)
              )
            )
            (
              tree-size-forest-size-wrapper
              (
                forest-size-args
                (iftail x1)
              )
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-tree-forest-size.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:44:04)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 57.45)
  (tgt-validation-time 10.59)
  (total-solve-time 46.86)
    (parse-time 0.01)
    (init-tool-time 3.63)
    (solver-time 43.22)