; Synthesized functions:
(
  (
    definec
    mirror
    (x :bintree)
    :bintree
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      'leaf
      (
        list
        (
          mirror
          (bt-right x)
        )
        (bt-value x)
        (
          mirror
          (bt-left x)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-ext-mirror-tree-test.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:55:46)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 23.42)
  (tgt-validation-time 4.41)
  (total-solve-time 19.01)
    (parse-time 0.01)
    (init-tool-time 1.71)
    (solver-time 17.29)