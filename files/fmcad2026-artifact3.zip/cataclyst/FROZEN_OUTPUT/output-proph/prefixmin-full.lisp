; Synthesized functions:
(
  (
    definec
    prefix-min
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        t
        (
          if
          (
            <
            x
            (head xs)
          )
          (
            prefix-min
            x
            (tail xs)
          )
          ()
        )
      )
    )
  )
  (
    definec
    index-of
    (x :int xs :int-list)
    :nat
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      0
      (
        if
        (
          equal
          (head xs)
          x
        )
        0
        (
          1+
          (
            index-of
            x
            (tail xs)
          )
        )
      )
    )
  )
  (
    definec
    anti-index
    (x :int xs :int-list)
    :nat
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      0
      (
        if
        (
          <
          (head xs)
          x
        )
        0
        (
          1+
          (
            anti-index
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/prefixmin-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:03:39)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 72.50)
  (tgt-validation-time 12.04)
  (total-solve-time 60.46)
    (parse-time 0.00)
    (init-tool-time 0.57)
    (solver-time 59.88)