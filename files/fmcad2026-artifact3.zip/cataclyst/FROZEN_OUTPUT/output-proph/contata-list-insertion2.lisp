; Synthesized functions:
(
  (
    definec
    contata-list-insertion
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (cons 0 ())
      (
        cons
        (head xs)
        (
          contata-list-insertion
          0
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-list-insertion2.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:21:53)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 10.09)
  (tgt-validation-time 2.25)
  (total-solve-time 7.85)
    (parse-time 0.00)
    (init-tool-time 0.42)
    (solver-time 7.42)