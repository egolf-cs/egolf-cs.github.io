; Synthesized functions:
(
  (
    definec
    is-even-is-odd-wrapper
    (args :is-even-is-odd-args)
    :is-even-is-odd-ret
    :skip-admissibilityp
    t
    (
      match
      args
      (
        ('is-even-args x)
        (
          if
          (endp x)
          t
          (
            is-even-is-odd-wrapper
            (
              is-odd-args
              (tail x)
            )
          )
        )
      )
      (
        ('is-odd-args x)
        (
          if
          (endp x)
          ()
          (
            is-even-is-odd-wrapper
            (
              is-even-args
              (tail x)
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-even-odd2.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:46:28)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 24.02)
  (tgt-validation-time 4.77)
  (total-solve-time 19.25)
    (parse-time 0.00)
    (init-tool-time 2.42)
    (solver-time 16.83)