; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-prefixmin-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_14:43:47)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 38.49)
  (tgt-validation-time 0.00)
  (total-solve-time 38.49)
    (parse-time 0.01)
    (init-tool-time 0.57)
    (solver-time 37.91)