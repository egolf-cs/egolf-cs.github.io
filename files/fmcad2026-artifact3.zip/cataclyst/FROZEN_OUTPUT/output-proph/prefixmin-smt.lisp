; Synthesized functions:
(
  (
    definec
    prefix-min
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        t
        (
          if
          (
            <
            x
            (head xs)
          )
          (
            prefix-min
            x
            (tail xs)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/prefixmin-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:59:57)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 24.15)
  (tgt-validation-time 3.54)
  (total-solve-time 20.61)
    (parse-time 0.00)
    (init-tool-time 0.48)
    (solver-time 20.13)