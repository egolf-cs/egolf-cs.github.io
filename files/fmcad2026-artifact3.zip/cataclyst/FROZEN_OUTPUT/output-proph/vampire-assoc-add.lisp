; Synthesized functions:
(
  (
    definec
    reassoc
    (x :unary y :unary z :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp y)
      z
      (
        usucc
        (
          reassoc
          x
          z
          (tail y)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/vampire-assoc-add.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:09:22)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 31.02)
  (tgt-validation-time 3.31)
  (total-solve-time 27.72)
    (parse-time 0.01)
    (init-tool-time 1.33)
    (solver-time 26.37)