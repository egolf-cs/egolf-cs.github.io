; Synthesized functions:
(
  (
    definec
    contains
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        t
        (
          contains
          x
          (tail xs)
        )
      )
    )
  )
  (
    definec
    index-of
    (x :int xs :int-list)
    :nat
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      0
      (
        if
        (
          equal
          (head xs)
          x
        )
        0
        (
          1+
          (
            index-of
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/index-of-contains-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:04:34)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 55.54)
  (tgt-validation-time 5.98)
  (total-solve-time 49.57)
    (parse-time 0.00)
    (init-tool-time 0.51)
    (solver-time 49.05)