; Synthesized functions:
(
  (
    definec
    mirror
    (tr :ttree)
    :ttree
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      'leaf
      (
        list
        (
          mirror
          (tt-right tr)
        )
        (tt-value tr)
        (
          mirror
          (tt-middle tr)
        )
        (
          mirror
          (tt-left tr)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-ext-mirror-ternary-test.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:56:56)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 44.66)
  (tgt-validation-time 4.77)
  (total-solve-time 39.89)
    (parse-time 0.01)
    (init-tool-time 2.29)
    (solver-time 37.59)