; Synthesized functions:
(
  (
    definec
    bt-depth
    (x :bintree)
    :int
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      0
      (
        1+
        (
          max
          (
            bt-depth
            (bt-right x)
          )
          (
            bt-depth
            (bt-left x)
          )
        )
      )
    )
  )
  (
    definec
    bt-cmp
    (x :bintree x1 :bintree)
    :compare
    :skip-admissibilityp
    t
    (
      int-cmp
      (bt-depth x)
      (bt-depth x1)
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-binary-tree-depth.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:47:14)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 26.70)
  (tgt-validation-time 4.93)
  (total-solve-time 21.77)
    (parse-time 0.00)
    (init-tool-time 1.52)
    (solver-time 20.25)