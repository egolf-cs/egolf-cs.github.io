; Synthesized functions:
(
  (
    definec
    btmax
    (tr :vtree)
    :int
    :skip-admissibilityp
    t
    (
      if
      (intp tr)
      (vt-leaf-val tr)
      (
        ite
        (
          <=
          (vt-node-val tr)
          (
            btmax
            (vt-left tr)
          )
        )
        (
          ite
          (
            <=
            (
              btmax
              (vt-left tr)
            )
            (
              btmax
              (vt-right tr)
            )
          )
          (
            btmax
            (vt-right tr)
          )
          (
            btmax
            (vt-left tr)
          )
        )
        (
          ite
          (
            <=
            (vt-node-val tr)
            (
              btmax
              (vt-right tr)
            )
          )
          (
            btmax
            (vt-right tr)
          )
          (vt-node-val tr)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/vampire-tree-max.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:13:41)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 62.28)
  (tgt-validation-time 11.27)
  (total-solve-time 51.01)
    (parse-time 0.03)
    (init-tool-time 7.95)
    (solver-time 43.03)