; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-contata-list-sort.acl2s)

(toolname proph)
(batchtime 2026-05-10_11:15:52)
(datetime 2026-05-10_11:17:39)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 65.92)
  (tgt-validation-time 0.00)
  (total-solve-time 65.92)
    (parse-time 0.00)
    (init-tool-time 1.99)
    (solver-time 63.93)