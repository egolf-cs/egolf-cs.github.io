; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-monotonic-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_14:45:07)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 63.16)
  (tgt-validation-time 0.00)
  (total-solve-time 63.16)
    (parse-time 0.01)
    (init-tool-time 1.41)
    (solver-time 61.75)