; Synthesized functions:
(
  (
    definec
    list-cmp
    (xs :int-list ys :int-list)
    :compare
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (
        if
        (endp ys)
        'cmp-eq
        'cmp-lt
      )
      (
        if
        (endp ys)
        'cmp-gt
        (
          if
          (
            <=
            (head xs)
            (head ys)
          )
          (
            if
            (
              <=
              (head ys)
              (head xs)
            )
            (
              list-cmp
              (tail xs)
              (tail ys)
            )
            'cmp-lt
          )
          'cmp-gt
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-ext-list-cmp.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:55:22)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 53.08)
  (tgt-validation-time 11.34)
  (total-solve-time 41.74)
    (parse-time 0.00)
    (init-tool-time 0.50)
    (solver-time 41.24)