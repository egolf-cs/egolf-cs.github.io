; Synthesized functions:
(
  (
    definec
    contains
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        t
        (
          contains
          x
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/index-of-contains-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:58:37)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 21.17)
  (tgt-validation-time 3.01)
  (total-solve-time 18.16)
    (parse-time 0.00)
    (init-tool-time 0.50)
    (solver-time 17.66)