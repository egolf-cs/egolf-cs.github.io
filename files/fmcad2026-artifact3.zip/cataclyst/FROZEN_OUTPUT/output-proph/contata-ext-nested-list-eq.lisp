; Synthesized functions:
(
  (
    definec
    nested-list-eq
    (xss :int-list-list yss :int-list-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xss)
      (endp yss)
      (
        if
        (endp yss)
        ()
        (
          if
          (
            list-eq
            (head yss)
            (head xss)
          )
          (
            nested-list-eq
            (tail xss)
            (tail yss)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-ext-nested-list-eq.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:54:00)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 28.74)
  (tgt-validation-time 4.98)
  (total-solve-time 23.75)
    (parse-time 0.01)
    (init-tool-time 1.26)
    (solver-time 22.49)