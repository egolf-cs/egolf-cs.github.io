; Synthesized functions:
(
  (
    definec
    nested-list-eq
    (xss :int-list-list yss :int-list-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xss)
      (endp xss)
      (
        if
        (endp yss)
        ()
        (
          if
          (
            list-eq
            (head yss)
            (head xss)
          )
          (
            nested-list-eq
            (tail xss)
            (tail xss)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-nested-list-eq.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:51:22)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 20.22)
  (tgt-validation-time 3.64)
  (total-solve-time 16.58)
    (parse-time 0.00)
    (init-tool-time 1.05)
    (solver-time 15.53)