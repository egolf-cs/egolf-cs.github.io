; Synthesized functions:
(
  (
    definec
    threshold-pairs
    (d :nat x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        and
        (
          threshold-pair
          d
          (head xs)
          x
        )
        (
          threshold-pairs
          d
          x
          (tail xs)
        )
      )
    )
  )
  (
    definec
    threshold-list
    (d :nat xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        and
        (
          threshold-pairs
          d
          (head xs)
          (tail xs)
        )
        (
          threshold-list
          d
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/threshold-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:00:33)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 35.22)
  (tgt-validation-time 5.80)
  (total-solve-time 29.42)
    (parse-time 0.00)
    (init-tool-time 1.54)
    (solver-time 27.88)