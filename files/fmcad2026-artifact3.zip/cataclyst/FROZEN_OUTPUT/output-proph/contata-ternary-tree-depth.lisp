; Synthesized functions:
(
  (
    definec
    tt-depth
    (x :ttree)
    :int
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      0
      (
        1+
        (
          max3
          (
            tt-depth
            (tt-right x)
          )
          (
            tt-depth
            (tt-left x)
          )
          (
            tt-depth
            (tt-middle x)
          )
        )
      )
    )
  )
  (
    definec
    tt-cmp
    (x :ttree x1 :ttree)
    :compare
    :skip-admissibilityp
    t
    (
      int-cmp
      (tt-depth x)
      (tt-depth x1)
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-ternary-tree-depth.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:48:00)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 45.71)
  (tgt-validation-time 6.00)
  (total-solve-time 39.71)
    (parse-time 0.00)
    (init-tool-time 2.18)
    (solver-time 37.52)