; Synthesized functions:
(
  (
    definec
    mk-prefix
    (xs :int-list suffix :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (equal suffix xs)
      ()
      (
        if
        (endp xs)
        ()
        (
          cons
          (head xs)
          (
            mk-prefix
            (tail xs)
            suffix
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/vampire-prefix-given-suffix.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:12:04)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 51.12)
  (tgt-validation-time 2.95)
  (total-solve-time 48.17)
    (parse-time 0.00)
    (init-tool-time 1.28)
    (solver-time 46.88)