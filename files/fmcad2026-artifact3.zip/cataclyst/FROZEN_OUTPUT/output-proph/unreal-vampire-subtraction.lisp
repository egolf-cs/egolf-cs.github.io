; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-vampire-subtraction.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_15:27:42)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 9.18)
  (tgt-validation-time 0.00)
  (total-solve-time 9.18)
    (parse-time 0.00)
    (init-tool-time 1.89)
    (solver-time 7.29)