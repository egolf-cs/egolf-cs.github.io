; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-index-of-contains-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_14:40:57)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 7.75)
  (tgt-validation-time 0.00)
  (total-solve-time 7.75)
    (parse-time 0.00)
    (init-tool-time 0.49)
    (solver-time 7.25)