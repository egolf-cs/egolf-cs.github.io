; Synthesized functions:
(
  (
    definec
    has-k-path
    (tr :bintree k :nat)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      (zp k)
      (
        if
        (zp k)
        ()
        (
          or
          (
            has-k-path
            (bt-left tr)
            (pred k)
          )
          (
            has-k-path
            (bt-right tr)
            (pred k)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/tree-k-path-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:01:21)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 47.92)
  (tgt-validation-time 6.32)
  (total-solve-time 41.60)
    (parse-time 0.00)
    (init-tool-time 3.62)
    (solver-time 37.98)