; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-monotonic-smt.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_14:40:49)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 33.49)
  (tgt-validation-time 0.00)
  (total-solve-time 33.49)
    (parse-time 0.00)
    (init-tool-time 0.97)
    (solver-time 32.52)