; Synthesized functions:
(
  (
    definec
    contata-insert-sort
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (cons x xs)
      (
        if
        (
          <=
          x
          (head xs)
        )
        (cons x xs)
        (
          cons
          (head xs)
          (
            contata-insert-sort
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-list-sort.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:22:34)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 22.04)
  (tgt-validation-time 4.86)
  (total-solve-time 17.18)
    (parse-time 0.00)
    (init-tool-time 1.97)
    (solver-time 15.21)