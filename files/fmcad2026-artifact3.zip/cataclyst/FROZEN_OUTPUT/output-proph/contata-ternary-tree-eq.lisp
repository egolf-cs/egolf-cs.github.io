; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-ternary-tree-eq.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:43:06)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 906.27)
  (tgt-validation-time 4.74)
  (total-solve-time 901.53)
    (parse-time 0.00)
    (init-tool-time 1.52)
    (solver-time 900.01)