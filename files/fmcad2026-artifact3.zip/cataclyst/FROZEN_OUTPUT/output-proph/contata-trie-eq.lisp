; Synthesized functions:
(
  (
    definec
    trie-eq
    (t1 :trie t2 :trie)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (atom t1)
      (atom t2)
      (
        if
        (atom t2)
        ()
        (
          if
          (
            equal
            (trie-value t2)
            (trie-value t1)
          )
          (
            and
            (
              trie-eq
              (trie-left t1)
              (trie-left t1)
            )
            (
              trie-eq
              (trie-left t1)
              (trie-left t2)
            )
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-trie-eq.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:27:59)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 113.18)
  (tgt-validation-time 4.20)
  (total-solve-time 108.98)
    (parse-time 0.00)
    (init-tool-time 1.20)
    (solver-time 107.78)