; Synthesized functions:
(
  (
    definec
    mirror
    (x :bintree)
    :bintree
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      'leaf
      (
        list
        (
          mirror
          (bt-right x)
        )
        (bt-value x)
        (
          mirror
          (bt-left x)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-mirror-tree-test.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:49:39)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 17.74)
  (tgt-validation-time 2.51)
  (total-solve-time 15.23)
    (parse-time 0.00)
    (init-tool-time 1.10)
    (solver-time 14.12)