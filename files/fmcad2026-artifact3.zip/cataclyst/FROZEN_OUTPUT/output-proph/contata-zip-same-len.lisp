; Synthesized functions:
(
  (
    definec
    my-zip
    (xs :int-list ys :int-list)
    :int-pair-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (endp ys)
        ()
        (
          cons
          (
            list
            (head xs)
            (head ys)
          )
          (
            my-zip
            (tail xs)
            (tail ys)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-zip-same-len.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:53:30)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 101.15)
  (tgt-validation-time 2.97)
  (total-solve-time 98.18)
    (parse-time 0.00)
    (init-tool-time 0.95)
    (solver-time 97.22)