; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-index-of-contains-full.acl2s)

(toolname proph)
(batchtime 2026-05-10_14:38:14)
(datetime 2026-05-10_14:44:04)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.33)
  (tgt-validation-time 0.00)
  (total-solve-time 16.33)
    (parse-time 0.00)
    (init-tool-time 0.62)
    (solver-time 15.70)