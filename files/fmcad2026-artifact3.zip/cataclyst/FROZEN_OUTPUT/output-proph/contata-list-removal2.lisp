; Synthesized functions:
(
  (
    definec
    contata-remove
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        (
          contata-remove
          x
          (tail xs)
        )
        (
          cons
          (head xs)
          (
            contata-remove
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-list-removal2.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:23:10)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 21.25)
  (tgt-validation-time 2.67)
  (total-solve-time 18.58)
    (parse-time 0.00)
    (init-tool-time 0.52)
    (solver-time 18.06)