; Synthesized functions:
(
  (
    definec
    contata-list-insertion
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (cons x ())
      (
        cons
        (head xs)
        (
          contata-list-insertion
          x
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-list-insertion3.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:22:48)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 13.86)
  (tgt-validation-time 2.25)
  (total-solve-time 11.61)
    (parse-time 0.00)
    (init-tool-time 0.42)
    (solver-time 11.18)