; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-contata-mirror-ternary-test2.acl2s)

(toolname proph)
(batchtime 2026-05-10_11:15:52)
(datetime 2026-05-10_12:29:13)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 164.03)
  (tgt-validation-time 0.00)
  (total-solve-time 164.03)
    (parse-time 0.00)
    (init-tool-time 1.43)
    (solver-time 162.60)