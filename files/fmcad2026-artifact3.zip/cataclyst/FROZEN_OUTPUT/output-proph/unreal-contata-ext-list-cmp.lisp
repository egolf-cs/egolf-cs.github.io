; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/unreal-contata-ext-list-cmp.acl2s)

(toolname proph)
(batchtime 2026-05-10_11:15:52)
(datetime 2026-05-10_12:30:54)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 26.25)
  (tgt-validation-time 0.00)
  (total-solve-time 26.25)
    (parse-time 0.01)
    (init-tool-time 0.49)
    (solver-time 25.74)