; Synthesized functions:
(
  (
    definec
    double
    (x :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x)
      x
      (
        usucc
        (
          usucc
          (
            double
            (tail x)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/vampire-double.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_11:10:17)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 7.82)
  (tgt-validation-time 3.14)
  (total-solve-time 4.68)
    (parse-time 0.00)
    (init-tool-time 1.56)
    (solver-time 3.11)