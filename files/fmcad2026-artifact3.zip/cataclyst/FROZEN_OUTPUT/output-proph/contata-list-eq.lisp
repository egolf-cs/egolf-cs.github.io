; Synthesized functions:
(
  (
    definec
    list-eq
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (endp xs)
      (
        if
        (endp ys)
        ()
        (
          if
          (
            equal
            (head ys)
            (head xs)
          )
          (
            list-eq
            (tail xs)
            (tail xs)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-proph/contata-list-eq.acl2s)

(toolname proph)
(batchtime 2026-05-10_10:21:31)
(datetime 2026-05-10_10:48:25)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 24.41)
  (tgt-validation-time 2.89)
  (total-solve-time 21.52)
    (parse-time 0.00)
    (init-tool-time 0.43)
    (solver-time 21.09)