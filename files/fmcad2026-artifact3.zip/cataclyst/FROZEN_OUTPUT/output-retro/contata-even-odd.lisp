; Synthesized functions:
(
  (
    definec
    is-even-is-odd-wrapper
    (args :is-even-is-odd-args)
    :is-even-is-odd-ret
    :skip-admissibilityp
    t
    (
      match
      args
      (
        ('is-even-args x)
        (
          if
          (endp x)
          t
          (
            is-even-is-odd-wrapper
            (
              is-odd-args
              (tail x)
            )
          )
        )
      )
      (
        ('is-odd-args x)
        (
          if
          (endp x)
          ()
          (
            is-even-is-odd-wrapper
            (
              is-even-args
              (tail x)
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-even-odd.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:29:46)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 24.42)
  (tgt-validation-time 4.72)
  (total-solve-time 19.70)
    (parse-time 0.00)
    (init-tool-time 2.36)
    (solver-time 17.34)