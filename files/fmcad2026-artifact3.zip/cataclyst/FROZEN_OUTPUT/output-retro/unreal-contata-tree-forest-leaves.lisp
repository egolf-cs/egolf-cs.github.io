; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-contata-tree-forest-leaves.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_01:11:03)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 161.41)
  (tgt-validation-time 0.00)
  (total-solve-time 161.41)
    (parse-time 0.02)
    (init-tool-time 4.08)
    (solver-time 157.31)