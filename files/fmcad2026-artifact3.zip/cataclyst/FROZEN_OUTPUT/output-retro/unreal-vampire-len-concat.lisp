; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-vampire-len-concat.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_13:03:02)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.79)
  (tgt-validation-time 0.00)
  (total-solve-time 16.79)
    (parse-time 0.00)
    (init-tool-time 0.46)
    (solver-time 16.33)