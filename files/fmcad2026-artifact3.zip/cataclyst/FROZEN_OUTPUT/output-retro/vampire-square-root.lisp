; Synthesized functions:
(
  (
    definec
    usqrt
    (x :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x)
      x
      (
        ite
        (
          unary-lt
          x
          (
            unary-mul
            (
              usucc
              (
                usqrt
                (tail x)
              )
            )
            (
              usucc
              (
                usqrt
                (tail x)
              )
            )
          )
        )
        (
          usqrt
          (tail x)
        )
        (
          usucc
          (
            usqrt
            (tail x)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-square-root.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:45:17)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 22.04)
  (tgt-validation-time 5.34)
  (total-solve-time 16.70)
    (parse-time 0.00)
    (init-tool-time 2.90)
    (solver-time 13.80)