; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/prefixb-full.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:03:27)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 906.56)
  (tgt-validation-time 6.11)
  (total-solve-time 900.45)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 900.01)