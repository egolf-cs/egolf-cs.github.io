; Synthesized functions:
(
  (
    definec
    mk-prefix
    (xs :int-list suffix :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (equal suffix xs)
      ()
      (
        if
        (endp xs)
        ()
        (
          cons
          (head xs)
          (
            mk-prefix
            (tail xs)
            suffix
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-prefix-given-suffix.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:44:32)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 67.03)
  (tgt-validation-time 2.98)
  (total-solve-time 64.05)
    (parse-time 0.00)
    (init-tool-time 1.20)
    (solver-time 62.85)