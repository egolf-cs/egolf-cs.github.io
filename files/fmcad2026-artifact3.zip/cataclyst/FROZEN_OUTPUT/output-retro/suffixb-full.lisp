; Synthesized functions:
(
  (
    definec
    suffixb
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (equal ys xs)
      t
      (
        if
        (endp ys)
        ()
        (
          suffixb
          xs
          (tail ys)
        )
      )
    )
  )
  (
    definec
    prefix
    (xs :int-list ys :int-list)
    :int-list-option
    :skip-admissibilityp
    t
    (
      if
      (equal ys xs)
      ()
      (
        if
        (endp ys)
        ()
        (
          cons-opt
          (head ys)
          (
            prefix
            xs
            (tail ys)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/suffixb-full.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:33:43)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 905.64)
  (tgt-validation-time 7.36)
  (total-solve-time 898.28)
    (parse-time 0.00)
    (init-tool-time 1.04)
    (solver-time 897.24)