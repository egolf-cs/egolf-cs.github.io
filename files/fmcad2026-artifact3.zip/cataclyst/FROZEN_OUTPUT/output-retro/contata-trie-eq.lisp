; Synthesized functions:
(
  (
    definec
    trie-eq
    (t1 :trie t2 :trie)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (atom t1)
      (atom t2)
      (
        if
        (atom t2)
        ()
        (
          if
          (
            equal
            (trie-value t2)
            (trie-value t1)
          )
          (
            and
            (
              trie-eq
              (trie-left t1)
              (trie-left t1)
            )
            (
              trie-eq
              (trie-left t1)
              (trie-left t2)
            )
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-trie-eq.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:50:18)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 423.73)
  (tgt-validation-time 4.22)
  (total-solve-time 419.51)
    (parse-time 0.00)
    (init-tool-time 1.18)
    (solver-time 418.33)