; Synthesized functions:
(
  (
    definec
    has-path-sum
    (tr :bintree n :int)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      (equal n 0)
      (
        or
        (
          has-path-sum
          (bt-left tr)
          (
            -
            n
            (bt-value tr)
          )
        )
        (
          has-path-sum
          (bt-right tr)
          (
            -
            n
            (bt-value tr)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/tree-sum-path-smt.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:54:01)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 78.33)
  (tgt-validation-time 7.87)
  (total-solve-time 70.46)
    (parse-time 0.00)
    (init-tool-time 3.68)
    (solver-time 66.78)