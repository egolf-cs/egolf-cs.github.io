; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-ternary-tree-eq.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:20:31)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 906.28)
  (tgt-validation-time 4.72)
  (total-solve-time 901.56)
    (parse-time 0.00)
    (init-tool-time 1.55)
    (solver-time 900.01)