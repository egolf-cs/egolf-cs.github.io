; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-contata-list-insertion3.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-10_22:31:14)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 17.17)
  (tgt-validation-time 0.00)
  (total-solve-time 17.17)
    (parse-time 0.00)
    (init-tool-time 0.43)
    (solver-time 16.73)