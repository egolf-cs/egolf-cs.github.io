; Synthesized functions:
(
  (
    definec
    udiv
    (x1 :unary x2 :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x1)
      x1
      (
        ite
        (
          equal
          x1
          (
            unary-mul
            x2
            (
              usucc
              (
                udiv
                (tail x1)
                x2
              )
            )
          )
        )
        (
          usucc
          (
            udiv
            (tail x1)
            x2
          )
        )
        (
          udiv
          (tail x1)
          x2
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-division.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:37:18)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 44.49)
  (tgt-validation-time 5.80)
  (total-solve-time 38.69)
    (parse-time 0.00)
    (init-tool-time 2.96)
    (solver-time 35.72)