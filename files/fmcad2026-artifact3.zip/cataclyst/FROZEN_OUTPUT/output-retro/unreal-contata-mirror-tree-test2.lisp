; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-contata-mirror-tree-test2.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_04:12:13)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 776.40)
  (tgt-validation-time 0.00)
  (total-solve-time 776.40)
    (parse-time 0.00)
    (init-tool-time 1.26)
    (solver-time 775.14)