; Synthesized functions:
(
  (
    definec
    binary-tree-eq
    (t1 :bintree t2 :bintree)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (atom t1)
      (atom t2)
      (
        if
        (atom t2)
        ()
        (
          if
          (
            equal
            (bt-value t2)
            (bt-value t1)
          )
          (
            and
            (
              binary-tree-eq
              (bt-left t1)
              (bt-left t2)
            )
            (
              binary-tree-eq
              (bt-right t1)
              (bt-right t2)
            )
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-binary-tree-eq.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:23:17)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 266.13)
  (tgt-validation-time 4.56)
  (total-solve-time 261.57)
    (parse-time 0.00)
    (init-tool-time 1.18)
    (solver-time 260.39)