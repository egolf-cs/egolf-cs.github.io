; Synthesized functions:
(
  (
    definec
    list-eq
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (endp xs)
      (
        if
        (endp ys)
        ()
        (
          if
          (
            equal
            (head ys)
            (head xs)
          )
          (
            list-eq
            (tail xs)
            (tail xs)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-list-eq.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:37:19)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 26.08)
  (tgt-validation-time 2.93)
  (total-solve-time 23.15)
    (parse-time 0.00)
    (init-tool-time 0.43)
    (solver-time 22.72)