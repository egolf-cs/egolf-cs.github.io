; Synthesized functions:
(
  (
    definec
    ilevens-ilodds-wrapper
    (args :ilevens-ilodds-args)
    :ilevens-ilodds-ret
    :skip-admissibilityp
    t
    (
      match
      args
      (
        ('ilevens-args x)
        (
          if
          (endp x)
          ()
          (
            cons
            (head x)
            (
              ilevens-ilodds-wrapper
              (
                ilodds-args
                (tail x)
              )
            )
          )
        )
      )
      (
        ('ilodds-args x)
        (
          if
          (endp x)
          ()
          (
            ilevens-ilodds-wrapper
            (
              ilevens-args
              (tail x)
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-evens-odds.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:28:44)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 38.58)
  (tgt-validation-time 4.28)
  (total-solve-time 34.31)
    (parse-time 0.01)
    (init-tool-time 2.19)
    (solver-time 32.11)