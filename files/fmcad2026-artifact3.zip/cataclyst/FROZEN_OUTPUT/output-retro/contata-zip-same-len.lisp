; Synthesized functions:
(
  (
    definec
    my-zip
    (xs :int-list ys :int-list)
    :int-pair-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (endp ys)
        ()
        (
          cons
          (
            list
            (head xs)
            (head ys)
          )
          (
            my-zip
            (tail xs)
            (tail ys)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-zip-same-len.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:10:11)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 32.27)
  (tgt-validation-time 2.94)
  (total-solve-time 29.33)
    (parse-time 0.00)
    (init-tool-time 0.76)
    (solver-time 28.57)