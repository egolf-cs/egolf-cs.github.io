; Synthesized functions:
(
  (
    definec
    mirror
    (tr :ttree)
    :ttree
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      'leaf
      (
        list
        (
          mirror
          (tt-right tr)
        )
        (tt-value tr)
        (
          mirror
          (tt-middle tr)
        )
        (
          mirror
          (tt-left tr)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-ext-mirror-ternary-test.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:40:08)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 46.96)
  (tgt-validation-time 4.80)
  (total-solve-time 42.16)
    (parse-time 0.00)
    (init-tool-time 2.29)
    (solver-time 39.86)