; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/monotonic-full.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_20:33:12)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 910.12)
  (tgt-validation-time 8.43)
  (total-solve-time 901.70)
    (parse-time 0.01)
    (init-tool-time 1.69)
    (solver-time 900.01)