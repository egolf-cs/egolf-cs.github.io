; Synthesized functions:
(
  (
    definec
    prefix-min
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        t
        (
          if
          (
            <
            x
            (head xs)
          )
          (
            prefix-min
            x
            (tail xs)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/prefixmin-smt.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_19:06:14)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 25.46)
  (tgt-validation-time 3.56)
  (total-solve-time 21.90)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 21.46)