; Synthesized functions:
(
  (
    definec
    my-rev
    (xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        append
        (
          my-rev
          (tail xs)
        )
        (
          cons
          (head xs)
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-list-rev-twice.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:06:36)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 12.37)
  (tgt-validation-time 1.90)
  (total-solve-time 10.46)
    (parse-time 0.00)
    (init-tool-time 0.38)
    (solver-time 10.08)