; Synthesized functions:
(
  (
    definec
    contata-list-insertion
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (cons x ())
      (
        cons
        (head xs)
        (
          contata-list-insertion
          x
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-list-insertion3.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:02:59)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 13.08)
  (tgt-validation-time 2.30)
  (total-solve-time 10.78)
    (parse-time 0.00)
    (init-tool-time 0.47)
    (solver-time 10.31)