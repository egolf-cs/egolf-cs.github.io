; Synthesized functions:
(
  (
    definec
    sub
    (x1 :unary x2 :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp x2)
      x1
      (
        if
        (endp x1)
        x1
        (
          sub
          x2
          (tail x1)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-subtraction.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:45:46)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 12.67)
  (tgt-validation-time 3.78)
  (total-solve-time 8.89)
    (parse-time 0.00)
    (init-tool-time 1.89)
    (solver-time 7.00)