; Synthesized functions:
(
  (
    definec
    btmax
    (tr :vtree)
    :int
    :skip-admissibilityp
    t
    (
      if
      (intp tr)
      (vt-leaf-val tr)
      (
        ite
        (
          <=
          (vt-node-val tr)
          (
            btmax
            (vt-left tr)
          )
        )
        (
          ite
          (
            <=
            (
              btmax
              (vt-left tr)
            )
            (
              btmax
              (vt-right tr)
            )
          )
          (
            btmax
            (vt-right tr)
          )
          (
            btmax
            (vt-left tr)
          )
        )
        (
          ite
          (
            <=
            (vt-node-val tr)
            (
              btmax
              (vt-right tr)
            )
          )
          (
            btmax
            (vt-right tr)
          )
          (vt-node-val tr)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-tree-max.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_22:00:12)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 64.24)
  (tgt-validation-time 11.69)
  (total-solve-time 52.54)
    (parse-time 0.00)
    (init-tool-time 8.37)
    (solver-time 44.17)