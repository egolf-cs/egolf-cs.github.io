; Synthesized functions:
(
  (
    definec
    contata-insert-sort
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (cons x xs)
      (
        if
        (
          <=
          x
          (head xs)
        )
        (cons x xs)
        (
          cons
          (head xs)
          (
            contata-insert-sort
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-list-sort.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:02:31)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 23.07)
  (tgt-validation-time 5.04)
  (total-solve-time 18.03)
    (parse-time 0.00)
    (init-tool-time 2.06)
    (solver-time 15.97)