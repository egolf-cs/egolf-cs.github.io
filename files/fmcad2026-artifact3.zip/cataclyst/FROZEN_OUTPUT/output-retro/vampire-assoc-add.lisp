; Synthesized functions:
(
  (
    definec
    reassoc
    (x :unary y :unary z :unary)
    :unary
    :skip-admissibilityp
    t
    (
      if
      (endp y)
      z
      (
        usucc
        (
          reassoc
          x
          z
          (tail y)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-assoc-add.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:34:45)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 29.92)
  (tgt-validation-time 3.49)
  (total-solve-time 26.44)
    (parse-time 0.00)
    (init-tool-time 1.36)
    (solver-time 25.07)