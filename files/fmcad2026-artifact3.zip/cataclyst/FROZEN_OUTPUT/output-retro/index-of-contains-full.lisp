; Synthesized functions:
(
  (
    definec
    contains
    (x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        t
        (
          contains
          x
          (tail xs)
        )
      )
    )
  )
  (
    definec
    index-of
    (x :int xs :int-list)
    :nat
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      0
      (
        if
        (
          equal
          (head xs)
          x
        )
        0
        (
          1+
          (
            index-of
            x
            (tail xs)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/index-of-contains-full.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_20:02:51)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 661.58)
  (tgt-validation-time 6.58)
  (total-solve-time 655.00)
    (parse-time 0.06)
    (init-tool-time 0.63)
    (solver-time 654.31)