; Synthesized functions:
(
  (
    definec
    lmax
    (l :int-list)
    :int
    :skip-admissibilityp
    t
    (
      if
      (endp l)
      0
      (
        if
        (
          endp
          (tail l)
        )
        (head l)
        (
          ite
          (
            <=
            (head l)
            (
              lmax
              (tail l)
            )
          )
          (
            lmax
            (tail l)
          )
          (head l)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-list-max.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:40:02)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 32.32)
  (tgt-validation-time 4.80)
  (total-solve-time 27.52)
    (parse-time 0.00)
    (init-tool-time 2.61)
    (solver-time 24.90)