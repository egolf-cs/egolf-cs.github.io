; Synthesized functions:
(
  (
    definec
    contata-remove
    (x :int xs :int-list)
    :int-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          equal
          (head xs)
          x
        )
        (
          contata-remove
          x
          (tail xs)
        )
        (
          cons
          (head xs)
          (contata-remove x ())
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-list-removal.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:01:33)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 19.92)
  (tgt-validation-time 2.50)
  (total-solve-time 17.42)
    (parse-time 0.00)
    (init-tool-time 0.48)
    (solver-time 16.94)