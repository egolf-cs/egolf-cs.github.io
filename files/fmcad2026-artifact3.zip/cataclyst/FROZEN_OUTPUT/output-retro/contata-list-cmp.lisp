; Synthesized functions:
(
  (
    definec
    list-cmp
    (xs :int-list ys :int-list)
    :compare
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      (
        if
        (endp ys)
        'cmp-eq
        'cmp-lt
      )
      (
        if
        (endp ys)
        'cmp-gt
        (
          if
          (
            <=
            (head xs)
            (head ys)
          )
          (
            if
            (
              <=
              (head ys)
              (head xs)
            )
            (
              list-cmp
              (tail xs)
              (tail xs)
            )
            'cmp-lt
          )
          'cmp-gt
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-list-cmp.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:57:19)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 287.75)
  (tgt-validation-time 11.06)
  (total-solve-time 276.69)
    (parse-time 0.00)
    (init-tool-time 0.49)
    (solver-time 276.19)