; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/prefixmin-full.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_19:36:41)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 913.28)
  (tgt-validation-time 12.64)
  (total-solve-time 900.65)
    (parse-time 0.00)
    (init-tool-time 0.64)
    (solver-time 900.01)