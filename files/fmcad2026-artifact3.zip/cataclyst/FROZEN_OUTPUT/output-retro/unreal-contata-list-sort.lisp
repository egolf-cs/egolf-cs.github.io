; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-contata-list-sort.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-10_22:30:33)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 676.61)
  (tgt-validation-time 0.00)
  (total-solve-time 676.61)
    (parse-time 0.00)
    (init-tool-time 2.06)
    (solver-time 674.55)