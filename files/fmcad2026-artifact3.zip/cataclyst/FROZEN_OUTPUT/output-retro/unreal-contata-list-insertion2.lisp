; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-contata-list-insertion2.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-10_22:03:29)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.93)
  (tgt-validation-time 0.00)
  (total-solve-time 16.93)
    (parse-time 0.00)
    (init-tool-time 0.43)
    (solver-time 16.50)