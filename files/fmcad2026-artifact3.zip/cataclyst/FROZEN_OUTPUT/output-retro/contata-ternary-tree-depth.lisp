; Synthesized functions:
(
  (
    definec
    tt-depth
    (x :ttree)
    :int
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      0
      (
        1+
        (
          max3
          (
            tt-depth
            (tt-right x)
          )
          (
            tt-depth
            (tt-left x)
          )
          (
            tt-depth
            (tt-middle x)
          )
        )
      )
    )
  )
  (
    definec
    tt-cmp
    (x :ttree x1 :ttree)
    :compare
    :skip-admissibilityp
    t
    (
      int-cmp
      (tt-depth x)
      (tt-depth x1)
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-ternary-tree-depth.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:35:18)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 46.30)
  (tgt-validation-time 6.09)
  (total-solve-time 40.21)
    (parse-time 0.00)
    (init-tool-time 2.25)
    (solver-time 37.95)