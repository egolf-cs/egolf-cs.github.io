; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-contata-pairs.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-11_05:13:52)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 9.60)
  (tgt-validation-time 0.00)
  (total-solve-time 9.60)
    (parse-time 0.01)
    (init-tool-time 1.86)
    (solver-time 7.73)