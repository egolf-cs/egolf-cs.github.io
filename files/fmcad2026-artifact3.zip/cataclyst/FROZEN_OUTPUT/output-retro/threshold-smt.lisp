; Synthesized functions:
(
  (
    definec
    threshold-pairs
    (d :nat x :int xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        and
        (
          threshold-pair
          d
          (head xs)
          x
        )
        (
          threshold-pairs
          d
          x
          (tail xs)
        )
      )
    )
  )
  (
    definec
    threshold-list
    (d :nat xs :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        and
        (
          threshold-pairs
          d
          (head xs)
          (tail xs)
        )
        (
          threshold-list
          d
          (tail xs)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/threshold-smt.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:49:41)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 35.26)
  (tgt-validation-time 5.82)
  (total-solve-time 29.43)
    (parse-time 0.00)
    (init-tool-time 1.56)
    (solver-time 27.87)