; Synthesized functions:
(
  (
    definec
    mirror
    (tr :ttree)
    :ttree
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      'leaf
      (
        list
        (tt-right tr)
        (tt-value tr)
        (
          mirror
          (tt-middle tr)
        )
        (tt-left tr)
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-mirror-ternary-test2.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:03:53)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 32.45)
  (tgt-validation-time 3.64)
  (total-solve-time 28.81)
    (parse-time 0.00)
    (init-tool-time 1.45)
    (solver-time 27.36)