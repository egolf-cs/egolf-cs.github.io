; Synthesized functions:
(
  (
    definec
    nested-list-eq
    (xss :int-list-list yss :int-list-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xss)
      (endp yss)
      (
        if
        (endp yss)
        ()
        (
          if
          (
            list-eq
            (head yss)
            (head xss)
          )
          (
            nested-list-eq
            (tail xss)
            (tail yss)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-ext-nested-list-eq.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:12:58)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 29.25)
  (tgt-validation-time 4.95)
  (total-solve-time 24.30)
    (parse-time 0.00)
    (init-tool-time 1.07)
    (solver-time 23.22)