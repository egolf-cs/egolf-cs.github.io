; Synthesized functions:
(
  (
    definec
    contata-insert
    (x :int tr :bintree)
    :bintree
    :skip-admissibilityp
    t
    (
      if
      (atom tr)
      (list 'leaf x 'leaf)
      (
        if
        (
          <
          x
          (bt-value tr)
        )
        (
          list
          (
            contata-insert
            x
            (bt-left tr)
          )
          (bt-value tr)
          (bt-right tr)
        )
        (
          list
          (bt-left tr)
          (bt-value tr)
          (
            contata-insert
            x
            (bt-right tr)
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-bst-insertion.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_16:28:08)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 77.68)
  (tgt-validation-time 27.46)
  (total-solve-time 50.22)
    (parse-time 0.00)
    (init-tool-time 13.21)
    (solver-time 37.00)