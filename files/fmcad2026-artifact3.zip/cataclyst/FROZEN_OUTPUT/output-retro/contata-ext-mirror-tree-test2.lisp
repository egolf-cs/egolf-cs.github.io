; Synthesized functions:
(
  (
    definec
    mirror
    (x :bintree)
    :bintree
    :skip-admissibilityp
    t
    (
      if
      (atom x)
      'leaf
      (
        list
        (
          mirror
          (bt-right x)
        )
        (bt-value x)
        (
          mirror
          (bt-left x)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-ext-mirror-tree-test2.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:37:19)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 25.17)
  (tgt-validation-time 5.10)
  (total-solve-time 20.07)
    (parse-time 0.00)
    (init-tool-time 1.70)
    (solver-time 18.37)