; Synthesized functions:
None
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/unreal-contata-bst-insertion.acl2s)

(toolname retro)
(batchtime 2026-05-10_22:02:09)
(datetime 2026-05-10_23:33:25)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? True)
(total-time 914.21)
  (tgt-validation-time 0.00)
  (total-solve-time 914.21)
    (parse-time 0.00)
    (init-tool-time 14.21)
    (solver-time 900.01)