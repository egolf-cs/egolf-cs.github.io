; Synthesized functions:
(
  (
    definec
    pairs
    (xs :int-list)
    :int-pair-list
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      ()
      (
        if
        (
          endp
          (tail xs)
        )
        ()
        (
          cons
          (
            list
            (head xs)
            (
              head
              (tail xs)
            )
          )
          (
            pairs
            (
              tail
              (tail xs)
            )
          )
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-pairs.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_18:07:41)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.56)
  (tgt-validation-time 3.06)
  (total-solve-time 13.50)
    (parse-time 0.00)
    (init-tool-time 1.50)
    (solver-time 12.00)