; Synthesized functions:
(
  (
    definec
    prefixb
    (xs :int-list ys :int-list)
    :bool
    :skip-admissibilityp
    t
    (
      if
      (endp xs)
      t
      (
        if
        (endp ys)
        ()
        (
          if
          (
            equal
            (head ys)
            (head xs)
          )
          (
            prefixb
            (tail xs)
            (tail ys)
          )
          ()
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/prefixb-smt.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_19:03:38)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 38.20)
  (tgt-validation-time 2.88)
  (total-solve-time 35.32)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 34.88)