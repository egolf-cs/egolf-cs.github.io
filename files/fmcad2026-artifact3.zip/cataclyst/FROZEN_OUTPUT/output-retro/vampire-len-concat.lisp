; Synthesized functions:
(
  (
    definec
    app-len
    (x :int-list y :int-list)
    :int
    :skip-admissibilityp
    t
    (
      if
      (endp y)
      (
        if
        (endp x)
        0
        (
          1+
          (
            app-len
            y
            (tail x)
          )
        )
      )
      (
        1+
        (
          app-len
          x
          (tail y)
        )
      )
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/vampire-len-concat.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_21:38:28)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 16.37)
  (tgt-validation-time 2.29)
  (total-solve-time 14.09)
    (parse-time 0.00)
    (init-tool-time 0.44)
    (solver-time 13.64)