; Synthesized functions:
(
  (
    definec
    insert
    (xs :sized-list x :int)
    :sized-list
    :skip-admissibilityp
    t
    (
      list
      (
        1+
        (get-size xs)
      )
      x
      xs
    )
  )
)
; ACL2S file located at
(acl2s-file-path /home/egolf/Projects/program-synthesis/next-artifact/cataclyst/output/output-retro/contata-sized-list.acl2s)

(toolname retro)
(batchtime 2026-05-10_16:00:05)
(datetime 2026-05-10_17:57:34)

; Note: we report total-solve-time in the paper.
; We do not include tgt-validation-time because
; it is for debugging purposes only.

(timeout? False)
(total-time 7.15)
  (tgt-validation-time 3.26)
  (total-solve-time 3.89)
    (parse-time 0.00)
    (init-tool-time 1.71)
    (solver-time 2.18)