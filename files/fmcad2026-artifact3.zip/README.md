# Cataclyst

This is the top-level README. Please see the inner README files.

- `cataclyst/README.md` gives more details about our inputs, outputs, how to
run the code, and how to check our mechanized proofs of correctness for the
synthesized programs produced by our tool.
- `vampire/README.md` gives more details about inputs to/outputs from Vampire
as well as how we run Vampire.
- `contata/README.md` gives more details about inputs to/outputs from Contata
as well as how we run Contata.

