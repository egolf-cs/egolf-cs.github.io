from itertools import product

class TransitionLabel:

    def __init__(self, symbol, sgn=None, wt=1):
        self.symbol = symbol
        self.sgn = sgn
        self.is_wait = (sgn == "?")
        self.is_join = (sgn == "!")
        self.wt = wt

    def __repr__(self):
        if self.is_wait:
            return f"{self.symbol}?,{self.wt}"
        if self.is_join:
            return f"{self.symbol}!,{self.wt}"
        return f"{self.symbol},{self.wt}"

    def __eq__(self,other):
        return repr(self) == repr(other)

    def __lt__(self,other):
        return repr(self) < repr(other)

    def __hash__(self):
        return hash(repr(self))

class StateLabel:

    def __init__(self, symbol, acc=False, init=False):
        self.symbol = symbol
        self.is_acc = acc
        self.is_init = init

    def __repr__(self):
        if self.is_init:
            return f"->{self.symbol}"
        else:
            return f"{self.symbol}"

    def __eq__(self,other):
        b0 = self.symbol == other.symbol
        b1 = self.is_acc == other.is_acc
        b2 = self.is_init == other.is_init

        return b1 and b0 and b2

    def __lt__(self,other):
        return repr(self) < repr(other)

    def __hash__(self):
        return hash(repr(self))

class System:

    def __init__(self, name, Q, delta):
        self.name = name
        self.Q = Q
        self.Q_0 = []
        self.F = []
        self.delta = delta
        for q in self.Q:
            if q.is_acc:
                self.F += [q]
            if q.is_init:
                self.Q_0 += [q]
        self.Q = reachable(self.delta, self.Q_0)
        self.F = [x for x in self.Q if x in self.F]

    def preds(self, q):
        return [p for p in self.delta if q in self.delta[p]]

    def succ_trans_input(self, q):
        res = []
        for r, ts in self.delta[q].items():
            for t in ts:
                if t.is_wait:
                    res.append((r,t.symbol))
        return res
    
    def succ_trans_output(self, q, symbol):
        res = []
        for r, ts in self.delta[q].items():
            for t in ts:
                if t.is_join and t.symbol == symbol:
                    res.append(r)
        return res
    
    def succ_trans_free(self, q):
        res = []
        for r, ts in self.delta[q].items():
            for t in ts:
                if not t.is_wait and not t.is_join:
                    res.append((r,t.symbol))
        return res
    
def reachable(delta, inits):
    res = [succ for i in inits for succ in delta[i]]
    res += inits
    res = set(res)
    if res == set(inits):
        return res
    else:
        return reachable(delta, res)

def delta2Q(delta):
    Q = set()
    for cntp, p in enumerate(delta):
        Q.add(p)
        for cntq, q in enumerate(delta[p]):
            Q.add(q)
    return Q

def mk_prod_label(a,b):
    return StateLabel((a.symbol, b.symbol), acc=a.is_acc or b.is_acc, init=a.is_init and b.is_init)

def add_prod_transition(p,q,symbol,sgn,delta,wt):
    if p not in delta:
        delta[p] = {}
    if q not in delta[p]:
        delta[p][q] = []
    t = TransitionLabel(symbol, sgn, wt)
    if t not in delta[p][q]:
        delta[p][q] += [t]
    return delta

def lproduct(xs):
    return list(product(*xs))

def prod_of_states_to_state(p):
    symbol = tuple([r.symbol for r in p])
    acc = False
    init = all(r.is_init for r in p)
    return StateLabel(symbol, acc=acc, init=init)

# returns list of tuple of StateLables (not list of StateLabels)
def mk_init_states(Ss):
    aux = [S.Q_0 for S in Ss]
    aux = lproduct(aux)
    # aux = [prod_of_states_to_state(a) for a in aux]
    return aux

def mk_transitions_aux0(ps, i, p, S):
    res = []
    free = S.succ_trans_free(p)
    for pr, a in free:
        psr = list(ps)
        psr[i] = pr
        res.append((ps, a, tuple(psr)))
    return res

def mk_transitions_aux1(S, T, p, q):
    res = []
    inputs = S.succ_trans_input(p)
    # pprint(inputs)
    for pr, a in inputs:
        outputs = T.succ_trans_output(q, a)
        # pprint(outputs)
        for qr in outputs:
            res.append((a, pr, qr))
    return res

def mk_transitions_aux2(ps, i, j, pr, qr, a):
    psr = list(ps)
    psr[i] = pr
    psr[j] = qr
    return ps, a, tuple(psr)

def mk_transitions(Ss, ps):
    res = []
    for i, p in enumerate(ps):
        S = Ss[i]
        res += mk_transitions_aux0(ps, i, p, S)
        for j, q in enumerate(ps):
            if i == j:
                continue
            T = Ss[j]
            aux = mk_transitions_aux1(S, T, p, q)
            for (a, pr, qr) in aux:
                res.append(
                    mk_transitions_aux2(ps, i, j, pr, qr, a))
    return res

def mk_multi_prod_ren(Ss):
    Q = []
    transitions = []
    queue = mk_init_states(Ss)
    while len(queue) > 0:
        curr = queue[0]
        queue = queue[1:]
        Q.append(curr)
        new_transitions = mk_transitions(Ss, curr)
        transitions += new_transitions
        for _, _, new_state in new_transitions:
            if new_state not in Q + queue:
                queue.append(new_state)
    

    Q = [prod_of_states_to_state(q) for q in Q]
    delta = {}
    for (p, a, q) in transitions:
        t = TransitionLabel(a)
        p = prod_of_states_to_state(p)
        q = prod_of_states_to_state(q)
        if p not in delta:
            delta[p] = {}
        if q not in delta[p]:
            delta[p][q] = []
        if t not in delta[p][q]:
            delta[p][q] += [t]

    names = [S.name for S in Ss]
    
    return System("||".join(names), Q, delta)

def mk_prod_ren(P, Q):
    return mk_multi_prod_ren([P, Q])

def delta_aux_aux_cl(a,b,sa,sb,tsa,tsb,delta):
    p = mk_prod_label(a,b)
    q = mk_prod_label(sa, sb)
    for ta in tsa:
        for tb in tsb:
            assert(not ta.is_wait and not ta.is_join)
            assert(not tb.is_wait and not tb.is_join)
            if ta.symbol == tb.symbol:
                wt = ta.wt*tb.wt
                delta = add_prod_transition(p,q,ta.symbol,"",delta,wt)
    return delta

def delta_aux_cl(a,b,va,vb,delta):
    for sa in va:
        tsa = va[sa]
        for sb in vb:
            tsb = vb[sb]
            delta = delta_aux_aux_cl(a,b,sa,sb,tsa,tsb,delta)
    return delta

# TODO: change mk_prod_cl so that it is less naive (e.g. use BFS approach)
def mk_prod_cl(S1, S2):
    delta = {}
    for a in S1.delta:
        # if a not in S1.reach:
        #     continue
        va = S1.delta[a]
        for b in S2.delta:
            # if b not in S2.reach:
            #     continue
            vb = S2.delta[b]
            delta = delta_aux_cl(a,b,va,vb,delta)
    Q = delta2Q(delta)
    S = System(f"{S1.name}||{S2.name}", Q, delta)
    return S
