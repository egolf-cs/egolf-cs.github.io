# SEFM2023 Artifact

This zip file contains the artifact for paper "Decoupled Fitness Criteria for Reactive Systems" by Derek Egolf and Stavros Tripakis, submitted to SEFM 2023. 
The paper is included in the zip file as SEFM2023_paper_53.pdf.

## Running the Artifact
The results in Table 1 of the paper can be reproduced by running the docker commands below and following the prompts.
Each of the three case studies should be run separately, per the prompts. 

`docker build -t sefm2023 .`

Please note the `.` in the command. The user should see the usual docker output, terminating in "Successfully..."

`docker run -it   -v $(pwd)/img:/img   sefm2023`

The user should see a prompt to enter an integer and an explanation for each possible choice.
The data from the table will be printed to the terminal. 
Image files are written to the img directory, which the docker command should automatically mount.

**The total runtime** of the program should not exceed a few minutes at most.

**A common error message** is "Got permission denied while trying to connect to the Docker daemon socket at unix..."
In this case, the user should add sudo to the beginning of the command (or elevate priviledges otherwise).

**We do not include** code to reproduce the results for the symbolic method mentioned in Section 5.1 of the paper, as those results depend on Mathematica, which requires a subscription to use.

## Project Structure

- *_automata.py : these files contain the automata for each case study
- data.py : this file allows to produce data for a case study and to plot that data
- driver.py : this files prompts the user for which case study they would like to reproduce
- tool/LTS.py : this file contains the data structures representing LTSs and auxiliary functions on these data structures (e.g. products)
- tool/interface.py : this file allows to construct the recurrence matrix/initial condition vector and to compute K-approximations

## On Repurposing

The user can easily repurpose the artifact toward applying it to their own systems, fitness function, and aggregate function. 
The user should make a call to the function `tool.interface.k_approx` (e.g. as we do in the function `data.mk_data`). 
The `k_approx` function takes 4 required arguments:

- k : int := the depth to approximate the limit
- S : System :=  the system to be evaluated
- f : list System := the list of LTS representing the fitness function
- h : int^d -> int := the arithmetic function representing the aggregate function, where d is the length of f

And a 5th optional argument dtype, in place of np.float128.

The user may use any value for k; a larger value will result in a more accurate approximation, but the user may need to use a larger number of bits to represent intermediate values if k is too large. 
We use k=9000 and 128 bit floats (dtype=np.float128). 

The System class is defined in `tool.LTS` and there are many examples of constructing an instance of this class. 
The simplest examples are found in `toy_automata.py`, e.g.:

- `mk_sender` and `mk_gr` directly instantiate Systems (representing individual processes)
- `mk_S_good`, which uses `mk_S`, then combines the two processes above via function `tool.LTS.mk_prod_ren` (rendezvous product) to obtain the System that we ultimately want to evaluate--i.e. the second argument to `k_approx`
- `mk_fitness_fn`, which uses `mk_f1` and `mk_f2`, demonstrates how to instantiate the third argument, f, of `k_approx`.

In `driver.py`, we define a function h, which is used as the fourth argument to `k_approx`. The user may instead use another function of the appropriate type, but they should take care so that it represents the intended aggregate (see Section 3 of the paper and the discussion around Definition 4).

The `k_approx` function returns a list of all intermediate K-approximations. The final element of the list is the kth K-approximation and otherwise the ith element of the list is the (2^i)th K-approximation. The user may wish to compare the last and second to last element of the list and check where the decimal places differ, as we do in Section 5 of the paper. They may also plot the results, as we do in `driver.py` using the function `data.plot_lim_approx_multi`. 
