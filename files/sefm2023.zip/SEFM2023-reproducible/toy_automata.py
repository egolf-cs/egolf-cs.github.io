from tool.LTS import StateLabel, TransitionLabel, System, mk_prod_ren


# # Environment Process (the sender) # #
def mk_sender():
    Q = [StateLabel("s0",init=True),
         StateLabel("s1"),
         StateLabel("s2")]
    delta = {Q[0] : {Q[1] : [TransitionLabel("s","!")]},
             Q[1] : {Q[0] : [TransitionLabel("a","?")],
                     Q[2] : [TransitionLabel("t")]},
             Q[2] : {Q[1] : [TransitionLabel("s","!")]}}
    S = System("E", Q, delta)
    return S



# # The Receiver Processes (varies per instance of case study) # #

def mk_gr():
    Q = [StateLabel("g0",init=True),
         StateLabel("g1")]
    delta = {Q[0] : {Q[1] : [TransitionLabel("s","?")]},
             Q[1] : {Q[0] : [TransitionLabel("a","!")],
                     Q[1] : [TransitionLabel("s","?")]}}
    S = System("gr", Q, delta)
    return S

def mk_br():
    Q = [StateLabel("b0",init=True),
         StateLabel("b1"),
         StateLabel("b2")]
    delta = {Q[0] : {Q[1] : [TransitionLabel("s","?")]},
             Q[1] : {Q[2] : [TransitionLabel("s","?")]},
             Q[2] : {Q[0] : [TransitionLabel("a","!")],
                     Q[2] : [TransitionLabel("s","?")]}}
    S = System("br", Q, delta)
    return S



# # The systems to be evaluated, parameterized by the receiver # #

def mk_S(receiver, name):
    S = mk_prod_ren(receiver, mk_sender())
    S.name = name
    return S

def mk_S_good():
    return mk_S(mk_gr(), "good")
def mk_S_bad():
    return mk_S(mk_br(), "bad")



# The Fitness Function # #

def mk_f1():
    Q = [StateLabel("rr0",init=True),
         StateLabel("rr1"),
         StateLabel("rr2",acc=True)]
    delta = {Q[0] : {Q[0] : [TransitionLabel("a"),
                             TransitionLabel("t")],
                     Q[1] : [TransitionLabel("s")]},
             Q[1] : {Q[1] : [TransitionLabel("s"),
                             TransitionLabel("t")],
                     Q[2] : [TransitionLabel("a")]},
             Q[2] : {Q[1] : [TransitionLabel("s")],
                     Q[0] : [TransitionLabel("t"),
                             TransitionLabel("a")]}}
    S = System("f1", Q, delta)
    return S

def mk_f2():
    Q = [StateLabel("len0", init=True),
         StateLabel("len1", acc=True)]
    delta = {Q[0] : {Q[1] : [TransitionLabel("s"),
                             TransitionLabel("t"),
                             TransitionLabel("a")]},
             Q[1] : {Q[1] : [TransitionLabel("s"),
                             TransitionLabel("t"),
                             TransitionLabel("a")]}}
    S = System("f2",Q,delta)
    return S

def mk_fitness_fn():
    return mk_f1(), mk_f2()